package com.example.service

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi

/**
 * Quick Settings Tile allowing instant voice command access
 * from anywhere on the phone (notification shade / quick settings).
 */
@RequiresApi(Build.VERSION_CODES.N)
class ZoyaVoiceTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile ?: return
        tile.state = if (ZoyaFloatingService.isServiceRunning.value) {
            Tile.STATE_ACTIVE
        } else {
            Tile.STATE_INACTIVE
        }
        tile.label = "Zoya Voice"
        tile.updateTile()
    }

    override fun onClick() {
        super.onClick()
        // Trigger voice recognition & overlay directly
        ZoyaFloatingService.triggerVoiceFromOutside(applicationContext)

        val tile = qsTile ?: return
        tile.state = Tile.STATE_ACTIVE
        tile.updateTile()
    }
}
