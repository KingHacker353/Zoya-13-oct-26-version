package com.example.service

import android.content.Intent
import android.speech.RecognitionService

/**
 * Recognition service stub required by Android's VoiceInteractionService specification.
 */
class ZoyaRecognitionService : RecognitionService() {

    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        // Recognition delegate handled in-app or via default engine
    }

    override fun onCancel(listener: Callback?) {
    }

    override fun onStopListening(listener: Callback?) {
    }
}
