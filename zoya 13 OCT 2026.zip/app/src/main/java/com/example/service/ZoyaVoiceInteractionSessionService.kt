package com.example.service

import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

/**
 * Session service for default digital assistant invocations.
 */
class ZoyaVoiceInteractionSessionService : VoiceInteractionSessionService() {

    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        return object : VoiceInteractionSession(this) {
            override fun onHandleAssist(data: Bundle?, structure: android.app.assist.AssistStructure?, content: android.app.assist.AssistContent?) {
                super.onHandleAssist(data, structure, content)
                // When invoked as default assistant via long-press home or gesture, launch floating assistant
                try {
                    ZoyaFloatingService.startService(applicationContext)
                } catch (e: Exception) {
                    // Fallback to launching main app
                    val intent = packageManager.getLaunchIntentForPackage(packageName)
                    if (intent != null) {
                        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(intent)
                    }
                }
                finish()
            }
        }
    }
}
