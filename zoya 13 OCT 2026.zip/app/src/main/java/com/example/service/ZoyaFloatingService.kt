package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.OpenInFull
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.ai.GeminiClient
import com.example.ai.ParsedAction
import com.example.audio.SpeechManager
import com.example.data.local.ZoyaDatabase
import com.example.data.model.ContactEntity
import com.example.data.repository.ZoyaRepository
import com.example.device.PhoneController
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonPink
import com.example.ui.theme.PureBlack
import com.example.ui.theme.RadiantCoral
import com.example.ui.theme.SunnyAmber
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ZoyaFloatingService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private lateinit var speechManager: SpeechManager
    private lateinit var database: ZoyaDatabase
    private lateinit var repository: ZoyaRepository

    // Floating UI state
    private val _isExpanded = MutableStateFlow(false)
    private val _floatingStatus = MutableStateFlow("Zoya Active 💖")
    private val _lastResponse = MutableStateFlow<String?>(null)
    private val _lastAction = MutableStateFlow<String?>(null)

    private var isUnlockReceiverRegistered = false
    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_USER_PRESENT) {
                if (com.example.device.SmartLockController.isAutoListenOnUnlockEnabled(applicationContext)) {
                    serviceScope.launch {
                        kotlinx.coroutines.delay(600)
                        showFloatingBubble()
                        _isExpanded.value = true
                        startListeningForCommand()
                    }
                }
            }
        }
    }

    companion object {
        const val CHANNEL_ID = "zoya_floating_service_channel"
        const val NOTIFICATION_ID = 2001

        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"
        const val ACTION_TRIGGER_VOICE = "com.example.service.ACTION_TRIGGER_VOICE"
        const val ACTION_TOGGLE_BUBBLE = "com.example.service.ACTION_TOGGLE_BUBBLE"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning = _isServiceRunning.asStateFlow()

        fun startService(context: Context) {
            val intent = Intent(context, ZoyaFloatingService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, ZoyaFloatingService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun triggerVoiceFromOutside(context: Context) {
            val intent = Intent(context, ZoyaFloatingService::class.java).apply {
                action = ACTION_TRIGGER_VOICE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        speechManager = SpeechManager(applicationContext, serviceScope)
        database = ZoyaDatabase.getDatabase(applicationContext, serviceScope)
        repository = ZoyaRepository(database.conversationDao(), database.memoryDao(), database.contactDao())

        createNotificationChannel()
        _isServiceRunning.value = true

        if (!isUnlockReceiverRegistered) {
            try {
                val filter = IntentFilter(Intent.ACTION_USER_PRESENT)
                registerReceiver(unlockReceiver, filter)
                isUnlockReceiverRegistered = true
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()

        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TRIGGER_VOICE -> {
                try {
                    @Suppress("DEPRECATION")
                    val closeDialogs = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
                    sendBroadcast(closeDialogs)
                } catch (e: Exception) {
                    // Ignore on newer Android versions where restricted
                }
                showFloatingBubble()
                _isExpanded.value = true
                startListeningForCommand()
            }
            ACTION_TOGGLE_BUBBLE -> {
                if (floatingView == null) {
                    showFloatingBubble()
                } else {
                    _isExpanded.value = !_isExpanded.value
                }
            }
            ACTION_START, null -> {
                showFloatingBubble()
            }
        }

        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Zoya Background Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Runs Zoya Floating Assistant to execute commands across WhatsApp, YouTube, and all apps."
                setShowBadge(false)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    private fun startAsForeground() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val voiceIntent = Intent(this, ZoyaFloatingService::class.java).apply {
            action = ACTION_TRIGGER_VOICE
        }
        val voicePendingIntent = PendingIntent.getService(
            this, 1, voiceIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, ZoyaFloatingService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("💖 Zoya Background Assistant Active")
            .setContentText("Har app ke upar ready hai — Bolo ya tap karo!")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openAppPendingIntent)
            .addAction(android.R.drawable.ic_btn_speak_now, "🎤 Speak Command", voicePendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "❌ Close", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showFloatingBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Zoya Overlay permission chahiye background ke liye", Toast.LENGTH_LONG).show()
            return
        }

        if (floatingView != null) return

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 400
        }
        layoutParams = params

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@ZoyaFloatingService)
            setViewTreeSavedStateRegistryOwner(this@ZoyaFloatingService)
            setViewTreeViewModelStoreOwner(this@ZoyaFloatingService)
            setContent {
                MyApplicationTheme {
                    FloatingZoyaOverlay(
                        isExpandedFlow = _isExpanded,
                        statusFlow = _floatingStatus,
                        lastResponseFlow = _lastResponse,
                        lastActionFlow = _lastAction,
                        isListeningFlow = speechManager.isListening,
                        isSpeakingFlow = speechManager.isSpeaking,
                        liveTranscriptFlow = speechManager.liveTranscript,
                        audioAmplitudeFlow = speechManager.audioAmplitude,
                        onMicClick = {
                            if (speechManager.isListening.value) {
                                speechManager.stopListening()
                            } else {
                                startListeningForCommand()
                            }
                        },
                        onTextSubmit = { text ->
                            processCommand(text)
                        },
                        onCloseClick = {
                            _isExpanded.value = false
                            updateFocusable(false)
                        },
                        onOpenFullApp = {
                            val intent = Intent(this@ZoyaFloatingService, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                            }
                            startActivity(intent)
                            _isExpanded.value = false
                            updateFocusable(false)
                        },
                        onDragDelta = { dx, dy ->
                            handleDrag(dx, dy)
                        },
                        onToggleExpand = {
                            val willExpand = !_isExpanded.value
                            _isExpanded.value = willExpand
                            updateFocusable(willExpand)
                        }
                    )
                }
            }
        }

        floatingView = composeView
        windowManager?.addView(composeView, params)
    }

    private fun handleDrag(dx: Float, dy: Float) {
        val p = layoutParams ?: return
        val v = floatingView ?: return
        p.x += dx.toInt()
        p.y += dy.toInt()
        try {
            windowManager?.updateViewLayout(v, p)
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun updateFocusable(isFocusable: Boolean) {
        val v = floatingView ?: return
        val p = layoutParams ?: return
        if (isFocusable) {
            p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        windowManager?.updateViewLayout(v, p)
    }

    private fun startListeningForCommand(retryOnSilence: Int = 1) {
        _floatingStatus.value = "Sun rahi hoon... 🎤"
        speechManager.startListening(
            onResult = { recognizedText ->
                _floatingStatus.value = "Processing: $recognizedText"
                processCommand(recognizedText)
            },
            onError = { error ->
                if (retryOnSilence > 0) {
                    _floatingStatus.value = "Sun rahi hoon... boliye na! 🎙️"
                    serviceScope.launch(Dispatchers.Main) {
                        kotlinx.coroutines.delay(400)
                        startListeningForCommand(retryOnSilence - 1)
                    }
                } else {
                    _floatingStatus.value = error
                }
            }
        )
    }

    private fun processCommand(text: String) {
        val query = text.trim()
        if (query.isBlank()) return

        serviceScope.launch(Dispatchers.IO) {
            repository.insertConversation(role = "user", content = query, isVoice = true)

            _floatingStatus.value = "Thinking... 🧠"
            val currentMemories = repository.getAllMemoriesList()
            val currentContacts = repository.getAllContactsList()
            val recentHistory = repository.getRecentConversations(4).reversed()

            val zoyaResponse = GeminiClient.generateZoyaResponse(
                userPrompt = query,
                conversationHistory = recentHistory,
                memories = currentMemories,
                contacts = currentContacts
            )

            var actionDesc = ""
            for (action in zoyaResponse.actions) {
                executeAction(action)
                actionDesc += "${action.type} "
            }

            _lastResponse.value = zoyaResponse.spokenText
            _lastAction.value = actionDesc.trim().ifEmpty { null }
            _floatingStatus.value = "Zoya: Done! 💖"

            repository.insertConversation(
                role = "zoya",
                content = zoyaResponse.spokenText,
                actionExecuted = actionDesc.trim().ifEmpty { null },
                isVoice = true
            )

            serviceScope.launch(Dispatchers.Main) {
                speechManager.speak(zoyaResponse.spokenText) {
                    if (com.example.ai.ZoyaCompanionManager.isContinuousConversationEnabled(applicationContext) &&
                        !com.example.ai.ZoyaCompanionManager.isExitPhrase(query)
                    ) {
                        serviceScope.launch(Dispatchers.Main) {
                            kotlinx.coroutines.delay(350)
                            startListeningForCommand()
                        }
                    }
                }
            }
        }
    }

    private suspend fun executeAction(action: ParsedAction) {
        when (action.type) {
            "OPEN_APP" -> PhoneController.openApp(action.target, applicationContext)
            "SEND_WHATSAPP" -> {
                val contact = repository.findContact(action.target)
                val targetPhone = contact?.phoneNumber ?: action.target
                PhoneController.sendWhatsApp(targetPhone, action.message, applicationContext)
            }
            "CALL_PHONE" -> {
                val contact = repository.findContact(action.target)
                val targetPhone = contact?.phoneNumber ?: action.target
                PhoneController.callPhone(targetPhone, applicationContext)
            }
            "SEND_SMS" -> {
                val contact = repository.findContact(action.target)
                val targetPhone = contact?.phoneNumber ?: action.target
                PhoneController.sendSms(targetPhone, action.message, applicationContext)
            }
            "SEARCH_YOUTUBE" -> PhoneController.searchYouTube(action.target, applicationContext)
            "SEARCH_SPOTIFY" -> PhoneController.playSpotify(action.target, applicationContext)
            "SET_ALARM" -> PhoneController.setAlarm(action.hour, action.minute, action.message, applicationContext)
            "SET_TIMER" -> PhoneController.setTimer(action.seconds, action.message, applicationContext)
            "ADJUST_VOLUME" -> PhoneController.adjustVolume(action.target, applicationContext)
            "TOGGLE_FLASHLIGHT" -> {
                val enable = if (action.target.lowercase() == "on") true else if (action.target.lowercase() == "off") false else null
                PhoneController.toggleFlashlight(enable, applicationContext)
            }
            "CHANGE_WALLPAPER" -> PhoneController.changeWallpaper(action.target, applicationContext)
            "SEARCH_WEB" -> PhoneController.searchWeb(action.target, applicationContext)
            "OPEN_SETTINGS" -> PhoneController.openSettingsSection(action.target, applicationContext)
            "TRIGGER_VIBRATION" -> PhoneController.triggerVibration(if (action.seconds > 0) (action.seconds * 1000).toLong() else 400L, applicationContext)
            "LOCK_SCREEN" -> PhoneController.lockScreen(applicationContext)
            "UNLOCK_SCREEN" -> PhoneController.unlockScreen(applicationContext)
            "GLOBAL_BACK" -> ZoyaAccessibilityService.performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
            "GLOBAL_HOME" -> ZoyaAccessibilityService.performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
            "GLOBAL_RECENTS" -> ZoyaAccessibilityService.performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
            "GLOBAL_NOTIFICATIONS" -> ZoyaAccessibilityService.performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            "CLICK_SCREEN" -> ZoyaAccessibilityService.clickTextOnScreen(action.target)
            "SCROLL_DOWN" -> ZoyaAccessibilityService.scrollDown()
            "SCROLL_UP" -> ZoyaAccessibilityService.scrollUp()
            "TYPE_TEXT" -> ZoyaAccessibilityService.typeTextIntoInput(action.target)
            "READ_SCREEN" -> {
                val summary = ZoyaAccessibilityService.getVisibleScreenSummary()
                speechManager.speak("Screen par dikh raha hai: $summary")
            }
            "SAVE_MEMORY" -> {
                if (action.key.isNotBlank() && action.value.isNotBlank()) {
                    repository.insertMemory(action.key, action.value, action.category)
                }
            }
            "ADD_CONTACT" -> {
                if (action.name.isNotBlank() && action.phone.isNotBlank()) {
                    repository.insertContact(
                        ContactEntity(
                            name = action.name,
                            phoneNumber = action.phone,
                            nickname = action.nickname,
                            relationship = action.relationship
                        )
                    )
                }
            }
            "SET_PATTERN" -> {
                val dots = action.target.split(",", " ", "-", ">").mapNotNull { it.trim().toIntOrNull() }.filter { it in 1..9 }
                if (dots.isNotEmpty()) {
                    com.example.device.SmartLockController.savePattern(applicationContext, dots)
                }
            }
            "SET_PIN" -> {
                val pin = action.target.filter { it.isDigit() }
                if (pin.isNotBlank()) {
                    com.example.device.SmartLockController.savePin(applicationContext, pin)
                }
            }
            "ORDER_ITEM" -> {
                val platform = if (action.platform.isNotBlank()) action.platform else "amazon"
                val item = if (action.item.isNotBlank()) action.item else action.target
                PhoneController.orderItem(platform, item, applicationContext)
            }
            "BOOK_TRAIN_TICKET" -> {
                val origin = if (action.origin.isNotBlank()) action.origin else "Ahmedabad"
                val destination = if (action.destination.isNotBlank()) action.destination else if (action.target.isNotBlank()) action.target else "Mumbai"
                val date = if (action.date.isNotBlank()) action.date else "today"
                val platform = if (action.platform.isNotBlank()) action.platform else "confirmtkt"
                PhoneController.bookTrainTicket(origin, destination, date, platform, applicationContext)
            }
        }
    }

    private fun removeFloatingBubble() {
        floatingView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (e: Exception) {
                // ignore
            }
            floatingView = null
        }
    }

    override fun onDestroy() {
        if (isUnlockReceiverRegistered) {
            try {
                unregisterReceiver(unlockReceiver)
            } catch (e: Exception) {
                // ignore
            }
            isUnlockReceiverRegistered = false
        }
        removeFloatingBubble()
        speechManager.destroy()
        serviceScope.cancel()
        _isServiceRunning.value = false

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()

        super.onDestroy()
    }
}

@Composable
fun FloatingZoyaOverlay(
    isExpandedFlow: MutableStateFlow<Boolean>,
    statusFlow: MutableStateFlow<String>,
    lastResponseFlow: MutableStateFlow<String?>,
    lastActionFlow: MutableStateFlow<String?>,
    isListeningFlow: kotlinx.coroutines.flow.StateFlow<Boolean>,
    isSpeakingFlow: kotlinx.coroutines.flow.StateFlow<Boolean>,
    liveTranscriptFlow: kotlinx.coroutines.flow.StateFlow<String>,
    audioAmplitudeFlow: kotlinx.coroutines.flow.StateFlow<Float>,
    onMicClick: () -> Unit,
    onTextSubmit: (String) -> Unit,
    onCloseClick: () -> Unit,
    onOpenFullApp: () -> Unit,
    onDragDelta: (Float, Float) -> Unit,
    onToggleExpand: () -> Unit
) {
    val isExpanded by isExpandedFlow.collectAsState()
    val status by statusFlow.collectAsState()
    val lastResponse by lastResponseFlow.collectAsState()
    val lastAction by lastActionFlow.collectAsState()
    val isListening by isListeningFlow.collectAsState()
    val isSpeaking by isSpeakingFlow.collectAsState()
    val liveTranscript by liveTranscriptFlow.collectAsState()
    val amplitude by audioAmplitudeFlow.collectAsState()

    var textInput by remember { mutableStateOf("") }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening || isSpeaking) 1.22f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Column(
        modifier = Modifier.padding(6.dp),
        horizontalAlignment = Alignment.End
    ) {
        // Expanded Floating Control Card
        AnimatedVisibility(
            visible = isExpanded,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically()
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = PureBlack.copy(alpha = 0.95f),
                tonalElevation = 12.dp,
                shadowElevation = 12.dp,
                modifier = Modifier
                    .widthIn(min = 280.dp, max = 340.dp)
                    .border(1.5.dp, Brush.linearGradient(listOf(NeonPink, DeepViolet, CyberTeal)), RoundedCornerShape(24.dp))
                    .padding(bottom = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(14.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(
                                        Brush.linearGradient(listOf(NeonPink, DeepViolet)),
                                        CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("💖", fontSize = 14.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Zoya Background",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Har App Me Active ✨",
                                    fontSize = 10.sp,
                                    color = CyberTeal
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onOpenFullApp, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Rounded.OpenInFull,
                                    contentDescription = "Open Full App",
                                    tint = TextSecondaryDark,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(onClick = onCloseClick, modifier = Modifier.size(32.dp)) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Minimize",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Live Status Pill
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isListening) RadiantCoral.copy(alpha = 0.2f) else DarkSurfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (isListening) RadiantCoral else Color.Transparent,
                                RoundedCornerShape(12.dp)
                            )
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (isListening) Icons.Rounded.Mic else if (isSpeaking) Icons.Rounded.VolumeUp else Icons.Rounded.GraphicEq,
                                    contentDescription = null,
                                    tint = if (isListening) RadiantCoral else if (isSpeaking) CyberTeal else NeonPink,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (liveTranscript.isNotBlank() && isListening) liveTranscript else status,
                                    fontSize = 12.sp,
                                    fontWeight = if (isListening) FontWeight.Bold else FontWeight.Normal,
                                    color = Color.White,
                                    maxLines = 2
                                )
                            }

                            if (isListening || isSpeaking) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    for (i in 0..7) {
                                        val heightMultiplier = kotlin.math.sin((i * 0.8f) + (amplitude * 10f)).coerceIn(0.2f, 1f)
                                        Box(
                                            modifier = Modifier
                                                .padding(horizontal = 2.dp)
                                                .width(3.dp)
                                                .height((8.dp + (20.dp * amplitude * heightMultiplier)).coerceIn(4.dp, 28.dp))
                                                .background(
                                                    if (isListening) RadiantCoral else CyberTeal,
                                                    RoundedCornerShape(2.dp)
                                                )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Last response card if present
                    if (!lastResponse.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = DarkSurface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NeonPink.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                if (!lastAction.isNullOrBlank()) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = CyberTeal.copy(alpha = 0.2f),
                                        modifier = Modifier.padding(bottom = 4.dp)
                                    ) {
                                        Text(
                                            text = "⚡ Action: $lastAction",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CyberTeal,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = lastResponse ?: "",
                                    fontSize = 12.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Center Big Voice Mic Button
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .scale(if (isListening) pulseScale else 1f)
                                .background(
                                    brush = Brush.radialGradient(
                                        listOf(
                                            if (isListening) RadiantCoral else NeonPink,
                                            DeepViolet
                                        )
                                    ),
                                    shape = CircleShape
                                )
                                .clickable { onMicClick() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                                contentDescription = "Mic",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Text Input Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            placeholder = { Text("Command likho...", fontSize = 12.sp, color = TextSecondaryDark) },
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = Color.White),
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = DarkSurfaceVariant,
                                unfocusedContainerColor = DarkSurfaceVariant,
                                cursorColor = NeonPink,
                                focusedBorderColor = NeonPink,
                                unfocusedBorderColor = DarkBorder
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                if (textInput.isNotBlank()) {
                                    onTextSubmit(textInput)
                                    textInput = ""
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .background(NeonPink, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Send,
                                contentDescription = "Send",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quick Command Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        FloatingMiniChip("💬 WhatsApp") { onTextSubmit("WhatsApp open karo") }
                        FloatingMiniChip("🎬 YouTube") { onTextSubmit("YouTube par mast gaane chalao") }
                        FloatingMiniChip("🔦 Torch") { onTextSubmit("Flashlight on karo") }
                        FloatingMiniChip("🔊 Vol+") { onTextSubmit("Volume badao") }
                    }
                }
            }
        }

        // Draggable Floating Bubble Orb (The main icon floating over apps)
        Box(
            modifier = Modifier
                .size(60.dp)
                .scale(if (isListening || isSpeaking) pulseScale else 1f)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDragDelta(dragAmount.x, dragAmount.y)
                    }
                }
                .background(
                    brush = Brush.sweepGradient(
                        listOf(NeonPink, DeepViolet, CyberTeal, RadiantCoral, NeonPink)
                    ),
                    shape = CircleShape
                )
                .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                .clickable { onToggleExpand() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (isListening) "🎤" else "💖",
                    fontSize = 22.sp
                )
                Text(
                    text = "ZOYA",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun FloatingMiniChip(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DarkSurfaceVariant,
        modifier = Modifier
            .border(0.8.dp, NeonPink.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
        )
    }
}
