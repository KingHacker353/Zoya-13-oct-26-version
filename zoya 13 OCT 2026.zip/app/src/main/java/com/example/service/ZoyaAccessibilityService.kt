package com.example.service

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.ai.GeminiClient
import com.example.ai.ParsedAction
import com.example.audio.SpeechManager
import com.example.data.local.ZoyaDatabase
import com.example.data.repository.ZoyaRepository
import com.example.device.PhoneController
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MagentaRose
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonPink
import com.example.ui.theme.RadiantCoral
import com.example.ui.theme.SunnyAmber
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.sin

/**
 * Zoya Accessibility Service: Provides shortcut button on navigation bar / screen corner,
 * allowing instant Voice Access phone control across all apps with zero screen blocking.
 */
class ZoyaAccessibilityService : AccessibilityService(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.Main + serviceJob)

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private var windowManager: WindowManager? = null
    private var voiceHudView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private lateinit var speechManager: SpeechManager
    private lateinit var database: ZoyaDatabase
    private lateinit var repository: ZoyaRepository

    private val _isHudVisible = MutableStateFlow(false)
    private val _hudStatus = MutableStateFlow("Listening...")
    private val _liveCommand = MutableStateFlow("")
    private val _lastResponse = MutableStateFlow<String?>(null)

    private var autoDismissJob: Job? = null

    companion object {
        private var instance: ZoyaAccessibilityService? = null

        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive = _isServiceActive.asStateFlow()

        fun isAccessibilityEnabled(context: Context): Boolean {
            val expectedServiceName = "${context.packageName}/${ZoyaAccessibilityService::class.java.canonicalName}"
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val colonSplitter = TextUtils.SimpleStringSplitter(':')
            colonSplitter.setString(enabledServices)
            while (colonSplitter.hasNext()) {
                val componentName = colonSplitter.next()
                if (componentName.equals(expectedServiceName, ignoreCase = true) ||
                    componentName.contains(ZoyaAccessibilityService::class.java.simpleName)
                ) {
                    return true
                }
            }
            return false
        }

        fun triggerVoiceFromShortcut(context: Context) {
            val s = instance
            if (s != null) {
                s.startVoiceCommandFlow()
            } else {
                // Open Accessibility Settings if not enabled
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                Toast.makeText(context, "Kripya Zoya Voice Access ko ON karein", Toast.LENGTH_LONG).show()
            }
        }

        fun triggerVoiceOnUnlock(context: Context) {
            val s = instance
            if (s != null) {
                s.serviceScope.launch {
                    kotlinx.coroutines.delay(500)
                    s.triggerVoiceAfterUnlock()
                }
            } else {
                ZoyaFloatingService.triggerVoiceFromOutside(context)
            }
        }

        fun performGlobal(action: Int): Boolean {
            return instance?.performGlobalAction(action) ?: false
        }

        fun clickTextOnScreen(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val cleanTarget = text.trim()
            if (cleanTarget.isBlank()) return false

            // 1. Direct text search
            val nodes = root.findAccessibilityNodeInfosByText(cleanTarget)
            for (node in nodes) {
                if (node.isClickable || node.isEnabled) {
                    if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                }
                var parent = node.parent
                while (parent != null) {
                    if (parent.isClickable) {
                        if (parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    }
                    parent = parent.parent
                }
            }

            // 2. Content description search (icons, image buttons, tabs)
            val matchedByDesc = mutableListOf<AccessibilityNodeInfo>()
            instance?.findNodesByDescription(root, cleanTarget, matchedByDesc)
            for (node in matchedByDesc) {
                if (node.isClickable || node.isEnabled) {
                    if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                }
                var parent = node.parent
                while (parent != null) {
                    if (parent.isClickable) {
                        if (parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    }
                    parent = parent.parent
                }
            }

            return false
        }

        fun scrollDown(): Boolean {
            val s = instance ?: return false
            val root = s.rootInActiveWindow ?: return false
            val scrollable = findFirstScrollable(root)
            if (scrollable != null) {
                val scrolled = scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
                if (scrolled) return true
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val metrics = s.resources.displayMetrics
                val width = metrics.widthPixels.toFloat()
                val height = metrics.heightPixels.toFloat()
                val path = Path().apply {
                    moveTo(width * 0.5f, height * 0.75f)
                    lineTo(width * 0.5f, height * 0.25f)
                }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
                    .build()
                return s.dispatchGesture(gesture, null, null)
            }
            return false
        }

        fun scrollUp(): Boolean {
            val s = instance ?: return false
            val root = s.rootInActiveWindow ?: return false
            val scrollable = findFirstScrollable(root)
            if (scrollable != null) {
                val scrolled = scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
                if (scrolled) return true
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val metrics = s.resources.displayMetrics
                val width = metrics.widthPixels.toFloat()
                val height = metrics.heightPixels.toFloat()
                val path = Path().apply {
                    moveTo(width * 0.5f, height * 0.25f)
                    lineTo(width * 0.5f, height * 0.75f)
                }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
                    .build()
                return s.dispatchGesture(gesture, null, null)
            }
            return false
        }

        private fun findFirstScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null) return null
            if (node.isScrollable) return node
            for (i in 0 until node.childCount) {
                val res = findFirstScrollable(node.getChild(i))
                if (res != null) return res
            }
            return null
        }

        fun typeTextIntoInput(text: String, pressSearch: Boolean = true): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            // 1. Check focused editable field
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null && (focused.isEditable || focused.className?.toString()?.contains("EditText", ignoreCase = true) == true)) {
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
                val success = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                if (success && pressSearch) {
                    clickTextOnScreen("Search") || clickTextOnScreen("Go") || clickTextOnScreen("खोजें")
                }
                return success
            }
            // 2. Find any editable field on screen (e.g. search bar in app or browser)
            val editableList = mutableListOf<AccessibilityNodeInfo>()
            findEditableNodes(root, editableList)
            if (editableList.isNotEmpty()) {
                val target = editableList.first()
                target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
                val success = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                if (success && pressSearch) {
                    clickTextOnScreen("Search") || clickTextOnScreen("Go") || clickTextOnScreen("खोजें")
                }
                return success
            }
            return false
        }

        private fun findEditableNodes(node: AccessibilityNodeInfo?, list: MutableList<AccessibilityNodeInfo>) {
            if (node == null) return
            if (node.isEditable || node.className?.toString()?.contains("EditText", ignoreCase = true) == true) {
                list.add(node)
            }
            for (i in 0 until node.childCount) {
                findEditableNodes(node.getChild(i), list)
            }
        }

        fun getVisibleScreenSummary(): String {
            val root = instance?.rootInActiveWindow ?: return "Screen par kuch nazar nahi aa raha."
            val textList = mutableListOf<String>()
            collectVisibleTexts(root, textList)
            val distinct = textList.map { it.trim() }.filter { it.length > 1 }.distinct()
            return if (distinct.isNotEmpty()) {
                distinct.take(10).joinToString(", ")
            } else {
                "Screen par koi text nahi dikha."
            }
        }

        private fun collectVisibleTexts(node: AccessibilityNodeInfo?, list: MutableList<String>) {
            if (node == null) return
            node.text?.toString()?.let { if (it.isNotBlank()) list.add(it) }
            node.contentDescription?.toString()?.let { if (it.isNotBlank()) list.add(it) }
            for (i in 0 until node.childCount) {
                collectVisibleTexts(node.getChild(i), list)
            }
        }

        private var isWhatsAppAutoSendPending = false
        private var isYouTubeAutoPlayPending = false

        fun triggerWhatsAppAutoSend() {
            isWhatsAppAutoSendPending = true
            instance?.scheduleWhatsAppAutoSend()
        }

        fun triggerYouTubeAutoPlay() {
            isYouTubeAutoPlayPending = true
            instance?.scheduleYouTubeAutoPlay()
        }

        fun tapAtCoordinate(x: Float, y: Float): Boolean {
            val s = instance ?: return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val path = Path().apply {
                    moveTo(x, y)
                }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 100))
                    .build()
                return s.dispatchGesture(gesture, null, null)
            }
            return false
        }

        fun swipeUpToUnlock(): Boolean {
            val s = instance ?: return false
            com.example.device.SmartLockController.wakeUpScreen(s.applicationContext)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val metrics = s.resources.displayMetrics
                val w = metrics.widthPixels.toFloat()
                val h = metrics.heightPixels.toFloat()
                val path = Path().apply {
                    moveTo(w * 0.5f, h * 0.82f)
                    lineTo(w * 0.5f, h * 0.20f)
                }
                val gesture = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0, 250))
                    .build()
                return s.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (com.example.device.SmartLockController.isAutoListenOnUnlockEnabled(s.applicationContext)) {
                            s.serviceScope.launch {
                                delay(1000)
                                s.triggerVoiceAfterUnlock()
                            }
                        }
                    }
                }, null)
            }
            return false
        }

        fun unlockDeviceWithPattern(patternDots: List<Int>, callback: ((Boolean) -> Unit)? = null) {
            val s = instance
            if (s == null) {
                callback?.invoke(false)
                return
            }
            com.example.device.SmartLockController.wakeUpScreen(s.applicationContext)
            s.serviceScope.launch {
                delay(350)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    val metrics = s.resources.displayMetrics
                    val w = metrics.widthPixels.toFloat()
                    val h = metrics.heightPixels.toFloat()
                    val swipePath = Path().apply {
                        moveTo(w * 0.5f, h * 0.85f)
                        lineTo(w * 0.5f, h * 0.25f)
                    }
                    val swipeGesture = GestureDescription.Builder()
                        .addStroke(GestureDescription.StrokeDescription(swipePath, 0, 250))
                        .build()

                    s.dispatchGesture(swipeGesture, object : AccessibilityService.GestureResultCallback() {
                        override fun onCompleted(gestureDescription: GestureDescription?) {
                            s.serviceScope.launch {
                                delay(450)
                                drawPatternGesture(patternDots, callback)
                            }
                        }
                        override fun onCancelled(gestureDescription: GestureDescription?) {
                            s.serviceScope.launch {
                                delay(250)
                                drawPatternGesture(patternDots, callback)
                            }
                        }
                    }, null)
                } else {
                    callback?.invoke(false)
                }
            }
        }

        fun drawPatternGesture(patternDots: List<Int>, callback: ((Boolean) -> Unit)? = null): Boolean {
            val s = instance ?: return false
            if (patternDots.isEmpty() || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return false

            val metrics = s.resources.displayMetrics
            val screenWidth = metrics.widthPixels.toFloat()
            val screenHeight = metrics.heightPixels.toFloat()

            val root = s.rootInActiveWindow
            var gridLeft = screenWidth * 0.14f
            var gridWidth = screenWidth * 0.72f
            var gridHeight = gridWidth
            var gridTop = (screenHeight * 0.60f) - (gridHeight / 2f)

            val patternNode = findPatternNode(root)
            if (patternNode != null) {
                val r = Rect()
                patternNode.getBoundsInScreen(r)
                if (r.width() > 100 && r.height() > 100) {
                    gridLeft = r.left.toFloat()
                    gridTop = r.top.toFloat()
                    gridWidth = r.width().toFloat()
                    gridHeight = r.height().toFloat()
                }
            }

            fun getDotCenter(dotNumber: Int): Pair<Float, Float> {
                val index = (dotNumber - 1).coerceIn(0, 8)
                val col = index % 3
                val row = index / 3
                val x = gridLeft + (col + 0.5f) * (gridWidth / 3f)
                val y = gridTop + (row + 0.5f) * (gridHeight / 3f)
                return Pair(x, y)
            }

            val path = Path()
            val (startX, startY) = getDotCenter(patternDots.first())
            path.moveTo(startX, startY)

            for (i in 1 until patternDots.size) {
                val (nextX, nextY) = getDotCenter(patternDots[i])
                path.lineTo(nextX, nextY)
            }

            val duration = (patternDots.size * 140L).coerceIn(400L, 1200L)
            val stroke = GestureDescription.StrokeDescription(path, 0, duration)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()

            return s.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    callback?.invoke(true)
                    if (com.example.device.SmartLockController.isAutoListenOnUnlockEnabled(s.applicationContext)) {
                        s.serviceScope.launch {
                            delay(1000)
                            s.triggerVoiceAfterUnlock()
                        }
                    }
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    callback?.invoke(false)
                }
            }, null)
        }

        fun unlockDeviceWithPin(pin: String, callback: ((Boolean) -> Unit)? = null) {
            val s = instance
            if (s == null) {
                callback?.invoke(false)
                return
            }
            com.example.device.SmartLockController.wakeUpScreen(s.applicationContext)
            s.serviceScope.launch {
                delay(350)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    val metrics = s.resources.displayMetrics
                    val w = metrics.widthPixels.toFloat()
                    val h = metrics.heightPixels.toFloat()
                    val swipePath = Path().apply {
                        moveTo(w * 0.5f, h * 0.85f)
                        lineTo(w * 0.5f, h * 0.25f)
                    }
                    val swipeGesture = GestureDescription.Builder()
                        .addStroke(GestureDescription.StrokeDescription(swipePath, 0, 250))
                        .build()

                    s.dispatchGesture(swipeGesture, object : AccessibilityService.GestureResultCallback() {
                        override fun onCompleted(gestureDescription: GestureDescription?) {
                            s.serviceScope.launch {
                                delay(400)
                                for (digit in pin) {
                                    clickTextOnScreen(digit.toString())
                                    delay(140)
                                }
                                delay(200)
                                val ok = clickTextOnScreen("Enter") || clickTextOnScreen("OK") || clickTextOnScreen("✓")
                                callback?.invoke(ok)
                                if (com.example.device.SmartLockController.isAutoListenOnUnlockEnabled(s.applicationContext)) {
                                    s.serviceScope.launch {
                                        delay(1000)
                                        s.triggerVoiceAfterUnlock()
                                    }
                                }
                            }
                        }
                        override fun onCancelled(gestureDescription: GestureDescription?) {
                            callback?.invoke(false)
                        }
                    }, null)
                }
            }
        }

        private fun findPatternNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null) return null
            val cls = node.className?.toString() ?: ""
            val id = node.viewIdResourceName?.toString() ?: ""
            if (cls.contains("Pattern", ignoreCase = true) || id.contains("pattern", ignoreCase = true)) {
                return node
            }
            for (i in 0 until node.childCount) {
                val found = findPatternNode(node.getChild(i))
                if (found != null) return found
            }
            return null
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        _isServiceActive.value = true

        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)

        database = ZoyaDatabase.getDatabase(applicationContext, serviceScope)
        repository = ZoyaRepository(database.conversationDao(), database.memoryDao(), database.contactDao())
        speechManager = SpeechManager(applicationContext, serviceScope)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        setupVoiceHudOverlay()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceActive.value = true
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        // Setup Accessibility Button callback (Android 8.0+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val controller = accessibilityButtonController
            controller.registerAccessibilityButtonCallback(object : AccessibilityButtonController.AccessibilityButtonCallback() {
                override fun onClicked(controller: AccessibilityButtonController?) {
                    super.onClicked(controller)
                    startVoiceCommandFlow()
                }

                override fun onAvailabilityChanged(
                    controller: AccessibilityButtonController?,
                    available: Boolean
                ) {
                    super.onAvailabilityChanged(controller, available)
                }
            })
        }

        Toast.makeText(applicationContext, "💖 Zoya Voice Access Shortcut Active! Accessibility button se bolo.", Toast.LENGTH_SHORT).show()

        if (!isUnlockReceiverRegistered) {
            try {
                val filter = IntentFilter(Intent.ACTION_USER_PRESENT)
                registerReceiver(unlockReceiver, filter)
                isUnlockReceiverRegistered = true
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: ""
        if (isWhatsAppAutoSendPending && (pkg.contains("whatsapp", ignoreCase = true))) {
            serviceScope.launch {
                delay(300)
                if (isWhatsAppAutoSendPending) {
                    val sent = attemptSendWhatsAppMessage()
                    if (sent) {
                        isWhatsAppAutoSendPending = false
                    }
                }
            }
        }
        if (isYouTubeAutoPlayPending && (pkg.contains("youtube", ignoreCase = true) || pkg.contains("chrome", ignoreCase = true) || pkg.contains("browser", ignoreCase = true))) {
            serviceScope.launch {
                delay(400)
                if (isYouTubeAutoPlayPending) {
                    val played = attemptPlayFirstYouTubeVideo()
                    if (played) {
                        isYouTubeAutoPlayPending = false
                    }
                }
            }
        }
    }

    fun scheduleYouTubeAutoPlay() {
        isYouTubeAutoPlayPending = true
        serviceScope.launch {
            // Check immediately and poll for up to 6 seconds for YouTube search results to appear
            repeat(12) { attemptIndex ->
                delay(500)
                if (!isYouTubeAutoPlayPending) return@launch
                val played = attemptPlayFirstYouTubeVideo()
                if (played) {
                    isYouTubeAutoPlayPending = false
                    return@launch
                }
                // Fallback after 2.5 seconds: tap directly on the first video card position in YouTube!
                if (attemptIndex == 4 && isYouTubeAutoPlayPending) {
                    val root = rootInActiveWindow
                    val pkg = root?.packageName?.toString() ?: ""
                    if (pkg.contains("youtube", ignoreCase = true) || pkg.contains("chrome", ignoreCase = true)) {
                        val metrics = resources.displayMetrics
                        val tapX = metrics.widthPixels * 0.5f
                        val tapY = metrics.heightPixels * 0.35f
                        tapAtCoordinate(tapX, tapY)
                        isYouTubeAutoPlayPending = false
                        return@launch
                    }
                }
            }
            isYouTubeAutoPlayPending = false
        }
    }

    private fun attemptPlayFirstYouTubeVideo(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: ""
        if (!pkg.contains("youtube", ignoreCase = true) && !pkg.contains("chrome", ignoreCase = true) && !pkg.contains("browser", ignoreCase = true)) {
            return false
        }

        // 1. YouTube App View IDs
        val videoViewIds = listOf(
            "com.google.android.youtube:id/thumbnail",
            "com.google.android.youtube:id/video_info_view",
            "com.google.android.youtube:id/compact_renderer",
            "com.google.android.youtube:id/item_layout",
            "com.google.android.youtube:id/title"
        )
        for (vid in videoViewIds) {
            val nodes = root.findAccessibilityNodeInfosByViewId(vid)
            for (node in nodes) {
                val target = if (node.isClickable) node else findClickableParent(node)
                if (target != null && target.isEnabled) {
                    val bounds = Rect()
                    target.getBoundsInScreen(bounds)
                    if (bounds.top > 180 && bounds.width() > 80) {
                        val clicked = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        if (clicked) return true
                    }
                }
            }
        }

        // 2. Search for clickable video cards by description (contains "views", "duration", "minute", "video")
        val videoCardNodes = mutableListOf<AccessibilityNodeInfo>()
        findVideoCardsByDescription(root, videoCardNodes)
        for (card in videoCardNodes) {
            val target = if (card.isClickable) card else findClickableParent(card)
            if (target != null && target.isEnabled) {
                val bounds = Rect()
                target.getBoundsInScreen(bounds)
                if (bounds.top > 180) {
                    val clicked = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    if (clicked) return true
                }
            }
        }

        return false
    }

    private fun findClickableParent(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var p = node?.parent
        while (p != null) {
            if (p.isClickable) return p
            p = p.parent
        }
        return null
    }

    private fun findVideoCardsByDescription(node: AccessibilityNodeInfo?, result: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        val desc = node.contentDescription?.toString() ?: ""
        if (desc.contains("views", ignoreCase = true) || desc.contains("minute", ignoreCase = true) ||
            desc.contains("second", ignoreCase = true) || desc.contains("ago", ignoreCase = true) ||
            desc.contains("video", ignoreCase = true)
        ) {
            result.add(node)
        }
        for (i in 0 until node.childCount) {
            findVideoCardsByDescription(node.getChild(i), result)
        }
    }

    fun scheduleWhatsAppAutoSend() {
        serviceScope.launch {
            // Poll for up to 4 seconds for WhatsApp UI to load and click the send button
            repeat(8) {
                delay(500)
                if (isWhatsAppAutoSendPending) {
                    val sent = attemptSendWhatsAppMessage()
                    if (sent) {
                        isWhatsAppAutoSendPending = false
                        return@launch
                    }
                } else {
                    return@launch
                }
            }
            isWhatsAppAutoSendPending = false
        }
    }

    private fun attemptSendWhatsAppMessage(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString() ?: ""
        if (!pkg.contains("whatsapp", ignoreCase = true)) {
            return false
        }

        // 1. Try finding by known WhatsApp send button view IDs
        val sendViewIds = listOf(
            "com.whatsapp:id/send",
            "com.whatsapp.w4b:id/send",
            "com.whatsapp:id/send_container"
        )
        for (viewId in sendViewIds) {
            val nodes = root.findAccessibilityNodeInfosByViewId(viewId)
            for (node in nodes) {
                if (node.isEnabled) {
                    val clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    if (clicked) return true
                }
            }
        }

        // 2. Try finding by Content Description: "Send", "भेजें", "Send message"
        val sendKeywords = listOf("Send", "भेजें", "ارسال", "Send message")
        for (kw in sendKeywords) {
            val matchedNodes = mutableListOf<AccessibilityNodeInfo>()
            findNodesByDescription(root, kw, matchedNodes)
            for (node in matchedNodes) {
                if (node.isClickable || node.isEnabled) {
                    if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    var p = node.parent
                    while (p != null) {
                        if (p.isClickable) {
                            if (p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                        }
                        p = p.parent
                    }
                }
            }
        }

        return false
    }

    private fun findNodesByDescription(node: AccessibilityNodeInfo?, target: String, result: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        val desc = node.contentDescription?.toString()
        if (desc != null && desc.contains(target, ignoreCase = true)) {
            result.add(node)
        }
        for (i in 0 until node.childCount) {
            findNodesByDescription(node.getChild(i), target, result)
        }
    }

    override fun onInterrupt() {
        speechManager.stopSpeaking()
        speechManager.stopListening()
        _isHudVisible.value = false
    }

    @SuppressLint("InflateParams")
    private fun setupVoiceHudOverlay() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 30
        }

        voiceHudView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@ZoyaAccessibilityService)
            setViewTreeViewModelStoreOwner(this@ZoyaAccessibilityService)
            setViewTreeSavedStateRegistryOwner(this@ZoyaAccessibilityService)

            setContent {
                MyApplicationTheme {
                    VoiceHudComponent(
                        isVisible = _isHudVisible.collectAsState().value,
                        status = _hudStatus.collectAsState().value,
                        liveCommand = _liveCommand.collectAsState().value,
                        lastResponse = _lastResponse.collectAsState().value,
                        isListening = speechManager.isListening.collectAsState().value,
                        isSpeaking = speechManager.isSpeaking.collectAsState().value,
                        amplitude = speechManager.audioAmplitude.collectAsState().value,
                        onMicClick = {
                            if (speechManager.isListening.value) {
                                speechManager.stopListening()
                            } else {
                                startVoiceCommandFlow()
                            }
                        },
                        onCloseClick = {
                            speechManager.stopListening()
                            speechManager.stopSpeaking()
                            _isHudVisible.value = false
                        }
                    )
                }
            }
        }

        try {
            windowManager?.addView(voiceHudView, layoutParams)
        } catch (e: Exception) {
            // overlay add failed
        }
    }

    private var isUnlockReceiverRegistered = false
    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_USER_PRESENT) {
                if (com.example.device.SmartLockController.isAutoListenOnUnlockEnabled(applicationContext)) {
                    serviceScope.launch {
                        delay(600)
                        triggerVoiceAfterUnlock()
                    }
                }
            }
        }
    }

    private var lastUnlockTriggerTime = 0L

    fun triggerVoiceAfterUnlock() {
        val now = System.currentTimeMillis()
        if (now - lastUnlockTriggerTime < 2500L) {
            return
        }
        lastUnlockTriggerTime = now

        serviceScope.launch {
            autoDismissJob?.cancel()
            _isHudVisible.value = true
            _hudStatus.value = "Phone unlock ho gaya! Boss, sun rahi hoon... 🎤🔓"
            _liveCommand.value = ""
            _lastResponse.value = null

            var listeningStarted = false
            fun startListeningSafely() {
                if (!listeningStarted) {
                    listeningStarted = true
                    startVoiceCommandFlow()
                }
            }

            // Proactively greet Boss and ask about mood & day like Google Assistant
            val greeting = if (com.example.ai.ZoyaCompanionManager.isProactiveCheckInEnabled(applicationContext)) {
                com.example.ai.ZoyaCompanionManager.getProactiveMoodGreeting(applicationContext)
            } else {
                "Phone unlock ho gaya Boss! Boliye, kya hukum hai?"
            }

            speechManager.speak(greeting) {
                serviceScope.launch(Dispatchers.Main) {
                    delay(500)
                    startListeningSafely()
                }
            }
        }
    }

    fun startVoiceCommandFlow(retryOnSilence: Int = 1) {
        autoDismissJob?.cancel()
        _isHudVisible.value = true
        _hudStatus.value = "Sun rahi hoon... boliye! 🎤"
        _liveCommand.value = ""
        _lastResponse.value = null

        speechManager.startListening(
            onResult = { userSpeech ->
                _liveCommand.value = userSpeech
                processVoiceCommand(userSpeech)
            },
            onError = { error ->
                if (retryOnSilence > 0) {
                    _hudStatus.value = "Sun rahi hoon... boliye na! 🎙️"
                    serviceScope.launch(Dispatchers.Main) {
                        delay(400)
                        startVoiceCommandFlow(retryOnSilence - 1)
                    }
                } else {
                    _hudStatus.value = "Dobara boliye: $error"
                    scheduleAutoDismiss(3500)
                }
            }
        )
    }

    private fun processVoiceCommand(command: String) {
        if (command.isBlank()) {
            scheduleAutoDismiss(2000)
            return
        }

        _hudStatus.value = "Samajh rahi hoon... 💭"
        serviceScope.launch(Dispatchers.IO) {
            try {
                // Save user message in local history
                repository.insertConversation(role = "user", content = command, isVoice = true)

                val memories = repository.getAllMemoriesList()
                val contacts = repository.getAllContactsList()
                val history = repository.getRecentConversations(6).reversed()

                val response = GeminiClient.generateZoyaResponse(
                    userPrompt = command,
                    conversationHistory = history,
                    memories = memories,
                    contacts = contacts
                )

                // Save Zoya reply
                repository.insertConversation(role = "zoya", content = response.spokenText, isVoice = true)

                _lastResponse.value = response.spokenText
                _hudStatus.value = "Hukam baja laya! 💖"

                // Execute all actions
                withContext(Dispatchers.Main) {
                    for (action in response.actions) {
                        executeAction(action)
                    }

                    // Speak in authentic clear Indian Hindi and automatically listen if continuous mode is active
                    speechManager.speak(response.spokenText) {
                        if (com.example.ai.ZoyaCompanionManager.isContinuousConversationEnabled(applicationContext) &&
                            !com.example.ai.ZoyaCompanionManager.isExitPhrase(command)
                        ) {
                            serviceScope.launch(Dispatchers.Main) {
                                delay(350)
                                startVoiceCommandFlow()
                            }
                        } else {
                            scheduleAutoDismiss(3500)
                        }
                    }
                }
            } catch (e: Exception) {
                val errorReply = "Aapka command execute karne me problem aayi. Dobara boliye!"
                _lastResponse.value = errorReply
                withContext(Dispatchers.Main) {
                    speechManager.speak(errorReply) {
                        scheduleAutoDismiss(3000)
                    }
                }
            }
        }
    }

    private fun executeAction(action: ParsedAction) {
        when (action.type) {
            "OPEN_APP" -> PhoneController.openApp(action.target, applicationContext)
            "CHANGE_WALLPAPER" -> PhoneController.changeWallpaper(action.target, applicationContext)
            "SEARCH_WEB" -> PhoneController.searchWeb(action.target, applicationContext)
            "SEARCH_YOUTUBE" -> PhoneController.searchYouTube(action.target, applicationContext)
            "SEARCH_SPOTIFY" -> PhoneController.playSpotify(action.target, applicationContext)
            "SEND_WHATSAPP" -> PhoneController.sendWhatsApp(action.target, action.message, applicationContext)
            "CALL_PHONE" -> PhoneController.callPhone(action.target, applicationContext)
            "SEND_SMS" -> PhoneController.sendSms(action.target, action.message, applicationContext)
            "SET_ALARM" -> PhoneController.setAlarm(action.hour, action.minute, action.message, applicationContext)
            "SET_TIMER" -> PhoneController.setTimer(action.seconds, action.message, applicationContext)
            "ADJUST_VOLUME" -> PhoneController.adjustVolume(action.target, applicationContext)
            "TOGGLE_FLASHLIGHT" -> {
                val enable = if (action.target.lowercase() == "on") true else if (action.target.lowercase() == "off") false else null
                PhoneController.toggleFlashlight(enable, applicationContext)
            }
            "OPEN_SETTINGS" -> PhoneController.openSettingsSection(action.target, applicationContext)
            "TRIGGER_VIBRATION" -> PhoneController.triggerVibration(if (action.seconds > 0) (action.seconds * 1000).toLong() else 400L, applicationContext)
            "GLOBAL_BACK" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "GLOBAL_HOME" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "GLOBAL_RECENTS" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "GLOBAL_NOTIFICATIONS" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "LOCK_SCREEN" -> PhoneController.lockScreen(applicationContext)
            "UNLOCK_SCREEN" -> PhoneController.unlockScreen(applicationContext)
            "CLICK_SCREEN" -> clickTextOnScreen(action.target)
            "SCROLL_DOWN" -> scrollDown()
            "SCROLL_UP" -> scrollUp()
            "TYPE_TEXT" -> typeTextIntoInput(action.target)
            "READ_SCREEN" -> {
                val summary = getVisibleScreenSummary()
                speechManager.speak("Screen par dikh raha hai: $summary")
            }
            "SAVE_MEMORY" -> {
                if (action.key.isNotBlank() && action.value.isNotBlank()) {
                    serviceScope.launch(Dispatchers.IO) {
                        repository.insertMemory(action.key, action.value, action.category)
                    }
                }
            }
            "SET_PATTERN" -> {
                val dots = action.target.split(",", " ", "-", ">").mapNotNull { it.trim().toIntOrNull() }.filter { it in 1..9 }
                if (dots.isNotEmpty()) {
                    com.example.device.SmartLockController.savePattern(applicationContext, dots)
                }
            }
            "SET_PIN" -> {
                val pin = action.target.filter { it.isDigit() }
                if (pin.isNotBlank()) {
                    com.example.device.SmartLockController.savePin(applicationContext, pin)
                }
            }
            "ORDER_ITEM" -> {
                val platform = if (action.platform.isNotBlank()) action.platform else "amazon"
                val item = if (action.item.isNotBlank()) action.item else action.target
                PhoneController.orderItem(platform, item, applicationContext)
            }
            "BOOK_TRAIN_TICKET" -> {
                val origin = if (action.origin.isNotBlank()) action.origin else "Ahmedabad"
                val destination = if (action.destination.isNotBlank()) action.destination else if (action.target.isNotBlank()) action.target else "Mumbai"
                val date = if (action.date.isNotBlank()) action.date else "today"
                val platform = if (action.platform.isNotBlank()) action.platform else "confirmtkt"
                PhoneController.bookTrainTicket(origin, destination, date, platform, applicationContext)
            }
        }
    }

    private fun scheduleAutoDismiss(delayMs: Long) {
        autoDismissJob?.cancel()
        autoDismissJob = serviceScope.launch {
            delay(delayMs)
            if (!speechManager.isSpeaking.value && !speechManager.isListening.value) {
                _isHudVisible.value = false
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isServiceActive.value = false
        speechManager.stopSpeaking()
        speechManager.stopListening()

        if (voiceHudView != null) {
            try {
                windowManager?.removeView(voiceHudView)
            } catch (e: Exception) {
                // ignore
            }
        }

        if (isUnlockReceiverRegistered) {
            try {
                unregisterReceiver(unlockReceiver)
            } catch (e: Exception) {
                // ignore
            }
            isUnlockReceiverRegistered = false
        }

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        serviceScope.cancel()
    }
}

@Composable
fun VoiceHudComponent(
    isVisible: Boolean,
    status: String,
    liveCommand: String,
    lastResponse: String?,
    isListening: Boolean,
    isSpeaking: Boolean,
    amplitude: Float,
    onMicClick: () -> Unit,
    onCloseClick: () -> Unit
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = DarkSurface.copy(alpha = 0.95f),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, if (isListening) RadiantCoral else CyberTeal),
                shadowElevation = 12.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(NeonPink, DeepViolet))),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("💖", fontSize = 16.sp)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Zoya Voice Access",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = status,
                                    fontSize = 11.sp,
                                    color = if (isListening) RadiantCoral else CyberTeal
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onMicClick,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isListening) RadiantCoral else DeepViolet)
                            ) {
                                Icon(
                                    imageVector = if (isListening) Icons.Rounded.Mic else Icons.Rounded.MicOff,
                                    contentDescription = "Mic",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(4.dp))

                            IconButton(
                                onClick = onCloseClick,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Close",
                                    tint = Color.Gray,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    // Live amplitude wave
                    if (isListening || isSpeaking) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            for (i in 0..11) {
                                val heightMultiplier = sin((i * 0.6f) + (amplitude * 8f)).coerceIn(0.2f, 1f)
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 2.dp)
                                        .width(3.dp)
                                        .height((6.dp + (22.dp * amplitude * heightMultiplier)).coerceIn(4.dp, 28.dp))
                                        .background(
                                            if (isListening) RadiantCoral else CyberTeal,
                                            RoundedCornerShape(2.dp)
                                        )
                                )
                            }
                        }
                    }

                    if (liveCommand.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = DarkSurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "🗣️ \"$liveCommand\"",
                                fontSize = 12.sp,
                                color = Color.White,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    if (lastResponse != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = lastResponse,
                            fontSize = 12.sp,
                            color = SunnyAmber,
                            fontWeight = FontWeight.Medium,
                            maxLines = 3
                        )
                    }
                }
            }
        }
    }
}
