package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.device.SmartLockController

/**
 * BroadcastReceiver triggered whenever the device is unlocked (fingerprint, pattern, PIN, swipe)
 * via system broadcast android.intent.action.USER_PRESENT.
 */
class ZoyaUnlockReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_USER_PRESENT) {
            Log.d("ZoyaUnlockReceiver", "Device unlocked (ACTION_USER_PRESENT received)")
            if (SmartLockController.isAutoListenOnUnlockEnabled(context)) {
                if (ZoyaAccessibilityService.isServiceActive.value) {
                    ZoyaAccessibilityService.triggerVoiceOnUnlock(context)
                } else if (ZoyaFloatingService.isServiceRunning.value) {
                    ZoyaFloatingService.triggerVoiceFromOutside(context)
                }
            }
        }
    }
}
