package com.example.service

import android.content.Intent
import android.service.voice.VoiceInteractionService

/**
 * Zoya Voice Interaction Service.
 * Registers Zoya as an official Default Digital Assistant on Android, allowing long-press Home button,
 * Power button shortcut, corner swipe gesture, or hardware trigger to launch Zoya instantly!
 */
class ZoyaVoiceInteractionService : VoiceInteractionService() {

    override fun onReady() {
        super.onReady()
    }

    override fun onShutdown() {
        super.onShutdown()
    }
}
