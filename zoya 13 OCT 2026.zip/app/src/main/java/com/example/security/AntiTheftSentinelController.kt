package com.example.security

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.SharedPreferences
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.device.PhoneController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.sqrt

object AntiTheftSentinelController {
    private const val TAG = "AntiTheftSentinel"
    private const val PREFS_NAME = "zoya_antitheft_prefs"
    private const val KEY_INCIDENTS_JSON = "key_incidents_json"
    private const val KEY_GUARD_ARMED = "key_guard_armed"
    private const val KEY_SENSITIVITY = "key_sensitivity"
    private const val SILENT_NOTIFICATION_CHANNEL_ID = "zoya_silent_intruder_channel"

    private val scope = CoroutineScope(Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _isArmed = MutableStateFlow(false)
    val isArmed: StateFlow<Boolean> = _isArmed.asStateFlow()

    private val _armCountdown = MutableStateFlow(0)
    val armCountdown: StateFlow<Int> = _armCountdown.asStateFlow()

    private val _incidents = MutableStateFlow<List<IntruderIncident>>(emptyList())
    val incidents: StateFlow<List<IntruderIncident>> = _incidents.asStateFlow()

    private val _unreviewedIncidents = MutableStateFlow<List<IntruderIncident>>(emptyList())
    val unreviewedIncidents: StateFlow<List<IntruderIncident>> = _unreviewedIncidents.asStateFlow()

    private val _hasUnreviewedIncident = MutableStateFlow(false)
    val hasUnreviewedIncident: StateFlow<Boolean> = _hasUnreviewedIncident.asStateFlow()

    private val _lastCapturedIncident = MutableStateFlow<IntruderIncident?>(null)
    val lastCapturedIncident: StateFlow<IntruderIncident?> = _lastCapturedIncident.asStateFlow()

    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null
    private var sensorListener: SensorEventListener? = null

    private var countdownJob: Job? = null
    private var lastTriggerTime: Long = 0L

    // Motion sensitivity: default delta threshold in m/s^2
    private var motionThreshold: Float = 1.9f

    // Low-pass filter baseline
    private var baselineMagnitude: Float = 9.8f
    private var isCalibrated: Boolean = false

    fun init(context: Context) {
        loadIncidents(context)
        createSilentNotificationChannel(context)
        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val wasArmed = prefs.getBoolean(KEY_GUARD_ARMED, false)
        if (wasArmed) {
            armGuard(context, countdownSeconds = 0)
        }
    }

    /**
     * Arms the Touch Guard.
     * countdownSeconds provides a delay (e.g. 5 seconds) so user can place phone down safely.
     */
    fun armGuard(context: Context, countdownSeconds: Int = 5) {
        countdownJob?.cancel()
        if (countdownSeconds <= 0) {
            activateSensors(context)
            _isArmed.value = true
            _armCountdown.value = 0
            saveArmedState(context, true)
            return
        }

        _armCountdown.value = countdownSeconds
        countdownJob = scope.launch {
            for (sec in countdownSeconds downTo 1) {
                _armCountdown.value = sec
                delay(1000)
            }
            _armCountdown.value = 0
            _isArmed.value = true
            saveArmedState(context, true)
            activateSensors(context)
        }
    }

    fun disarmGuard(context: Context) {
        countdownJob?.cancel()
        countdownJob = null
        _armCountdown.value = 0
        _isArmed.value = false
        saveArmedState(context, false)
        deactivateSensors()
    }

    private fun activateSensors(context: Context) {
        deactivateSensors()
        isCalibrated = false
        baselineMagnitude = 9.8f

        sensorListener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null || !_isArmed.value) return
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                val currentMag = sqrt(x * x + y * y + z * z)

                if (!isCalibrated) {
                    baselineMagnitude = currentMag
                    isCalibrated = true
                    return
                }

                // Calculate motion delta against baseline gravity
                val delta = kotlin.math.abs(currentMag - baselineMagnitude)
                // Smooth baseline update
                baselineMagnitude = baselineMagnitude * 0.9f + currentMag * 0.1f

                if (delta > motionThreshold) {
                    val now = System.currentTimeMillis()
                    // Throttle 5 seconds between triggers
                    if (now - lastTriggerTime > 5000L) {
                        lastTriggerTime = now
                        Log.i(TAG, "Unauthorized motion detected! Delta: $delta > Threshold: $motionThreshold")
                        triggerUnauthorizedTouch(
                            context = context,
                            triggerReason = "Unauthorized Touch / Physical Movement Detected"
                        )
                    }
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        sensorManager?.registerListener(
            sensorListener,
            accelerometer,
            SensorManager.SENSOR_DELAY_NORMAL
        )
        Log.i(TAG, "Anti-theft motion sensors activated")
    }

    private fun deactivateSensors() {
        sensorListener?.let {
            sensorManager?.unregisterListener(it)
        }
        sensorListener = null
    }

    /**
     * Executes the full Intruder Protocol:
     * 1. Silently captures photo using front camera
     * 2. Triggers silent covert alert (discreet haptic pulse + silent notification)
     * 3. Locks device screen immediately
     * 4. Saves incident record for user to review on return
     */
    fun triggerUnauthorizedTouch(
        context: Context,
        triggerReason: String = "Unauthorized Touch Detected"
    ) {
        Log.w(TAG, "TRIGGERING INTRUDER PROTOCOL: $triggerReason")

        // 1. Trigger Silent Alert (Discreet haptic pulse pattern + silent notification)
        executeSilentAlert(context, triggerReason)

        // 2. Instantly Lock Screen (Protects phone from unauthorized intruder)
        try {
            PhoneController.lockScreen(context)
        } catch (e: Exception) {
            Log.e(TAG, "Error locking screen", e)
        }

        // 3. Silent Front Camera Photo Capture
        SilentIntruderCameraCapture.captureFrontCameraSilently(context) { photoFile ->
            val incident = IntruderIncident(
                photoPath = photoFile?.absolutePath ?: "",
                triggerReason = triggerReason,
                isReviewed = false,
                lockExecuted = true,
                alertExecuted = true
            )

            scope.launch(Dispatchers.Main) {
                addIncident(context, incident)
                _lastCapturedIncident.value = incident
                _hasUnreviewedIncident.value = true
            }
        }
    }

    private fun executeSilentAlert(context: Context, reason: String) {
        try {
            // Discreet covert vibration pulse (Silent Alert)
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            val pattern = longArrayOf(0, 160, 120, 160, 120, 160)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, -1)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Vibrator error", e)
        }

        try {
            // Silent Covert Notification (Importance Low, no sound)
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            val notification = NotificationCompat.Builder(context, SILENT_NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("⚠️ Zoya Security Alert: Touch Detected!")
                .setContentText("Kisi ne phone chhua tha! Photo capture ho gayi aur screen lock ho gaya.")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setAutoCancel(true)
                .build()

            notificationManager?.notify(9901, notification)
        } catch (e: Exception) {
            Log.e(TAG, "Notification error", e)
        }
    }

    private fun createSilentNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Zoya Silent Security Alerts"
            val description = "Silent notifications for unauthorized touch & intruder captures"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(SILENT_NOTIFICATION_CHANNEL_ID, name, importance).apply {
                this.description = description
                enableVibration(false)
                setSound(null, null)
            }
            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    private fun addIncident(context: Context, incident: IntruderIncident) {
        val currentList = _incidents.value.toMutableList()
        currentList.add(0, incident)
        _incidents.value = currentList
        updateUnreviewedList()
        saveIncidentsToPrefs(context)
    }

    fun markAllIncidentsAsReviewed(context: Context) {
        val updated = _incidents.value.map { it.copy(isReviewed = true) }
        _incidents.value = updated
        _hasUnreviewedIncident.value = false
        _unreviewedIncidents.value = emptyList()
        saveIncidentsToPrefs(context)
    }

    fun deleteIncident(context: Context, id: String) {
        val current = _incidents.value.toMutableList()
        val toRemove = current.find { it.id == id }
        if (toRemove != null) {
            if (toRemove.photoPath.isNotEmpty()) {
                try {
                    File(toRemove.photoPath).delete()
                } catch (e: Exception) {
                    // ignore
                }
            }
            current.remove(toRemove)
            _incidents.value = current
            updateUnreviewedList()
            saveIncidentsToPrefs(context)
        }
    }

    fun clearAllIncidents(context: Context) {
        _incidents.value.forEach { incident ->
            if (incident.photoPath.isNotEmpty()) {
                try {
                    File(incident.photoPath).delete()
                } catch (e: Exception) {
                    // ignore
                }
            }
        }
        _incidents.value = emptyList()
        _unreviewedIncidents.value = emptyList()
        _hasUnreviewedIncident.value = false
        _lastCapturedIncident.value = null
        saveIncidentsToPrefs(context)
    }

    private fun updateUnreviewedList() {
        val unrev = _incidents.value.filter { !it.isReviewed }
        _unreviewedIncidents.value = unrev
        _hasUnreviewedIncident.value = unrev.isNotEmpty()
    }

    private fun saveArmedState(context: Context, armed: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_GUARD_ARMED, armed).apply()
    }

    private fun saveIncidentsToPrefs(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonArray = JSONArray()
        for (item in _incidents.value) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("timestamp", item.timestamp)
                put("photoPath", item.photoPath)
                put("triggerReason", item.triggerReason)
                put("isReviewed", item.isReviewed)
                put("lockExecuted", item.lockExecuted)
                put("alertExecuted", item.alertExecuted)
            }
            jsonArray.put(obj)
        }
        prefs.edit().putString(KEY_INCIDENTS_JSON, jsonArray.toString()).apply()
    }

    private fun loadIncidents(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_INCIDENTS_JSON, null) ?: return
        try {
            val jsonArray = JSONArray(jsonStr)
            val list = mutableListOf<IntruderIncident>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    IntruderIncident(
                        id = obj.optString("id"),
                        timestamp = obj.optLong("timestamp"),
                        photoPath = obj.optString("photoPath"),
                        triggerReason = obj.optString("triggerReason", "Unauthorized Touch"),
                        isReviewed = obj.optBoolean("isReviewed", false),
                        lockExecuted = obj.optBoolean("lockExecuted", true),
                        alertExecuted = obj.optBoolean("alertExecuted", true)
                    )
                )
            }
            _incidents.value = list
            updateUnreviewedList()
        } catch (e: Exception) {
            Log.e(TAG, "Error loading incidents JSON", e)
        }
    }
}
