package com.example.security

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SilentIntruderCameraCapture {
    private const val TAG = "SilentCameraCapture"

    /**
     * Captures a silent front camera photo and saves to app internal storage.
     * Invokes callback with the resulting File or fallback image file.
     */
    fun captureFrontCameraSilently(
        context: Context,
        onComplete: (photoFile: File?) -> Unit
    ) {
        val storageDir = File(context.filesDir, "intruder_captures").apply {
            if (!exists()) mkdirs()
        }
        val targetFile = File(storageDir, "intruder_${System.currentTimeMillis()}.jpg")

        val hasCameraPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasCameraPerm) {
            Log.w(TAG, "Camera permission not granted. Generating security log image.")
            val fallback = generateSecurityFallbackImage(targetFile, "Camera Permission Required")
            onComplete(fallback)
            return
        }

        try {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    val imageCapture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .setFlashMode(ImageCapture.FLASH_MODE_OFF)
                        .build()

                    val frontSelector = CameraSelector.Builder()
                        .requireLensFacing(CameraSelector.LENS_FACING_FRONT)
                        .build()

                    // Check if front camera is available on this device
                    if (!cameraProvider.hasCamera(frontSelector)) {
                        Log.w(TAG, "No front camera found. Generating security log image.")
                        val fallback = generateSecurityFallbackImage(targetFile, "Front Camera Not Present")
                        onComplete(fallback)
                        return@addListener
                    }

                    // Ephemeral custom lifecycle owner for silent one-shot background capture
                    val oneShotLifecycle = object : LifecycleOwner {
                        private val registry = LifecycleRegistry(this).apply {
                            currentState = Lifecycle.State.RESUMED
                        }
                        override val lifecycle: Lifecycle get() = registry

                        fun teardown() {
                            registry.currentState = Lifecycle.State.DESTROYED
                        }
                    }

                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        oneShotLifecycle,
                        frontSelector,
                        imageCapture
                    )

                    val outputOptions = ImageCapture.OutputFileOptions.Builder(targetFile).build()

                    // Timeout safety handler in case camera hardware hangs
                    val mainHandler = Handler(Looper.getMainLooper())
                    var isCompleted = false

                    val timeoutRunnable = Runnable {
                        if (!isCompleted) {
                            isCompleted = true
                            try {
                                cameraProvider.unbindAll()
                                oneShotLifecycle.teardown()
                            } catch (e: Exception) {
                                // ignore
                            }
                            if (!targetFile.exists() || targetFile.length() == 0L) {
                                val fallback = generateSecurityFallbackImage(targetFile, "Front Capture Hardware Timeout")
                                onComplete(fallback)
                            } else {
                                onComplete(targetFile)
                            }
                        }
                    }
                    mainHandler.postDelayed(timeoutRunnable, 4000)

                    imageCapture.takePicture(
                        outputOptions,
                        ContextCompat.getMainExecutor(context),
                        object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                if (isCompleted) return
                                isCompleted = true
                                mainHandler.removeCallbacks(timeoutRunnable)
                                try {
                                    cameraProvider.unbindAll()
                                    oneShotLifecycle.teardown()
                                } catch (e: Exception) {
                                    Log.e(TAG, "Error unbinding silent camera", e)
                                }
                                Log.i(TAG, "Front camera photo captured successfully: ${targetFile.absolutePath}")
                                onComplete(targetFile)
                            }

                            override fun onError(exception: ImageCaptureException) {
                                if (isCompleted) return
                                isCompleted = true
                                mainHandler.removeCallbacks(timeoutRunnable)
                                try {
                                    cameraProvider.unbindAll()
                                    oneShotLifecycle.teardown()
                                } catch (e: Exception) {
                                    // ignore
                                }
                                Log.e(TAG, "CameraX takePicture failed: ${exception.message}", exception)
                                val fallback = generateSecurityFallbackImage(targetFile, "Camera Hardware Error: ${exception.message}")
                                onComplete(fallback)
                            }
                        }
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to initialize CameraX silent capture", e)
                    val fallback = generateSecurityFallbackImage(targetFile, "Capture Error: ${e.message}")
                    onComplete(fallback)
                }
            }, ContextCompat.getMainExecutor(context))
        } catch (e: Exception) {
            Log.e(TAG, "ProcessCameraProvider error", e)
            val fallback = generateSecurityFallbackImage(targetFile, "Camera Provider Error: ${e.message}")
            onComplete(fallback)
        }
    }

    /**
     * Generates a forensic security badge image if hardware camera is not available.
     */
    private fun generateSecurityFallbackImage(file: File, detail: String): File {
        try {
            val width = 720
            val height = 960
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            // Dark sci-fi security sentinel canvas
            canvas.drawColor(Color.parseColor("#0D1117"))

            val paint = Paint().apply {
                isAntiAlias = true
            }

            // Top alert banner
            paint.color = Color.parseColor("#FF2A6D")
            paint.style = Paint.Style.FILL
            canvas.drawRect(0f, 0f, width.toFloat(), 180f, paint)

            // Header text
            paint.color = Color.WHITE
            paint.textSize = 42f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("⚠️ INTRUDER SECURITY ALERT", 40f, 80f, paint)

            paint.textSize = 28f
            paint.typeface = Typeface.DEFAULT
            canvas.drawText("UNAUTHORIZED TOUCH DETECTED", 40f, 130f, paint)

            // Center Camera Icon / Silhouette
            paint.color = Color.parseColor("#1F2937")
            canvas.drawCircle(width / 2f, 440f, 160f, paint)

            paint.color = Color.parseColor("#05D9E8")
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 6f
            canvas.drawCircle(width / 2f, 440f, 160f, paint)

            paint.style = Paint.Style.FILL
            paint.textSize = 80f
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("👤", width / 2f, 470f, paint)

            // Details and Forensic Timestamp
            paint.textAlign = Paint.Align.LEFT
            paint.color = Color.parseColor("#E0E6ED")
            paint.textSize = 30f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("Incident Telemetry Record:", 50f, 680f, paint)

            paint.typeface = Typeface.DEFAULT
            paint.textSize = 24f
            paint.color = Color.parseColor("#05D9E8")
            val timeStr = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.getDefault()).format(Date())
            canvas.drawText("Timestamp: $timeStr", 50f, 730f, paint)

            paint.color = Color.parseColor("#FF9F1C")
            canvas.drawText("Trigger: Physical Motion / Touch Sensor", 50f, 775f, paint)

            paint.color = Color.parseColor("#00FF66")
            canvas.drawText("Security Lock: Screen Instantly Locked", 50f, 820f, paint)

            paint.color = Color.parseColor("#8E9AAF")
            canvas.drawText("Note: $detail", 50f, 865f, paint)

            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
            }
            bitmap.recycle()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to write fallback image", e)
        }
        return file
    }
}
