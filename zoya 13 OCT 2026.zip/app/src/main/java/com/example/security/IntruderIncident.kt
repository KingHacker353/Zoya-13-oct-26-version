package com.example.security

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class IntruderIncident(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val photoPath: String = "",
    val triggerReason: String = "Unauthorized Touch / Motion",
    val isReviewed: Boolean = false,
    val lockExecuted: Boolean = true,
    val alertExecuted: Boolean = true
) {
    val formattedTime: String
        get() {
            return try {
                val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm:ss a", Locale.getDefault())
                sdf.format(Date(timestamp))
            } catch (e: Exception) {
                "$timestamp"
            }
        }
}
