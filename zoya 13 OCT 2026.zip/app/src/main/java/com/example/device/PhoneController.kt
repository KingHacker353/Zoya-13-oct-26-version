package com.example.device

import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.app.WallpaperManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.service.ZoyaAccessibilityService

data class ActionResult(
    val isSuccess: Boolean,
    val description: String,
    val detail: String = ""
)

object PhoneController {

    private val APP_PACKAGES = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "instagram" to listOf("com.instagram.android"),
        "youtube" to listOf("com.google.android.youtube"),
        "spotify" to listOf("com.spotify.music"),
        "maps" to listOf("com.google.android.apps.maps"),
        "google maps" to listOf("com.google.android.apps.maps"),
        "camera" to listOf("com.google.android.GoogleCamera", "com.android.camera"),
        "chrome" to listOf("com.android.chrome"),
        "browser" to listOf("com.android.chrome"),
        "clock" to listOf("com.google.android.deskclock", "com.android.deskclock"),
        "alarm" to listOf("com.google.android.deskclock", "com.android.deskclock"),
        "calculator" to listOf("com.google.android.calculator", "com.android.calculator2"),
        "contacts" to listOf("com.google.android.contacts", "com.android.contacts"),
        "settings" to listOf("com.android.settings"),
        "gallery" to listOf("com.google.android.apps.photos", "com.android.gallery3d"),
        "photos" to listOf("com.google.android.apps.photos", "com.android.gallery3d"),
        "phone" to listOf("com.google.android.dialer", "com.android.dialer"),
        "messages" to listOf("com.google.android.apps.messaging", "com.android.mms"),
        "play store" to listOf("com.android.vending"),
        "flipkart" to listOf("com.flipkart.android"),
        "amazon" to listOf("in.amazon.mShop.android.shopping", "com.amazon.mShop.android.shopping"),
        "zomato" to listOf("com.application.zomato"),
        "swiggy" to listOf("in.swiggy.android"),
        "twitter" to listOf("com.twitter.android"),
        "x" to listOf("com.twitter.android"),
        "facebook" to listOf("com.facebook.katana", "com.facebook.lite"),
        "netflix" to listOf("com.netflix.mediaclient"),
        "cricbuzz" to listOf("com.cricbuzz.android"),
        "hotstar" to listOf("in.startv.hotstar"),
        "disney" to listOf("in.startv.hotstar"),
        "myntra" to listOf("com.myntra.android"),
        "meesho" to listOf("com.meesho.supply"),
        "irctc" to listOf("cris.org.in.prs.ima"),
        "paytm" to listOf("net.one97.paytm"),
        "phonepe" to listOf("com.phonepe.app"),
        "gpay" to listOf("com.google.android.apps.nbu.paisa.user"),
        "google pay" to listOf("com.google.android.apps.nbu.paisa.user"),
        "telegram" to listOf("org.telegram.messenger"),
        "snapchat" to listOf("com.snapchat.android"),
        "linkedin" to listOf("com.linkedin.android"),
        "chatgpt" to listOf("com.openai.chatgpt"),
        "uber" to listOf("com.ubercab"),
        "ola" to listOf("com.olacabs.customer"),
        "jiocinema" to listOf("com.jio.media.ondemand"),
        "jio cinema" to listOf("com.jio.media.ondemand"),
        "zepto" to listOf("com.zepto.shopping"),
        "blinkit" to listOf("com.grofers.customerapp"),
        "bookmyshow" to listOf("com.bt.bms"),
        "makemytrip" to listOf("com.makemytrip"),
        "wikipedia" to listOf("org.wikipedia")
    )

    private val APP_DIRECT_URLS = mapOf(
        "flipkart" to "https://www.flipkart.com",
        "amazon" to "https://www.amazon.in",
        "zomato" to "https://www.zomato.com",
        "swiggy" to "https://www.swiggy.com",
        "instagram" to "https://www.instagram.com",
        "facebook" to "https://www.facebook.com",
        "twitter" to "https://www.twitter.com",
        "x" to "https://www.x.com",
        "youtube" to "https://www.youtube.com",
        "netflix" to "https://www.netflix.com",
        "spotify" to "https://open.spotify.com",
        "cricbuzz" to "https://www.cricbuzz.com",
        "hotstar" to "https://www.hotstar.com",
        "disney" to "https://www.hotstar.com",
        "myntra" to "https://www.myntra.com",
        "meesho" to "https://www.meesho.com",
        "irctc" to "https://www.irctc.co.in",
        "paytm" to "https://paytm.com",
        "phonepe" to "https://www.phonepe.com",
        "gpay" to "https://pay.google.com",
        "google pay" to "https://pay.google.com",
        "telegram" to "https://web.telegram.org",
        "snapchat" to "https://www.snapchat.com",
        "linkedin" to "https://www.linkedin.com",
        "chatgpt" to "https://chatgpt.com",
        "uber" to "https://m.uber.com",
        "ola" to "https://www.olacabs.com",
        "jiocinema" to "https://www.jiocinema.com",
        "jio cinema" to "https://www.jiocinema.com",
        "zepto" to "https://www.zeptonow.com",
        "blinkit" to "https://blinkit.com",
        "bookmyshow" to "https://in.bookmyshow.com",
        "makemytrip" to "https://www.makemytrip.com",
        "wikipedia" to "https://www.wikipedia.org",
        "pinterest" to "https://www.pinterest.com",
        "reddit" to "https://www.reddit.com",
        "quora" to "https://www.quora.com",
        "gmail" to "https://mail.google.com"
    )

    private var isTorchOn = false

    fun ensureFloatingAssistant(context: Context) {
        try {
            if (Settings.canDrawOverlays(context)) {
                com.example.service.ZoyaFloatingService.startService(context)
            }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun openApp(appName: String, context: Context): ActionResult {
        val cleanName = appName.lowercase()
            .replace(Regex("""(?i)\b(app|open|kholo|chalu|karo|chalao|laga|do|pe|par|zoya)\b"""), "")
            .trim()
            .ifBlank { appName.lowercase().trim() }

        val displayName = cleanName.replaceFirstChar { it.uppercase() }

        // Direct intent handling for system functions
        when {
            cleanName.contains("camera") -> {
                ensureFloatingAssistant(context)
                return openCamera(context)
            }
            cleanName.contains("setting") -> {
                ensureFloatingAssistant(context)
                return try {
                    val intent = Intent(Settings.ACTION_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult(true, "Settings khol diya! ⚙️")
                } catch (e: Exception) {
                    ActionResult(false, "Settings nahi khul paya: ${e.message}")
                }
            }
            cleanName.contains("contact") -> {
                ensureFloatingAssistant(context)
                return try {
                    val intent = Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult(true, "Contacts khol diya! 👥")
                } catch (e: Exception) {
                    ActionResult(false, "Contacts nahi khul paya: ${e.message}")
                }
            }
            cleanName.contains("alarm") || cleanName.contains("clock") -> {
                ensureFloatingAssistant(context)
                return try {
                    val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    ActionResult(true, "Clock & Alarms khol diya! ⏰")
                } catch (e: Exception) {
                    ActionResult(false, "Clock nahi khul paya: ${e.message}")
                }
            }
        }

        val pm = context.packageManager

        // 1. Check known candidate packages
        val packageCandidates = APP_PACKAGES[cleanName]
            ?: APP_PACKAGES.entries.find { cleanName.contains(it.key) || it.key.contains(cleanName) }?.value
            ?: listOf(cleanName)

        for (pkg in packageCandidates) {
            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                ensureFloatingAssistant(context)
                return ActionResult(
                    true,
                    "$displayName app khol diya hai! Zoya aapke sath hai, boliye ab isme kya karna hai! 🚀✨",
                    "App launched: $pkg"
                )
            }
        }

        // 2. Search all installed apps on device by label or package
        try {
            val installedApps = pm.getInstalledApplications(0)
            for (appInfo in installedApps) {
                val label = pm.getApplicationLabel(appInfo).toString().lowercase()
                val pkgName = appInfo.packageName.lowercase()
                if (label.contains(cleanName) || cleanName.contains(label) || pkgName.contains(cleanName)) {
                    val launchIntent = pm.getLaunchIntentForPackage(appInfo.packageName)
                    if (launchIntent != null) {
                        val appLabel = pm.getApplicationLabel(appInfo).toString()
                        launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        context.startActivity(launchIntent)
                        ensureFloatingAssistant(context)
                        return ActionResult(
                            true,
                            "$appLabel app khol diya hai! Zoya aapke sath screen par ready hai! 🚀✨",
                            "Installed app launched: ${appInfo.packageName}"
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // continue to web fallback
        }

        // 3. Fallback: App not installed on device!
        // Open official website or Google search directly so the user gets straight into the service!
        val matchedDirectUrl = APP_DIRECT_URLS[cleanName]
            ?: APP_DIRECT_URLS.entries.find { cleanName.contains(it.key) || it.key.contains(cleanName) }?.value

        return try {
            val targetUrl = matchedDirectUrl ?: "https://www.google.com/search?q=" + Uri.encode("$cleanName official website")
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(webIntent)
            ensureFloatingAssistant(context)

            val explanation = if (matchedDirectUrl != null) {
                "Aapke phone me $displayName app install nahi tha, isliye maine iski official website ($matchedDirectUrl) open kar di hai! Zoya aapke sath hai, boliye kya command follow karna hai! 🌐✨"
            } else {
                "Aapke phone me $displayName app install nahi tha, isliye maine Google par iski website open kar di hai! Zoya screen par ready hai, aap jo bolenge main execute karungi! 🌐✨"
            }
            ActionResult(true, explanation, "Web URL: $targetUrl")
        } catch (e: Exception) {
            ActionResult(false, "$displayName kholne me dikkat aayi: ${e.message}")
        }
    }

    fun resolvePhoneNumber(query: String, context: Context): String {
        val digitsOnly = query.filter { it.isDigit() || it == '+' }
        if (digitsOnly.length >= 7) return digitsOnly

        return try {
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            )
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf("%$query%")

            context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    if (numberIndex != -1) {
                        return cursor.getString(numberIndex)
                    }
                }
            }
            query
        } catch (e: Exception) {
            query
        }
    }

    fun sendWhatsApp(target: String, message: String, context: Context): ActionResult {
        return try {
            val resolvedTarget = resolvePhoneNumber(target, context)
            val cleanTarget = resolvedTarget.filter { it.isDigit() }

            // Trigger accessibility auto-clicker for WhatsApp send button!
            ZoyaAccessibilityService.triggerWhatsAppAutoSend()

            val uri = if (cleanTarget.isNotBlank() && cleanTarget.length >= 7) {
                val fullNumber = if (cleanTarget.length == 10) "91$cleanTarget" else cleanTarget
                Uri.parse("https://api.whatsapp.com/send?phone=$fullNumber&text=${Uri.encode(message)}")
            } else {
                Uri.parse("https://api.whatsapp.com/send?text=${Uri.encode(message)}")
            }

            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                `package` = "com.whatsapp"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                val fallbackIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(fallbackIntent)
            }

            ActionResult(true, "$target ko WhatsApp par message send kar diya! 💬🚀", "Target: $target | Message: $message")
        } catch (e: Exception) {
            ActionResult(false, "WhatsApp message send nahi ho paya: ${e.message}")
        }
    }

    fun callPhone(contactOrNumber: String, context: Context): ActionResult {
        return try {
            val resolvedNumber = resolvePhoneNumber(contactOrNumber, context)
            val cleanNumber = resolvedNumber.filter { it.isDigit() || it == '+' }

            if (cleanNumber.isNotBlank()) {
                val hasCallPermission = ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.CALL_PHONE
                ) == PackageManager.PERMISSION_GRANTED

                if (hasCallPermission) {
                    val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$cleanNumber")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(callIntent)
                    ActionResult(true, "$contactOrNumber ko direct call laga diya hai! 📞⚡", "Called: $cleanNumber")
                } else {
                    val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanNumber")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(dialIntent)
                    ActionResult(true, "$contactOrNumber ko phone par dial kar diya! 📞", "Dialed: $contactOrNumber")
                }
            } else {
                val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(dialIntent)
                ActionResult(true, "Phone dialer khol diya! 📞")
            }
        } catch (e: Exception) {
            ActionResult(false, "Call connect nahi ho payi: ${e.message}")
        }
    }

    fun sendSms(contactOrNumber: String, message: String, context: Context): ActionResult {
        return try {
            val cleanNumber = contactOrNumber.filter { it.isDigit() || it == '+' }
            val uri = Uri.parse("smsto:${if (cleanNumber.isNotBlank()) cleanNumber else ""}")
            val smsIntent = Intent(Intent.ACTION_SENDTO, uri).apply {
                putExtra("sms_body", message)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(smsIntent)
            ActionResult(true, "$contactOrNumber ko SMS draft kar diya! 📩", "SMS: $message")
        } catch (e: Exception) {
            ActionResult(false, "SMS bhejne me error: ${e.message}")
        }
    }

    fun searchYouTube(query: String, context: Context): ActionResult {
        val cleanQuery = query.replace(Regex("""(?i)\b(youtube|kholo|chalao|chala|play|search|video|baja|bajao|open|par|pe|lagao|gaana|song)\b"""), " ").trim()
        val searchQuery = if (cleanQuery.isBlank()) "trending songs" else cleanQuery

        // 1. Arm Zoya Accessibility Service to auto-click the first video as soon as search results load!
        ZoyaAccessibilityService.triggerYouTubeAutoPlay()

        // 2. Try Media Play From Search intent (official Android media playback from search)
        try {
            val playMediaIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                `package` = "com.google.android.youtube"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                putExtra(SearchManager.QUERY, searchQuery)
            }
            context.startActivity(playMediaIntent)
            ensureFloatingAssistant(context)
            return ActionResult(true, "YouTube par '$searchQuery' search karke video playback start kar diya! 🎬🍿", "Auto Play: $searchQuery")
        } catch (e: Exception) {
            // If explicit media play intent fails, proceed to search results + auto-clicker
        }

        return try {
            val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(searchQuery)}")
            
            // Try explicit YouTube app search
            val appIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                `package` = "com.google.android.youtube"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            try {
                context.startActivity(appIntent)
                ensureFloatingAssistant(context)
                ActionResult(true, "YouTube par '$searchQuery' search karke playback start kar diya! 🎬🍿", "App Playback: $searchQuery")
            } catch (e: Exception) {
                // If YouTube app not installed, open via browser
                val generalIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(generalIntent)
                ensureFloatingAssistant(context)
                ActionResult(true, "YouTube par '$searchQuery' khol kar video playback shuru kar diya! 🎬🍿", "Web Playback: $searchQuery")
            }
        } catch (e: Exception) {
            ActionResult(false, "YouTube open nahi ho paya: ${e.message}")
        }
    }

    fun playSpotify(query: String, context: Context): ActionResult {
        val cleanQuery = query.replace(Regex("""(?i)\b(spotify|gaana|baja|chala|play|song|music|sunao)\b"""), " ").trim()
        val songName = if (cleanQuery.isBlank()) "top hits" else cleanQuery
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(songName)}")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "Spotify par '$songName' chala diya! 🎵")
        } catch (e: Exception) {
            // Fallback to YouTube
            searchYouTube(songName, context)
        }
    }

    fun openCamera(context: Context): ActionResult {
        return try {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "Camera khol diya! Smile please! 📸")
        } catch (e: Exception) {
            // Fallback to generic camera package
            try {
                val launchIntent = context.packageManager.getLaunchIntentForPackage("com.google.android.GoogleCamera")
                    ?: context.packageManager.getLaunchIntentForPackage("com.android.camera")
                if (launchIntent != null) {
                    launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    context.startActivity(launchIntent)
                    ActionResult(true, "Camera open kar diya! 📸")
                } else {
                    ActionResult(false, "Camera app nahi mila")
                }
            } catch (ex: Exception) {
                ActionResult(false, "Camera open nahi ho saka: ${ex.message}")
            }
        }
    }

    fun setAlarm(hour: Int, minute: Int, message: String, context: Context): ActionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message.ifEmpty { "Zoya Reminder" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "$hour:${minute.toString().padStart(2, '0')} ka alarm laga diya! ⏰", "Alarm: $message")
        } catch (e: Exception) {
            ActionResult(false, "Alarm lagane me problem hui: ${e.message}")
        }
    }

    fun setTimer(seconds: Int, message: String, context: Context): ActionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message.ifEmpty { "Zoya Timer" })
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            val minText = if (seconds >= 60) "${seconds / 60} minute" else "$seconds second"
            ActionResult(true, "$minText ka timer laga diya! ⏳", "Timer: $message")
        } catch (e: Exception) {
            ActionResult(false, "Timer set nahi ho paya: ${e.message}")
        }
    }

    fun adjustVolume(action: String, context: Context): ActionResult {
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

            when (action.lowercase()) {
                "up", "increase" -> {
                    audioManager.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_RAISE,
                        AudioManager.FLAG_SHOW_UI
                    )
                    ActionResult(true, "Volume badha diya! 🔊")
                }
                "down", "decrease" -> {
                    audioManager.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_SHOW_UI
                    )
                    ActionResult(true, "Volume kam kar diya! 🔉")
                }
                "mute" -> {
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                    ActionResult(true, "Mute kar diya! 🔇")
                }
                "max" -> {
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxVol, AudioManager.FLAG_SHOW_UI)
                    ActionResult(true, "Volume full max kar diya! 🔊💥")
                }
                else -> {
                    val targetPercent = action.filter { it.isDigit() }.toIntOrNull()
                    if (targetPercent != null) {
                        val level = (targetPercent * maxVol) / 100
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, level, AudioManager.FLAG_SHOW_UI)
                        ActionResult(true, "Volume $targetPercent% par set kar diya! 🎵")
                    } else {
                        ActionResult(true, "Current volume: ${(currentVol * 100) / maxVol}%")
                    }
                }
            }
        } catch (e: Exception) {
            ActionResult(false, "Volume change nahi ho paya: ${e.message}")
        }
    }

    fun toggleFlashlight(enable: Boolean?, context: Context): ActionResult {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: "0"

            val targetState = enable ?: !isTorchOn
            cameraManager.setTorchMode(cameraId, targetState)
            isTorchOn = targetState

            val msg = if (targetState) "Flashlight on kar diya! 💡✨" else "Flashlight off kar diya! 🔦"
            ActionResult(true, msg)
        } catch (e: CameraAccessException) {
            ActionResult(false, "Torch access fail: ${e.message}")
        } catch (e: Exception) {
            ActionResult(false, "Flashlight toggle error: ${e.message}")
        }
    }

    /**
     * Change phone wallpaper with dynamic HD aesthetic gradient or color theme!
     */
    fun changeWallpaper(theme: String, context: Context): ActionResult {
        return try {
            val wallpaperManager = WallpaperManager.getInstance(context)
            val width = 1080
            val height = 2400
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            val lowerTheme = theme.lowercase().trim()
            val (color1, color2, color3) = when {
                lowerTheme.contains("pink") || lowerTheme.contains("romantic") || lowerTheme.contains("love") || lowerTheme.contains("cute") ->
                    Triple(Color.parseColor("#FF1493"), Color.parseColor("#8A2BE2"), Color.parseColor("#1A0B2E"))
                lowerTheme.contains("blue") || lowerTheme.contains("cyber") || lowerTheme.contains("neon") ->
                    Triple(Color.parseColor("#00F0FF"), Color.parseColor("#0D1B2A"), Color.parseColor("#000814"))
                lowerTheme.contains("dark") || lowerTheme.contains("black") || lowerTheme.contains("amoled") ->
                    Triple(Color.parseColor("#1C1C1E"), Color.parseColor("#0A0A0A"), Color.parseColor("#000000"))
                lowerTheme.contains("sunset") || lowerTheme.contains("gold") || lowerTheme.contains("orange") ->
                    Triple(Color.parseColor("#FF512F"), Color.parseColor("#DD2476"), Color.parseColor("#1B1464"))
                lowerTheme.contains("nature") || lowerTheme.contains("green") ->
                    Triple(Color.parseColor("#11998E"), Color.parseColor("#38EF7D"), Color.parseColor("#051923"))
                lowerTheme.contains("galaxy") || lowerTheme.contains("space") || lowerTheme.contains("purple") ->
                    Triple(Color.parseColor("#654EA3"), Color.parseColor("#EAAFC8"), Color.parseColor("#120E43"))
                else ->
                    Triple(Color.parseColor("#FF2A85"), Color.parseColor("#7928CA"), Color.parseColor("#0A0118"))
            }

            val shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(color1, color2, color3),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            val paint = Paint().apply {
                this.shader = shader
            }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

            // Draw artistic subtle glowing orb circles
            val circlePaint = Paint().apply {
                color = Color.WHITE
                alpha = 30
                style = Paint.Style.FILL
            }
            canvas.drawCircle(width * 0.3f, height * 0.25f, 350f, circlePaint)
            canvas.drawCircle(width * 0.8f, height * 0.7f, 450f, circlePaint)

            wallpaperManager.setBitmap(bitmap)
            ActionResult(true, "Aapke phone ka wallpaper ekdum stylish '$theme' theme me change kar diya! 🎨✨", "Wallpaper: $theme")
        } catch (e: Exception) {
            ActionResult(false, "Wallpaper change nahi ho paya: ${e.message}")
        }
    }

    /**
     * Search Google/Web
     */
    fun searchWeb(query: String, context: Context): ActionResult {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "Google par '$query' search kar diya! 🔍", "Search: $query")
        } catch (e: Exception) {
            ActionResult(false, "Web search error: ${e.message}")
        }
    }

    /**
     * Open specific settings page (WiFi, Bluetooth, Display, Sound, Battery, Apps)
     */
    fun openSettingsSection(section: String, context: Context): ActionResult {
        return try {
            val clean = section.lowercase().trim()
            val action = when {
                clean.contains("wifi") || clean.contains("wi-fi") || clean.contains("internet") -> Settings.ACTION_WIFI_SETTINGS
                clean.contains("bluetooth") -> Settings.ACTION_BLUETOOTH_SETTINGS
                clean.contains("display") || clean.contains("brightness") -> Settings.ACTION_DISPLAY_SETTINGS
                clean.contains("sound") || clean.contains("volume") || clean.contains("ringtone") -> Settings.ACTION_SOUND_SETTINGS
                clean.contains("battery") -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                clean.contains("app") -> Settings.ACTION_APPLICATION_SETTINGS
                clean.contains("wallpaper") -> Settings.ACTION_DISPLAY_SETTINGS
                clean.contains("location") || clean.contains("gps") -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            val intent = Intent(action).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "$section settings open kar diya! ⚙️", "Settings: $section")
        } catch (e: Exception) {
            ActionResult(false, "Settings open karne me error: ${e.message}")
        }
    }

    /**
     * Trigger haptic feedback / vibration
     */
    fun triggerVibration(durationMs: Long = 300, context: Context): ActionResult {
        return try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(durationMs)
            }
            ActionResult(true, "Phone vibrate kiya! 📳")
        } catch (e: Exception) {
            ActionResult(false, "Vibration failed: ${e.message}")
        }
    }

    /**
     * Lock device screen immediately
     */
    fun lockScreen(context: Context): ActionResult {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val locked = ZoyaAccessibilityService.performGlobal(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                if (locked) {
                    ActionResult(true, "Screen ko turant lock kar diya! 🔒")
                } else {
                    if (!ZoyaAccessibilityService.isAccessibilityEnabled(context)) {
                        ActionResult(false, "Screen lock karne ke liye Zoya Accessibility Service ON hona zaroori hai. Kripya Accessibility me Zoya ko ON karein. 🔒")
                    } else {
                        ActionResult(true, "Screen lock command bhej diya! 🔒")
                    }
                }
            } else {
                ActionResult(false, "Screen lock Android 9+ par supported hai.")
            }
        } catch (e: Exception) {
            ActionResult(false, "Screen lock failed: ${e.message}")
        }
    }

    /**
     * Wake up and unlock device screen (Pattern Lock, PIN, or Swipe)
     */
    fun unlockScreen(context: Context): ActionResult {
        return try {
            val savedPattern = SmartLockController.getSavedPattern(context)
            val savedPin = SmartLockController.getSavedPin(context)

            if (savedPattern.isNotEmpty()) {
                ZoyaAccessibilityService.unlockDeviceWithPattern(savedPattern)
                ActionResult(
                    true,
                    "Screen wake karke aapka pattern lock (${savedPattern.joinToString("->")}) draw kar diya aur phone unlock kar diya! 🔓✨",
                    "Pattern: ${savedPattern.joinToString(",")}"
                )
            } else if (savedPin.isNotBlank()) {
                ZoyaAccessibilityService.unlockDeviceWithPin(savedPin)
                ActionResult(
                    true,
                    "Screen wake karke aapka PIN daal kar phone unlock kar diya! 🔓✨",
                    "PIN unlock"
                )
            } else {
                SmartLockController.wakeUpScreen(context)
                ZoyaAccessibilityService.swipeUpToUnlock()
                ActionResult(
                    true,
                    "Screen wake karke unlock swipe kar diya! 🔓 Agar aapka pattern lock hai, to boliye 'Zoya mera pattern hai 1 2 3 5 9' ya Settings me pattern save kar lijiye, fir Zoya khud pattern draw karegi!",
                    "Standard swipe unlock"
                )
            }
        } catch (e: Exception) {
            ActionResult(false, "Screen unlock failed: ${e.message}")
        }
    }

    /**
     * Automated Ordering for food, grocery and shopping:
     * Amazon, Flipkart, Meesho, Zomato, Swiggy, Blinkit, Zepto, etc.
     */
    fun getOrderUrl(platform: String, item: String): String {
        val cleanPlatform = platform.lowercase().trim()
        val cleanItem = item.trim()
        val encodedQuery = Uri.encode(cleanItem)
        return when {
            cleanPlatform.contains("zomato") || cleanPlatform.contains("zomoto") -> "https://www.zomato.com/search?q=$encodedQuery"
            cleanPlatform.contains("swiggy") || cleanPlatform.contains("swigi") -> "https://www.swiggy.com/search?query=$encodedQuery"
            cleanPlatform.contains("blinkit") || cleanPlatform.contains("blikit") -> "https://blinkit.com/s/?q=$encodedQuery"
            cleanPlatform.contains("zepto") -> "https://www.zeptonow.com/search?q=$encodedQuery"
            cleanPlatform.contains("amazon") -> "https://www.amazon.in/s?k=$encodedQuery"
            cleanPlatform.contains("flipkart") -> "https://www.flipkart.com/search?q=$encodedQuery"
            cleanPlatform.contains("meesho") -> "https://www.meesho.com/search?q=$encodedQuery"
            cleanPlatform.contains("myntra") -> "https://www.myntra.com/$encodedQuery"
            else -> "https://www.google.com/search?q=" + Uri.encode("$cleanItem order online on $cleanPlatform")
        }
    }

    fun getTrainUrl(origin: String, destination: String, date: String, platform: String): String {
        val cleanOrigin = origin.trim().ifBlank { "Ahmedabad" }
        val cleanDest = destination.trim().ifBlank { "Mumbai" }
        val cleanDate = date.trim()
        val cleanPlatform = platform.lowercase().trim()
        val encodedOrigin = Uri.encode(cleanOrigin)
        val encodedDest = Uri.encode(cleanDest)
        val encodedDate = Uri.encode(cleanDate)
        return when {
            cleanPlatform.contains("irctc") -> "https://www.irctc.co.in/nget/train-search"
            cleanPlatform.contains("makemytrip") -> "https://www.makemytrip.com/railways/listing?srcStn=$encodedOrigin&destStn=$encodedDest&date=$encodedDate"
            cleanPlatform.contains("ixigo") -> "https://www.ixigo.com/trains/$encodedOrigin-to-$encodedDest-trains"
            else -> "https://www.confirmtkt.com/rts/trains?fromStationCode=$encodedOrigin&toStationCode=$encodedDest&dateOfJourney=$encodedDate"
        }
    }

    fun orderItem(platform: String, item: String, context: Context): ActionResult {
        ensureFloatingAssistant(context)
        val cleanPlatform = platform.lowercase().trim()
        val cleanItem = item.trim()
        val displayName = cleanPlatform.replaceFirstChar { it.uppercase() }
        val encodedQuery = Uri.encode(cleanItem)

        val (targetUrl, candidatePackages) = when {
            cleanPlatform.contains("zomato") || cleanPlatform.contains("zomoto") -> Pair(
                "https://www.zomato.com/search?q=$encodedQuery",
                listOf("com.application.zomato")
            )
            cleanPlatform.contains("swiggy") || cleanPlatform.contains("swigi") -> Pair(
                "https://www.swiggy.com/search?query=$encodedQuery",
                listOf("in.swiggy.android")
            )
            cleanPlatform.contains("blinkit") || cleanPlatform.contains("blikit") -> Pair(
                "https://blinkit.com/s/?q=$encodedQuery",
                listOf("com.grofers.customerapp")
            )
            cleanPlatform.contains("zepto") -> Pair(
                "https://www.zeptonow.com/search?q=$encodedQuery",
                listOf("com.zepto.shopping")
            )
            cleanPlatform.contains("amazon") -> Pair(
                "https://www.amazon.in/s?k=$encodedQuery",
                listOf("in.amazon.mShop.android.shopping", "com.amazon.mShop.android.shopping")
            )
            cleanPlatform.contains("flipkart") -> Pair(
                "https://www.flipkart.com/search?q=$encodedQuery",
                listOf("com.flipkart.android")
            )
            cleanPlatform.contains("meesho") -> Pair(
                "https://www.meesho.com/search?q=$encodedQuery",
                listOf("com.meesho.supply")
            )
            cleanPlatform.contains("myntra") -> Pair(
                "https://www.myntra.com/$encodedQuery",
                listOf("com.myntra.android")
            )
            else -> Pair(
                "https://www.google.com/search?q=" + Uri.encode("$cleanItem order online on $cleanPlatform"),
                listOf(cleanPlatform)
            )
        }

        val pm = context.packageManager
        // 1. Try launching native app with search view
        for (pkg in candidatePackages) {
            try {
                val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                    setPackage(pkg)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (appIntent.resolveActivity(pm) != null) {
                    context.startActivity(appIntent)
                    return ActionResult(
                        true,
                        "$displayName par '$cleanItem' ka order khol diya hai! Aapka login profile aur address already saved hai, Zoya screen par ready hai! 🛒✨",
                        "App launched: $pkg"
                    )
                }
            } catch (_: Exception) {}

            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                return ActionResult(
                    true,
                    "$displayName app khol diya hai! Search me '$cleanItem' open ho raha hai, aapka address aur account already saved hai! 🛒✨",
                    "App launched: $pkg"
                )
            }
        }

        // 2. Open official web storefront with direct search
        return try {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(webIntent)
            ActionResult(
                true,
                "$displayName par '$cleanItem' ka order khol diya hai! Aapka account aur address already saved hai! 🛍️✨",
                "Web search: $targetUrl"
            )
        } catch (e: Exception) {
            ActionResult(false, "Order page nahi khul paya: ${e.message}")
        }
    }

    /**
     * Automated Train Ticket Booking:
     * ConfirmTkt, IRCTC Connect, MakeMyTrip, Ixigo
     */
    fun bookTrainTicket(origin: String, destination: String, date: String, platform: String, context: Context): ActionResult {
        ensureFloatingAssistant(context)
        val cleanOrigin = origin.trim().ifBlank { "Ahmedabad" }
        val cleanDest = destination.trim().ifBlank { "Mumbai" }
        val cleanDate = date.trim()
        val cleanPlatform = platform.lowercase().trim()

        val encodedOrigin = Uri.encode(cleanOrigin)
        val encodedDest = Uri.encode(cleanDest)
        val encodedDate = Uri.encode(cleanDate)

        val (targetUrl, candidatePackages) = when {
            cleanPlatform.contains("irctc") -> Pair(
                "https://www.irctc.co.in/nget/train-search",
                listOf("cris.org.in.prs.ima")
            )
            cleanPlatform.contains("makemytrip") -> Pair(
                "https://www.makemytrip.com/railways/listing?srcStn=$encodedOrigin&destStn=$encodedDest&date=$encodedDate",
                listOf("com.makemytrip")
            )
            cleanPlatform.contains("ixigo") -> Pair(
                "https://www.ixigo.com/trains/$encodedOrigin-to-$encodedDest-trains",
                listOf("com.ixigo.train.ixigotrain")
            )
            else -> Pair(
                // ConfirmTkt is the fastest & smoothest user experience for Indian train search & IRCTC booking
                "https://www.confirmtkt.com/rts/trains?fromStationCode=$encodedOrigin&toStationCode=$encodedDest&dateOfJourney=$encodedDate",
                listOf("com.confirmtkt.lite", "cris.org.in.prs.ima")
            )
        }

        val pm = context.packageManager
        for (pkg in candidatePackages) {
            try {
                val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                    setPackage(pkg)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (appIntent.resolveActivity(pm) != null) {
                    context.startActivity(appIntent)
                    return ActionResult(
                        true,
                        "$cleanOrigin se $cleanDest ki train tickets booking open kar di hai! Aapka IRCTC login aur profile already saved hai, bas train chun kar confirm kijiye! 🚆🎫✨",
                        "App launched: $pkg"
                    )
                }
            } catch (_: Exception) {}

            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                return ActionResult(
                    true,
                    "Train booking app khol diya hai! $cleanOrigin se $cleanDest ki trains search ho rahi hain. Aapki saved IRCTC details ke sath ready hai! 🚆🎫✨",
                    "App launched: $pkg"
                )
            }
        }

        return try {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(webIntent)
            ActionResult(
                true,
                "$cleanOrigin se $cleanDest ke liye train tickets search aur booking page khol diya hai! Aapka naam aur login profile already saved hai, direct ticket confirm kijiye! 🚆🎫✨",
                "Web booking: $targetUrl"
            )
        } catch (e: Exception) {
            ActionResult(false, "Train booking page nahi khul paya: ${e.message}")
        }
    }
}
