package com.example.device

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.view.WindowManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class LockSecurityState(
    val isDeviceSecure: Boolean = true,
    val isKeyguardLocked: Boolean = false,
    val smartWakeActive: Boolean = true,
    val savedPattern: List<Int> = emptyList(),
    val savedPin: String = "",
    val autoListenOnUnlock: Boolean = true,
    val securityLevelText: String = "Biometric / PIN Protected",
    val lockMethod: String = "Pattern / PIN / Biometric",
    val statusMessage: String = "Smart Lock Sentinel Active"
)

object SmartLockController {
    private const val PREFS_NAME = "zoya_security_prefs"
    private const val KEY_UNLOCK_PATTERN = "key_unlock_pattern"
    private const val KEY_UNLOCK_PIN = "key_unlock_pin"
    private const val KEY_AUTO_LISTEN_ON_UNLOCK = "key_auto_listen_on_unlock"

    private val _state = MutableStateFlow(LockSecurityState())
    val state: StateFlow<LockSecurityState> = _state.asStateFlow()

    fun inspectLockState(context: Context) {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val isSecure = km?.isDeviceSecure ?: true
        val isLocked = km?.isKeyguardLocked ?: false
        val pattern = getSavedPattern(context)
        val pin = getSavedPin(context)
        val autoListen = isAutoListenOnUnlockEnabled(context)

        _state.value = _state.value.copy(
            isDeviceSecure = isSecure,
            isKeyguardLocked = isLocked,
            savedPattern = pattern,
            savedPin = pin,
            autoListenOnUnlock = autoListen,
            securityLevelText = if (pattern.isNotEmpty()) {
                "Pattern Auto-Unlock Active (${pattern.joinToString("->")})"
            } else if (pin.isNotBlank()) {
                "PIN Auto-Unlock Active"
            } else if (isSecure) {
                "Hardware Secured (Pattern / PIN not configured in Zoya)"
            } else {
                "Swipe / Unsecured"
            },
            statusMessage = if (pattern.isNotEmpty()) "Pattern Lock Configured (${pattern.joinToString("->")})" else if (isLocked) "Device is Locked" else "Device Ready"
        )
    }

    fun isAutoListenOnUnlockEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_AUTO_LISTEN_ON_UNLOCK, true)
    }

    fun setAutoListenOnUnlock(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_AUTO_LISTEN_ON_UNLOCK, enabled).apply()
        _state.value = _state.value.copy(
            autoListenOnUnlock = enabled,
            statusMessage = if (enabled) "Phone unlock hone par Voice Listening chalu hai 🎤🔓" else "Voice Listening on Unlock band hai"
        )
    }

    fun getSavedPattern(context: Context): List<Int> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_UNLOCK_PATTERN, "") ?: ""
        return raw.split(",", " ", "-").mapNotNull { it.trim().toIntOrNull() }.filter { it in 1..9 }
    }

    fun savePattern(context: Context, pattern: List<Int>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val filtered = pattern.filter { it in 1..9 }
        prefs.edit().putString(KEY_UNLOCK_PATTERN, filtered.joinToString(",")).apply()
        _state.value = _state.value.copy(
            savedPattern = filtered,
            statusMessage = "Pattern Lock Saved: ${filtered.joinToString(" -> ")}"
        )
    }

    fun clearPattern(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_UNLOCK_PATTERN).apply()
        _state.value = _state.value.copy(
            savedPattern = emptyList(),
            statusMessage = "Pattern Lock Cleared"
        )
    }

    fun getSavedPin(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_UNLOCK_PIN, "") ?: ""
    }

    fun savePin(context: Context, pin: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_UNLOCK_PIN, pin.trim()).apply()
        _state.value = _state.value.copy(
            savedPin = pin.trim(),
            statusMessage = "PIN Saved"
        )
    }

    fun clearPin(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_UNLOCK_PIN).apply()
        _state.value = _state.value.copy(
            savedPin = "",
            statusMessage = "PIN Cleared"
        )
    }

    /**
     * Wakes up the screen immediately
     */
    fun wakeUpScreen(context: Context): ActionResult {
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val wakeLock = pm?.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "Zoya:SmartWakeLock"
            )
            wakeLock?.acquire(3000L) // Release automatically after 3s
            ActionResult(true, "Screen ko turant wake up (on) kar diya! 💡⚡")
        } catch (e: Exception) {
            ActionResult(false, "Screen wake failed: ${e.message}")
        }
    }

    /**
     * Requests Keyguard dismiss (prompts for PIN/Fingerprint or dismisses if not secure)
     */
    fun requestUnlockPrompt(activity: Activity?): ActionResult {
        if (activity == null) {
            return ActionResult(false, "Activity context unavailable")
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val km = activity.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
                km?.requestDismissKeyguard(activity, object : KeyguardManager.KeyguardDismissCallback() {
                    override fun onDismissSucceeded() {
                        _state.value = _state.value.copy(isKeyguardLocked = false, statusMessage = "Device Successfully Unlocked! 🔓")
                    }

                    override fun onDismissCancelled() {
                        _state.value = _state.value.copy(statusMessage = "Unlock prompt cancelled by user")
                    }

                    override fun onDismissError() {
                        _state.value = _state.value.copy(statusMessage = "Keyguard dismiss error")
                    }
                })
                ActionResult(true, "Unlock prompt screen par display kar diya! 🔓")
            } else {
                @Suppress("DEPRECATION")
                activity.window.addFlags(
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                )
                ActionResult(true, "Keyguard dismiss flags applied! 🔓")
            }
        } catch (e: Exception) {
            ActionResult(false, "Unlock request failed: ${e.message}")
        }
    }
}
