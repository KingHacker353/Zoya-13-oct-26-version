package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VoiceChat
import androidx.compose.material.icons.rounded.Yard
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.islamic.AyatDetail
import com.example.data.islamic.DuaItem
import com.example.data.islamic.FatwaItem
import com.example.data.islamic.HadithItem
import com.example.data.islamic.IslamicRepository
import com.example.data.islamic.KalimaItem
import com.example.data.islamic.NaatItem
import com.example.data.islamic.ShayariItem
import com.example.data.islamic.SurahInfo
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MagentaRose
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SunnyAmber

// Islamic Palette Accents
val IslamicEmerald = Color(0xFF00B894)
val IslamicEmeraldDark = Color(0xFF054D3B)
val IslamicGold = Color(0xFFFFD166)
val IslamicGoldMuted = Color(0xFFB4975A)
val DeepMidnight = Color(0xFF0A0E17)
val CardBackground = Color(0xFF131A26)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IslamicHubSheet(
    onDismiss: () -> Unit,
    sheetState: SheetState,
    onReciteText: (String) -> Unit,
    onStopSpeaking: () -> Unit,
    isSpeaking: Boolean,
    onAskZoya: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabTitles = listOf(
        "🌹 कलाम-ए-रज़ा",
        "📜 हदीस-ए-पाक",
        "⚖️ फ़तावा रज़विय्या",
        "📖 क़ुरआन मजीद",
        "🌺 नात शरीफ़",
        "✒️ शायरी",
        "🤲 दुआ व तस्बीह"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DeepMidnight,
        dragHandle = null,
        modifier = modifier.testTag("islamic_hub_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 16.dp)
        ) {
            // Header with Islamic Motif
            Surface(
                color = CardBackground,
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(IslamicEmerald, IslamicGold)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🕌",
                                fontSize = 22.sp
                            )
                        }
                        Column {
                            Text(
                                text = "इस्लामी इल्म व कलाम-ए-रज़ा",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "कलाम-ए-रज़ा • हदीस-ए-पाक • फ़तावा • क़ुरआन मजीद",
                                style = MaterialTheme.typography.labelSmall,
                                color = IslamicGold
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_islamic_hub_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close",
                            tint = Color.White.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            // Live Recitation Active Banner
            AnimatedVisibility(visible = isSpeaking) {
                Surface(
                    color = IslamicEmeraldDark,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, IslamicGold)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(text = "🔊", fontSize = 16.sp)
                            Text(
                                text = "ज़ोया तिलावत / कलाम पढ़ रही हैं...",
                                color = IslamicGold,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                        Button(
                            onClick = onStopSpeaking,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Stop,
                                contentDescription = "Stop",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "रोकें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Navigation Tabs (Scrollable for complete Islamic categories)
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = DeepMidnight,
                contentColor = IslamicGold,
                edgePadding = 12.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 12.sp,
                                color = if (selectedTabIndex == index) IslamicGold else Color.White.copy(alpha = 0.6f)
                            )
                        }
                    )
                }
            }

            // Content Area by Tab
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                when (selectedTabIndex) {
                    0 -> KalaamRazaTabContent(
                        onRecite = onReciteText,
                        onAskZoya = onAskZoya
                    )
                    1 -> HadithTabContent(
                        onRecite = onReciteText,
                        onAskZoya = onAskZoya
                    )
                    2 -> FatwaTabContent(
                        onRecite = onReciteText,
                        onAskZoya = onAskZoya
                    )
                    3 -> QuranTabContent(
                        onRecite = onReciteText,
                        onAskZoya = onAskZoya
                    )
                    4 -> NaatTabContent(
                        onRecite = onReciteText,
                        onAskZoya = onAskZoya
                    )
                    5 -> ShayariTabContent(
                        onRecite = onReciteText,
                        onAskZoya = onAskZoya
                    )
                    6 -> DuasAndTasbeehTabContent(
                        onRecite = onReciteText,
                        onAskZoya = onAskZoya
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 0. KALAAM-E-RAZA & ASH'AAR TAB (आला हज़रत कलाम व शेर)
// -------------------------------------------------------------
@Composable
fun KalaamRazaTabContent(
    onRecite: (String) -> Unit,
    onAskZoya: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedSubSection by remember { mutableIntStateOf(0) } // 0: Kalaam (हदाएक़-ए-बख़्शिश), 1: Ash'aar (शेर)
    val context = LocalContext.current

    val filteredKalaam = remember(searchQuery) {
        if (searchQuery.isBlank()) IslamicRepository.kalaamERazaCollection
        else IslamicRepository.kalaamERazaCollection.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
            it.titleUrdu.contains(searchQuery) ||
            it.hindiLyrics.contains(searchQuery, ignoreCase = true) ||
            it.category.contains(searchQuery, ignoreCase = true)
        }
    }

    val filteredAshar = remember(searchQuery) {
        if (searchQuery.isBlank()) IslamicRepository.asharRazaCollection
        else IslamicRepository.asharRazaCollection.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
            it.category.contains(searchQuery, ignoreCase = true) ||
            it.couplets.any { c -> c.contains(searchQuery, ignoreCase = true) }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("कलाम-ए-रज़ा या शेर खोजें (जैसे: मुस्तफ़ा जाने रहमत)...", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f)) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "Search", tint = IslamicGold) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Color.White)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = IslamicGold,
                unfocusedBorderColor = IslamicEmerald.copy(alpha = 0.4f),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = IslamicGold
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        )

        // Sub Section Selector Chips
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            FilterChip(
                selected = selectedSubSection == 0,
                onClick = { selectedSubSection = 0 },
                label = { Text("🌹 कलाम-ए-रज़ा (${IslamicRepository.kalaamERazaCollection.size})", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = IslamicEmerald,
                    selectedLabelColor = Color.Black
                )
            )
            FilterChip(
                selected = selectedSubSection == 1,
                onClick = { selectedSubSection = 1 },
                label = { Text("✒️ आला हज़रत के शेर (${IslamicRepository.asharRazaCollection.size})", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = IslamicGold,
                    selectedLabelColor = Color.Black
                )
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (selectedSubSection == 0) {
            // Kalaam List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredKalaam) { naat ->
                    NaatCard(
                        naat = naat,
                        onRecite = { onRecite(naat.audioRecitationText) },
                        onAskZoya = { onAskZoya("आला हज़रत के इस कलाम के बारे में बताएं: ${naat.title}") }
                    )
                }
            }
        } else {
            // Ash'aar List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredAshar) { shair ->
                    ShayariCard(
                        shayari = shair,
                        onRecite = { onRecite(shair.audioRecitationText) },
                        onAskZoya = { onAskZoya("आला हज़रत के इस शेर की तफ़्सीर समझाएं: ${shair.title}") }
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 1. HADITH TAB (हदीस-ए-पाक)
// -------------------------------------------------------------
@Composable
fun HadithTabContent(
    onRecite: (String) -> Unit,
    onAskZoya: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    val context = LocalContext.current

    val categories = listOf("All", "ईमान व नीयत", "इश्क़-ए-रसूल ﷺ", "इल्म व तआलीम", "दुरूद व सलात", "अख़लाक़ व हुस्ने सुलूक", "वालिदैन के हुक़ूक़", "शफ़ाअत-ए-मुस्तफ़ा ﷺ")

    val filteredHadiths = remember(searchQuery, selectedCategory) {
        IslamicRepository.hadithCollection.filter { hadith ->
            val matchesCategory = if (selectedCategory == "All") true else hadith.category.contains(selectedCategory, ignoreCase = true)
            val matchesSearch = if (searchQuery.isBlank()) true else {
                hadith.title.contains(searchQuery, ignoreCase = true) ||
                hadith.hindiTranslation.contains(searchQuery, ignoreCase = true) ||
                hadith.reference.contains(searchQuery, ignoreCase = true) ||
                hadith.category.contains(searchQuery, ignoreCase = true) ||
                hadith.rawi.contains(searchQuery, ignoreCase = true)
            }
            matchesCategory && matchesSearch
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("हदीस-ए-पाक खोजें (जैसे: नियत, दुरूद, इल्म, माँ)...", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f)) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "Search", tint = IslamicGold) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Color.White)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = IslamicGold,
                unfocusedBorderColor = IslamicEmerald.copy(alpha = 0.4f),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = IslamicGold
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        )

        // Categories Row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            items(categories) { cat ->
                AssistChip(
                    onClick = { selectedCategory = cat },
                    label = {
                        Text(
                            text = if (cat == "All") "सभी हदीसें (${IslamicRepository.hadithCollection.size})" else cat,
                            fontSize = 11.sp,
                            fontWeight = if (selectedCategory == cat) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedCategory == cat) Color.Black else Color.White
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (selectedCategory == cat) IslamicGold else CardBackground
                    ),
                    border = BorderStroke(1.dp, if (selectedCategory == cat) IslamicGold else IslamicEmerald.copy(alpha = 0.3f))
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Hadith List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredHadiths) { hadith ->
                HadithCard(
                    hadith = hadith,
                    context = context,
                    onRecite = { onRecite(hadith.audioRecitationText) },
                    onAskZoya = { onAskZoya("मुझे इस हदीस के बारे में और समझाइए: ${hadith.title}") }
                )
            }
        }
    }
}

@Composable
fun HadithCard(
    hadith: HadithItem,
    context: Context,
    onRecite: () -> Unit,
    onAskZoya: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Title + Category Tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = hadith.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = IslamicGold
                    )
                    Text(
                        text = "रावी: ${hadith.rawi}",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = IslamicEmerald.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = hadith.category,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = IslamicGold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Arabic Text
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = DeepMidnight,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = hadith.arabicText,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.End,
                    lineHeight = 26.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Transliteration
            Text(
                text = "तलफ़्फ़ुज़: ${hadith.hindiTransliteration}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.9f),
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Translation
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White.copy(alpha = 0.05f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = "तर्जुमा:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IslamicGold
                    )
                    Text(
                        text = hadith.hindiTranslation,
                        fontSize = 13.sp,
                        color = Color.White,
                        lineHeight = 19.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            // Reference & Lesson
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "📖 हवाला: ${hadith.reference}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = CyberTeal
            )

            if (hadith.lesson.isNotBlank()) {
                Text(
                    text = "💡 सबक़: ${hadith.lesson}",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val textToCopy = "${hadith.title}\n\n${hadith.arabicText}\n\nतर्जुमा: ${hadith.hindiTranslation}\n\nहवाला: ${hadith.reference}"
                        val clip = ClipData.newPlainText("Hadith", textToCopy)
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
                        Toast.makeText(context, "हदीस शरीफ़ कॉपी हो गई! 📜", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = "Copy",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                OutlinedButton(
                    onClick = onAskZoya,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.5f)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("ज़ोया से पूछें 💬", fontSize = 11.sp, color = IslamicEmerald)
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onRecite,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGold),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VolumeUp,
                        contentDescription = "Recite",
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("हदीस सुनें 🔊", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 2. FATWA TAB (फ़तावा रज़विय्या - आला हज़रत)
// -------------------------------------------------------------
@Composable
fun FatwaTabContent(
    onRecite: (String) -> Unit,
    onAskZoya: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val context = LocalContext.current

    val filteredFatwas = remember(searchQuery) {
        if (searchQuery.isBlank()) IslamicRepository.fatwaCollection
        else IslamicRepository.fatwaCollection.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
            it.topic.contains(searchQuery, ignoreCase = true) ||
            it.question.contains(searchQuery, ignoreCase = true) ||
            it.fatwaAnswer.contains(searchQuery, ignoreCase = true) ||
            it.reference.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Banner info
        Surface(
            color = IslamicEmeraldDark,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, IslamicGold.copy(alpha = 0.4f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(text = "⚖️", fontSize = 24.sp)
                Column {
                    Text(
                        text = "फ़तावा रज़विय्या (अल-अताया अन-नबविय्या)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = IslamicGold
                    )
                    Text(
                        text = "आला हज़रत इमाम अहमद रज़ा ख़ान फ़ाज़िले बरेलवी के शरई अहकाम",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("फ़तवा या मसला खोजें (जैसे: अँगूठे चूमना, मिलाद, रोज़ा)...", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f)) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "Search", tint = IslamicGold) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Color.White)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = IslamicGold,
                unfocusedBorderColor = IslamicEmerald.copy(alpha = 0.4f),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = IslamicGold
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Fatwa List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredFatwas) { fatwa ->
                FatwaCard(
                    fatwa = fatwa,
                    context = context,
                    onRecite = { onRecite(fatwa.audioRecitationText) },
                    onAskZoya = { onAskZoya("फ़तावा रज़विय्या के इस मसले पर और समझाइए: ${fatwa.title}") }
                )
            }
        }
    }
}

@Composable
fun FatwaCard(
    fatwa: FatwaItem,
    context: Context,
    onRecite: () -> Unit,
    onAskZoya: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = BorderStroke(1.dp, IslamicGold.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Topic Badge + Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = IslamicGold.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, IslamicGold.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = fatwa.topic,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = IslamicGold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = "फ़तावा रज़विय्या",
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = fatwa.title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Question Box
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = DeepMidnight,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "❓ सवाल:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonPink
                    )
                    Text(
                        text = fatwa.question,
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.9f),
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Answer Box
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = IslamicEmeraldDark.copy(alpha = 0.5f),
                border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "✍️ अल-जवाब (आला हज़रत का शरई हुक्म):",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = IslamicGold
                    )
                    Text(
                        text = fatwa.fatwaAnswer,
                        fontSize = 13.sp,
                        color = Color.White,
                        lineHeight = 20.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Reference
            Text(
                text = "📚 किताब हवाला: ${fatwa.reference}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = CyberTeal
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val textToCopy = "फ़तावा रज़विय्या - आला हज़रत\n\nसवाल: ${fatwa.question}\n\nजवाब: ${fatwa.fatwaAnswer}\n\nहवाला: ${fatwa.reference}"
                        val clip = ClipData.newPlainText("Fatwa", textToCopy)
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
                        Toast.makeText(context, "फ़तवा शरीफ़ कॉपी हो गया! ⚖️", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = "Copy",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                OutlinedButton(
                    onClick = onAskZoya,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.5f)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("सवाल पूछें 💬", fontSize = 11.sp, color = IslamicEmerald)
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onRecite,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGold),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VolumeUp,
                        contentDescription = "Recite",
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("फ़तवा सुनें 🔊", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 3. QURAN TAB (114 Surahs Catalog + Ayat Reader)
// -------------------------------------------------------------
@Composable
fun QuranTabContent(
    onRecite: (String) -> Unit,
    onAskZoya: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedSubTab by remember { mutableIntStateOf(0) } // 0: Key Ayats, 1: 114 Surahs
    val context = LocalContext.current

    val filteredAyats = remember(searchQuery) {
        if (searchQuery.isBlank()) IslamicRepository.featuredAyats
        else IslamicRepository.featuredAyats.filter {
            it.surahName.contains(searchQuery, ignoreCase = true) ||
            it.hindiTranslation.contains(searchQuery, ignoreCase = true) ||
            it.hindiTransliteration.contains(searchQuery, ignoreCase = true)
        }
    }

    val filteredSurahs = remember(searchQuery) {
        if (searchQuery.isBlank()) IslamicRepository.allSurahs
        else IslamicRepository.allSurahs.filter {
            it.nameHindi.contains(searchQuery, ignoreCase = true) ||
            it.nameEnglish.contains(searchQuery, ignoreCase = true) ||
            it.meaningHindi.contains(searchQuery, ignoreCase = true) ||
            it.number.toString() == searchQuery.trim()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search Input Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("सूरह या आयत खोजें (उदा. फ़ातिहा, कुर्सी, यासीन)...", fontSize = 12.sp, color = Color.Gray) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "Search", tint = IslamicEmerald) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Color.White)
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = IslamicEmerald,
                unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
                focusedContainerColor = CardBackground,
                unfocusedContainerColor = CardBackground,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        // Sub-tabs: "प्रमुख आयतें (हिंदी तर्जुमा)" & "114 सूरह सूची"
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (selectedSubTab == 0) IslamicEmerald else CardBackground,
                border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.5f)),
                modifier = Modifier
                    .weight(1f)
                    .clickable { selectedSubTab = 0 }
            ) {
                Text(
                    text = "📖 मुंतख़ब आयतें व तर्जुमा (${filteredAyats.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedSubTab == 0) Color.Black else Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (selectedSubTab == 1) IslamicEmerald else CardBackground,
                border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.5f)),
                modifier = Modifier
                    .weight(1f)
                    .clickable { selectedSubTab = 1 }
            ) {
                Text(
                    text = "📜 114 सूरह इंडेक्स (${filteredSurahs.size})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedSubTab == 1) Color.Black else Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }

        if (selectedSubTab == 0) {
            // Ayats List with Arabic, Hindi Transliteration, and Hindi Tarjuma
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredAyats) { ayat ->
                    AyatCard(
                        ayat = ayat,
                        onRecite = {
                            val recitationText = "बिस्मिल्लाहिर-रहमानिर-रहीम। ${ayat.surahName}। ${ayat.hindiTransliteration}। इसका हिंदी तर्जुमा है: ${ayat.hindiTranslation}"
                            onRecite(recitationText)
                        },
                        onAskZoya = {
                            onAskZoya("Zoya, ${ayat.surahName} ki tafseer aur fazilat batao")
                        }
                    )
                }
            }
        } else {
            // 114 Surahs Catalog
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredSurahs) { surah ->
                    SurahCard(
                        surah = surah,
                        onReciteSurah = {
                            val prompt = "Zoya, Surah ${surah.nameHindi} ki fazilat aur tarjuma sunao"
                            onAskZoya(prompt)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AyatCard(
    ayat: AyatDetail,
    onRecite: () -> Unit,
    onAskZoya: () -> Unit
) {
    val context = LocalContext.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Title Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(IslamicEmerald.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${ayat.surahNumber}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = IslamicEmerald
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = ayat.surahName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = IslamicGold
                    )
                }

                if (ayat.ayatNumber > 0) {
                    Text(
                        text = "आयत: ${ayat.ayatNumber}",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Arabic Text (Elegant Calligraphic Layout)
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DeepMidnight.copy(alpha = 0.7f),
                border = BorderStroke(1.dp, IslamicGold.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = ayat.arabicText,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.End,
                    lineHeight = 32.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Hindi Pronunciation / Transliteration (तलफ़्फ़ुज़)
            Text(
                text = "उच्चारण (तलफ़्फ़ुज़):",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = IslamicEmerald
            )
            Text(
                text = ayat.hindiTransliteration,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.9f),
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Hindi Translation (तर्जुमा)
            Text(
                text = "हिंदी तर्जुमा (अनुवाद):",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = IslamicGold
            )
            Text(
                text = ayat.hindiTranslation,
                fontSize = 13.sp,
                color = Color.White.copy(alpha = 0.85f),
                lineHeight = 18.sp
            )

            if (ayat.virtues.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "✨ ", fontSize = 11.sp)
                    Text(
                        text = ayat.virtues,
                        fontSize = 11.sp,
                        color = IslamicGoldMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons: Recite Aloud, Ask Zoya, Copy
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Copy button
                IconButton(
                    onClick = {
                        val clip = ClipData.newPlainText("Ayat", "${ayat.arabicText}\n${ayat.hindiTransliteration}\n\nहिंदी तर्जुमा:\n${ayat.hindiTranslation}")
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
                        Toast.makeText(context, "आयत व तर्जुमा कॉपी हो गया! 📋", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = "Copy",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Ask Zoya button
                OutlinedButton(
                    onClick = onAskZoya,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, CyberTeal.copy(alpha = 0.5f)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("तफ़्सीर पूछें", fontSize = 11.sp, color = CyberTeal)
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Recite Aloud with Zoya Voice Button
                Button(
                    onClick = onRecite,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicEmerald),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VolumeUp,
                        contentDescription = "Recite",
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ज़ोया से सुनें 🔊", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}

@Composable
fun SurahCard(
    surah: SurahInfo,
    onReciteSurah: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onReciteSurah() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Surah Number Diamond
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(IslamicEmerald.copy(alpha = 0.15f))
                        .border(1.dp, IslamicEmerald.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${surah.number}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = IslamicGold
                    )
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = surah.nameHindi,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "(${surah.nameEnglish})",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }

                    Text(
                        text = "अर्थ: ${surah.meaningHindi}",
                        fontSize = 11.sp,
                        color = IslamicGoldMuted
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Text(
                            text = "${surah.revelationType} • ${surah.totalAyats} आयतें",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                    }
                }
            }

            // Arabic Name + Action
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = surah.nameArabic,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = IslamicGold
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = IslamicEmerald.copy(alpha = 0.2f),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Text(
                        text = "सुनें 🔊",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = IslamicEmerald,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 2. NAAT SHARIF TAB
// -------------------------------------------------------------
@Composable
fun NaatTabContent(
    onRecite: (String) -> Unit,
    onAskZoya: (String) -> Unit
) {
    val naats = IslamicRepository.naatCollection
    val context = LocalContext.current

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = IslamicEmeraldDark.copy(alpha = 0.5f),
                border = BorderStroke(1.dp, IslamicGold.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🌺", fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "हुज़ूर नबी-ए-करीम ﷺ की शान-ए-अक़दस में मशहूर व रूहानी नात शरीफ़। ज़ोया इन्हें अपनी आवाज़ में सुना भी सकती हैं!",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        }

        items(naats) { naat ->
            NaatCard(
                naat = naat,
                onRecite = { onRecite(naat.audioRecitationText) },
                onAskZoya = { onAskZoya("Zoya, '${naat.title}' naat sharif ki tareekh aur matlab batao") }
            )
        }
    }
}

@Composable
fun NaatCard(
    naat: NaatItem,
    onRecite: () -> Unit,
    onAskZoya: () -> Unit
) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = BorderStroke(1.dp, IslamicGold.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = naat.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = IslamicGold
                    )
                    Text(
                        text = "शायर: ${naat.poet}",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = IslamicEmerald.copy(alpha = 0.2f),
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(
                            text = naat.category,
                            fontSize = 10.sp,
                            color = IslamicEmerald,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = naat.titleUrdu,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.8f),
                    textAlign = TextAlign.End
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Stanzas / Lyrics
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = DeepMidnight,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    val displayedStanzas = if (isExpanded) naat.stanzas else naat.stanzas.take(2)
                    for (stanza in displayedStanzas) {
                        Text(
                            text = stanza,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White.copy(alpha = 0.95f),
                            lineHeight = 20.sp,
                            modifier = Modifier.padding(vertical = 3.dp)
                        )
                    }

                    if (naat.stanzas.size > 2) {
                        Text(
                            text = if (isExpanded) "कम दिखाएं ▲" else "और अशआर पढ़ें (${naat.stanzas.size} शेर) ▼",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = IslamicGold,
                            modifier = Modifier
                                .padding(top = 6.dp)
                                .clickable { isExpanded = !isExpanded }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val clip = ClipData.newPlainText("Naat", "${naat.title}\n\n${naat.hindiLyrics}")
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
                        Toast.makeText(context, "नात शरीफ़ कॉपी हो गई! 🌺", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = "Copy",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                // YouTube Search Action
                OutlinedButton(
                    onClick = {
                        com.example.device.PhoneController.searchYouTube("${naat.title} naat sharif", context)
                    },
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.6f)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("YouTube 🎬", fontSize = 11.sp, color = Color.White)
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Recite Aloud Button
                Button(
                    onClick = onRecite,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGold),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VolumeUp,
                        contentDescription = "Recite",
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("नात सुनाओ 🌺", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 3. SHAYARI & SUFI KALAM TAB
// -------------------------------------------------------------
@Composable
fun ShayariTabContent(
    onRecite: (String) -> Unit,
    onAskZoya: (String) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "अल्लामा इक़बाल रूहानी कलाम", "इश्क़-ए-रसूल ﷺ", "नमाज़ व इबादत", "सब्र व दुआ")

    val filteredList = remember(selectedCategory) {
        if (selectedCategory == "All") IslamicRepository.shayariCollection
        else IslamicRepository.shayariCollection.filter { it.category == selectedCategory }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Category Filter Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        ) {
            items(categories) { cat ->
                AssistChip(
                    onClick = { selectedCategory = cat },
                    label = {
                        Text(
                            text = if (cat == "All") "सभी शायरी" else cat,
                            fontSize = 11.sp,
                            fontWeight = if (selectedCategory == cat) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (selectedCategory == cat) IslamicEmerald else CardBackground,
                        labelColor = if (selectedCategory == cat) Color.Black else Color.White
                    ),
                    border = AssistChipDefaults.assistChipBorder(
                        enabled = true,
                        borderColor = IslamicEmerald.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredList) { item ->
                ShayariCard(
                    shayari = item,
                    onRecite = { onRecite(item.audioRecitationText) },
                    onAskZoya = { onAskZoya("Zoya, '${item.title}' sher ka matlab aur tafseel samjhao") }
                )
            }
        }
    }
}

@Composable
fun ShayariCard(
    shayari: ShayariItem,
    onRecite: () -> Unit,
    onAskZoya: () -> Unit
) {
    val context = LocalContext.current

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = BorderStroke(1.dp, DeepViolet.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = shayari.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White
                    )
                    Text(
                        text = "शायर: ${shayari.poet}",
                        fontSize = 11.sp,
                        color = IslamicGold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DeepViolet.copy(alpha = 0.25f)
                ) {
                    Text(
                        text = shayari.category,
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Couplets
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = DeepMidnight,
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    for (line in shayari.couplets) {
                        Text(
                            text = line,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val text = "${shayari.title}\nशायर: ${shayari.poet}\n\n${shayari.couplets.joinToString("\n")}"
                        val clip = ClipData.newPlainText("Shayari", text)
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
                        Toast.makeText(context, "शेर कॉपी हो गया! ✒️", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = "Copy",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                OutlinedButton(
                    onClick = onAskZoya,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, DeepViolet.copy(alpha = 0.6f)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Text("मतलब पूछें", fontSize = 11.sp, color = DeepViolet)
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onRecite,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicEmerald),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VolumeUp,
                        contentDescription = "Recite",
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("शेर सुनो 🔊", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}

// -------------------------------------------------------------
// 4. DUAS, KALIMAS & DIGITAL TASBEEH TAB
// -------------------------------------------------------------
@Composable
fun DuasAndTasbeehTabContent(
    onRecite: (String) -> Unit,
    onAskZoya: (String) -> Unit
) {
    var subSection by remember { mutableIntStateOf(0) } // 0: Tasbeeh, 1: 6 Kalimas, 2: Masnoon Duas

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (subSection == 0) IslamicEmerald else CardBackground,
                border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.4f)),
                modifier = Modifier
                    .weight(1f)
                    .clickable { subSection = 0 }
            ) {
                Text(
                    text = "📿 डिजिटल तस्बीह",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (subSection == 0) Color.Black else Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (subSection == 1) IslamicEmerald else CardBackground,
                border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.4f)),
                modifier = Modifier
                    .weight(1f)
                    .clickable { subSection = 1 }
            ) {
                Text(
                    text = "✨ 6 कलिमे",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (subSection == 1) Color.Black else Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (subSection == 2) IslamicEmerald else CardBackground,
                border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.4f)),
                modifier = Modifier
                    .weight(1f)
                    .clickable { subSection = 2 }
            ) {
                Text(
                    text = "🤲 मसनून दुआएँ",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (subSection == 2) Color.Black else Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }
        }

        when (subSection) {
            0 -> DigitalTasbeehSection()
            1 -> SixKalimasSection(onRecite = onRecite)
            2 -> MasnoonDuasSection(onRecite = onRecite)
        }
    }
}

@Composable
fun DigitalTasbeehSection() {
    val haptic = LocalHapticFeedback.current
    val zikrList = listOf(
        Pair("سُبْحَانَ اللَّهِ (सुब्हानअल्लाह)", 33),
        Pair("الْحَمْدُ لِلَّهِ (अलहम्दुलिल्लाह)", 33),
        Pair("اللَّهُ أَكْبَرُ (अल्लाहु अकबर)", 34),
        Pair("أَسْتَغْفِرُ اللَّهَ (अस्तग़फ़िरुल्लाह)", 100),
        Pair("اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ (दुरूद शरीफ़ ﷺ)", 100),
        Pair("لَا إِلَٰهَ إِلَّا اللَّهُ (ला इलाहा इल्लल्लाह)", 100)
    )

    var selectedZikrIndex by remember { mutableIntStateOf(0) }
    var count by remember { mutableIntStateOf(0) }
    val currentZikr = zikrList[selectedZikrIndex]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Zikr selection chip row
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(zikrList.indices.toList()) { index ->
                val item = zikrList[index]
                AssistChip(
                    onClick = {
                        selectedZikrIndex = index
                        count = 0
                    },
                    label = { Text(item.first.substringBefore(" ("), fontSize = 12.sp) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (selectedZikrIndex == index) IslamicGold else CardBackground,
                        labelColor = if (selectedZikrIndex == index) Color.Black else Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Selected Zikr Title Display
        Text(
            text = currentZikr.first,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = IslamicGold,
            textAlign = TextAlign.Center
        )
        Text(
            text = "लक्ष्य: ${currentZikr.second} बार",
            fontSize = 12.sp,
            color = Color.White.copy(alpha = 0.6f)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Interactive Large Tasbeeh Orb
        Box(
            modifier = Modifier
                .size(190.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(IslamicEmerald, IslamicEmeraldDark, DeepMidnight)
                    )
                )
                .border(4.dp, IslamicGold, CircleShape)
                .clickable {
                    count++
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$count",
                    fontSize = 48.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Text(
                    text = "टैप करें",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = IslamicGold
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Reset Counter Button
        OutlinedButton(
            onClick = { count = 0 },
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
        ) {
            Icon(Icons.Rounded.Refresh, contentDescription = "Reset", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("रीसेट करें (Reset)", fontSize = 12.sp)
        }
    }
}

@Composable
fun SixKalimasSection(onRecite: (String) -> Unit) {
    val kalimas = IslamicRepository.sixKalimas

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(kalimas) { item ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = item.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = IslamicGold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DeepMidnight,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = item.arabicText,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.End,
                            lineHeight = 26.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "तलफ़्फ़ुज़: ${item.hindiTransliteration}",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "तर्जुमा: ${item.hindiTranslation}",
                        fontSize = 12.sp,
                        color = IslamicGoldMuted
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = {
                                onRecite("${item.name}। ${item.hindiTransliteration}। इसका हिंदी तर्जुमा है: ${item.hindiTranslation}")
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IslamicEmerald),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Rounded.VolumeUp, contentDescription = "Recite", tint = Color.Black, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("कलिमा सुनें 🔊", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MasnoonDuasSection(onRecite: (String) -> Unit) {
    val duas = IslamicRepository.masnoonDuas

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(duas) { dua ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                border = BorderStroke(1.dp, IslamicEmerald.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = dua.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = IslamicGold
                        )
                        Text(
                            text = dua.occasion,
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DeepMidnight,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = dua.arabicText,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.End,
                            lineHeight = 24.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "तलफ़्फ़ुज़: ${dua.hindiTransliteration}",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "तर्जुमा: ${dua.hindiTranslation}",
                        fontSize = 12.sp,
                        color = IslamicGoldMuted
                    )

                    if (dua.benefit.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "फ़ज़ीलत: ${dua.benefit}",
                            fontSize = 11.sp,
                            color = CyberTeal
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = {
                                onRecite("${dua.title}। ${dua.hindiTransliteration}। इसका हिंदी तर्जुमा है: ${dua.hindiTranslation}")
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IslamicEmerald),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Icon(Icons.Rounded.VolumeUp, contentDescription = "Recite", tint = Color.Black, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("दुआ सुनें 🔊", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}
