package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiClient
import com.example.ai.ParsedAction
import com.example.audio.FemaleVoiceProfile
import com.example.audio.SpeechManager
import com.example.data.local.ZoyaDatabase
import com.example.data.model.ContactEntity
import com.example.data.model.ConversationEntity
import com.example.data.model.MemoryEntity
import com.example.data.repository.ZoyaRepository
import com.example.device.PhoneController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ZoyaViewModel(application: Application) : AndroidViewModel(application) {

    private val database = ZoyaDatabase.getDatabase(application, viewModelScope)
    private val repository = ZoyaRepository(database.conversationDao(), database.memoryDao(), database.contactDao())

    val speechManager = SpeechManager(application, viewModelScope)

    val conversations: StateFlow<List<ConversationEntity>> = repository.allConversations
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val memories: StateFlow<List<MemoryEntity>> = repository.allMemories
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val contacts: StateFlow<List<ContactEntity>> = repository.allContacts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val isListening: StateFlow<Boolean> = speechManager.isListening
    val isSpeaking: StateFlow<Boolean> = speechManager.isSpeaking
    val audioAmplitude: StateFlow<Float> = speechManager.audioAmplitude
    val liveTranscript: StateFlow<String> = speechManager.liveTranscript
    val availableVoices: StateFlow<List<FemaleVoiceProfile>> = speechManager.availableVoices
    val selectedVoice: StateFlow<FemaleVoiceProfile> = speechManager.selectedVoice

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _showIslamicHub = MutableStateFlow(false)
    val showIslamicHub: StateFlow<Boolean> = _showIslamicHub.asStateFlow()

    private val _fallbackToSystemVoiceDialog = MutableStateFlow(false)
    val fallbackToSystemVoiceDialog: StateFlow<Boolean> = _fallbackToSystemVoiceDialog.asStateFlow()

    fun triggerSystemVoiceDialog() {
        _fallbackToSystemVoiceDialog.value = true
    }

    fun onSystemVoiceDialogHandled() {
        _fallbackToSystemVoiceDialog.value = false
    }

    fun setShowIslamicHub(show: Boolean) {
        _showIslamicHub.value = show
    }

    private val _showVisionCamera = MutableStateFlow(false)
    val showVisionCamera: StateFlow<Boolean> = _showVisionCamera.asStateFlow()

    private val _isVisionAnalyzing = MutableStateFlow(false)
    val isVisionAnalyzing: StateFlow<Boolean> = _isVisionAnalyzing.asStateFlow()

    private val _visionResultText = MutableStateFlow<String?>(null)
    val visionResultText: StateFlow<String?> = _visionResultText.asStateFlow()

    private val _capturedVisionBitmap = MutableStateFlow<android.graphics.Bitmap?>(null)
    val capturedVisionBitmap: StateFlow<android.graphics.Bitmap?> = _capturedVisionBitmap.asStateFlow()

    // Interactive In-App AI Web Automation Browser & Co-Pilot
    private val _showWebAutomation = MutableStateFlow(false)
    val showWebAutomation: StateFlow<Boolean> = _showWebAutomation.asStateFlow()

    private val _webAutomationUrl = MutableStateFlow("")
    val webAutomationUrl: StateFlow<String> = _webAutomationUrl.asStateFlow()

    private val _webAutomationTitle = MutableStateFlow("")
    val webAutomationTitle: StateFlow<String> = _webAutomationTitle.asStateFlow()

    private val _webAutomationPlatform = MutableStateFlow("")
    val webAutomationPlatform: StateFlow<String> = _webAutomationPlatform.asStateFlow()

    private val _webAutomationQuery = MutableStateFlow("")
    val webAutomationQuery: StateFlow<String> = _webAutomationQuery.asStateFlow()

    fun openWebAutomation(url: String, title: String, platform: String, query: String = "") {
        _webAutomationUrl.value = url
        _webAutomationTitle.value = title
        _webAutomationPlatform.value = platform
        _webAutomationQuery.value = query
        _showWebAutomation.value = true
        _lastActionNotice.value = "$title live khol diya hai! ⚡"
    }

    fun closeWebAutomation() {
        _showWebAutomation.value = false
        _webAutomationUrl.value = ""
        speechManager.stopSpeaking()
        speechManager.stopListening()
    }

    fun startListeningForWebAutomation(context: Context) {
        speechManager.stopSpeaking()
        speechManager.startListening(
            onResult = { voiceQuery ->
                if (voiceQuery.isNotBlank()) {
                    processUserQuery(voiceQuery, isVoice = true, context = context)
                }
            },
            onError = { error ->
                _lastActionNotice.value = error
            },
            onFallbackToSystemDialog = {
                _lastActionNotice.value = "Mic ready hai — tap karke boliye! 🎙️"
            }
        )
    }

    fun openVisionCamera() {
        _showVisionCamera.value = true
        _visionResultText.value = null
        _lastActionNotice.value = "Zoya Vision Camera Active 📷✨"
    }

    fun closeVisionCamera() {
        _showVisionCamera.value = false
        _isVisionAnalyzing.value = false
        speechManager.stopListening()
    }

    fun startListeningForVision(bitmap: android.graphics.Bitmap?, context: Context) {
        speechManager.stopSpeaking()
        speechManager.startListening(
            onResult = { voiceQuery ->
                if (voiceQuery.isNotBlank()) {
                    val targetBitmap = bitmap ?: _capturedVisionBitmap.value
                    if (targetBitmap != null) {
                        analyzeCapturedImage(targetBitmap, voiceQuery, context)
                    } else {
                        processUserQuery(voiceQuery, isVoice = true, context = context)
                    }
                }
            },
            onError = { error ->
                _lastActionNotice.value = error
            },
            onFallbackToSystemDialog = {
                _lastActionNotice.value = "Mic ready hai — tap karke boliye! 🎙️"
            }
        )
    }

    fun analyzeCapturedImage(bitmap: android.graphics.Bitmap, userPrompt: String = "Ye dekho aur vistaar se batao ye kya hai", context: Context) {
        _capturedVisionBitmap.value = bitmap
        _isVisionAnalyzing.value = true
        _visionResultText.value = null

        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.insertConversation(role = "user", content = "[Zoya Vision 📷] $userPrompt", isVoice = true)
                val response = GeminiClient.analyzeImageWithZoya(bitmap, userPrompt, context)
                _isVisionAnalyzing.value = false
                _visionResultText.value = response.spokenText

                repository.insertConversation(role = "zoya", content = response.spokenText, isVoice = true)
                com.example.ai.ZoyaCompanionManager.setEmotion(com.example.ai.ZoyaEmotion.SUPER_SMART)

                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    speechManager.speak(response.spokenText) {
                        // User requested: "batane ke baad dubara mic on hona chahiye taake aage jo puchhna ho wo puchh sake"
                        viewModelScope.launch(Dispatchers.Main) {
                            kotlinx.coroutines.delay(400)
                            if (_showVisionCamera.value) {
                                startListeningForVision(bitmap, context)
                            } else {
                                startListeningSafely(context, retryOnSilence = 1)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                _isVisionAnalyzing.value = false
                val errorMsg = "Photo analysis error: ${e.localizedMessage}"
                _visionResultText.value = errorMsg
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    speechManager.speak("Boss, photo dekhne me thodi dikkat aayi. Kripya dobara try karein!") {
                        viewModelScope.launch(Dispatchers.Main) {
                            kotlinx.coroutines.delay(400)
                            if (_showVisionCamera.value) {
                                startListeningForVision(bitmap, context)
                            }
                        }
                    }
                }
            }
        }
    }

    private val _lastActionNotice = MutableStateFlow<String?>(null)
    val lastActionNotice: StateFlow<String?> = _lastActionNotice.asStateFlow()

    private val _voicePitch = MutableStateFlow(1.18f)
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()

    private val _voiceSpeed = MutableStateFlow(1.05f)
    val voiceSpeed: StateFlow<Float> = _voiceSpeed.asStateFlow()

    private val _personalityLevel = MutableStateFlow("Max Chulbuli 💖")
    val personalityLevel: StateFlow<String> = _personalityLevel.asStateFlow()

    val isContinuousConversationActive: StateFlow<Boolean> = com.example.ai.ZoyaCompanionManager.isContinuousConversationActive
    val isProactiveCheckInActive: StateFlow<Boolean> = com.example.ai.ZoyaCompanionManager.isProactiveCheckInActive
    val bossTitle: StateFlow<String> = com.example.ai.ZoyaCompanionManager.currentBossTitle
    val currentEmotion: StateFlow<com.example.ai.ZoyaEmotion> = com.example.ai.ZoyaCompanionManager.currentEmotion

    // Anti-Theft Touch Guard & Intruder Protection Sentinel
    val isTouchGuardArmed: StateFlow<Boolean> = com.example.security.AntiTheftSentinelController.isArmed
    val armCountdown: StateFlow<Int> = com.example.security.AntiTheftSentinelController.armCountdown
    val intruderIncidents: StateFlow<List<com.example.security.IntruderIncident>> = com.example.security.AntiTheftSentinelController.incidents
    val unreviewedIncidents: StateFlow<List<com.example.security.IntruderIncident>> = com.example.security.AntiTheftSentinelController.unreviewedIncidents
    val hasUnreviewedIntruderIncident: StateFlow<Boolean> = com.example.security.AntiTheftSentinelController.hasUnreviewedIncident
    val lastCapturedIncident: StateFlow<com.example.security.IntruderIncident?> = com.example.security.AntiTheftSentinelController.lastCapturedIncident

    private val _showIntruderSecuritySheet = MutableStateFlow(false)
    val showIntruderSecuritySheet: StateFlow<Boolean> = _showIntruderSecuritySheet.asStateFlow()

    init {
        com.example.ai.ZoyaCompanionManager.init(application)
        com.example.security.AntiTheftSentinelController.init(application)
    }

    fun openIntruderSecuritySheet() { _showIntruderSecuritySheet.value = true }
    fun closeIntruderSecuritySheet() { _showIntruderSecuritySheet.value = false }

    fun toggleTouchGuard(context: Context, arm: Boolean) {
        if (arm) {
            com.example.security.AntiTheftSentinelController.armGuard(context, countdownSeconds = 5)
            _lastActionNotice.value = "Anti-Theft Touch Guard: 5 sec me active ho raha hai... 🛡️"
        } else {
            com.example.security.AntiTheftSentinelController.disarmGuard(context)
            _lastActionNotice.value = "Anti-Theft Touch Guard band kar diya 🔓"
        }
    }

    fun testTriggerIntruderSecurity(context: Context) {
        com.example.security.AntiTheftSentinelController.triggerUnauthorizedTouch(context, "Manual Test: Unauthorized Touch")
        _lastActionNotice.value = "Test Alert: Photo captured & phone locked! 📸🔒"
    }

    fun markIntruderIncidentsReviewed(context: Context) {
        com.example.security.AntiTheftSentinelController.markAllIncidentsAsReviewed(context)
    }

    fun deleteIntruderIncident(context: Context, id: String) {
        com.example.security.AntiTheftSentinelController.deleteIncident(context, id)
    }

    fun clearAllIntruderIncidents(context: Context) {
        com.example.security.AntiTheftSentinelController.clearAllIncidents(context)
        _lastActionNotice.value = "Saare intruder logs clear kar diye 🗑️"
    }

    fun setContinuousConversation(enabled: Boolean) {
        com.example.ai.ZoyaCompanionManager.setContinuousConversationEnabled(getApplication(), enabled)
        _lastActionNotice.value = if (enabled) "Google Assistant Auto-Answer Loop Active 🎙️" else "Auto-Answer Loop Band Hai"
    }

    fun setProactiveCheckIn(enabled: Boolean) {
        com.example.ai.ZoyaCompanionManager.setProactiveCheckInEnabled(getApplication(), enabled)
        _lastActionNotice.value = if (enabled) "Proactive Mood & Daily Chat Active 💖" else "Proactive Mood Check-In Band Hai"
    }

    fun setBossTitle(title: String) {
        com.example.ai.ZoyaCompanionManager.setBossTitle(getApplication(), title)
        _lastActionNotice.value = "Boss Title Updated: $title ✨"
    }

    fun initiateProactiveMoodCheckIn(context: Context) {
        val greeting = com.example.ai.ZoyaCompanionManager.getProactiveMoodGreeting(context)
        com.example.ai.ZoyaCompanionManager.setEmotion(com.example.ai.ZoyaEmotion.LOVING_CARE)
        _lastActionNotice.value = "Boss Mood & Daily Chat 💖"
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertConversation(
                role = "zoya",
                content = greeting,
                isVoice = true
            )
            kotlinx.coroutines.withContext(Dispatchers.Main) {
                speechManager.speak(greeting) {
                    viewModelScope.launch(Dispatchers.Main) {
                        // Allow audio track to fully clear before opening microphone
                        kotlinx.coroutines.delay(500)
                        startListeningSafely(context, retryOnSilence = 1)
                    }
                }
            }
        }
    }

    private var isContinuousListeningSessionActive: Boolean = true

    fun setContinuousListeningSessionActive(active: Boolean) {
        isContinuousListeningSessionActive = active
    }

    /**
     * Start continuous listening loop:
     * When Zoya speaks, the mic automatically turns back on for the user's next command.
     * Even if silence or a speech timeout occurs, it automatically keeps listening
     * until the user says an exit phrase ("bye", "alvida", "band ho jao") or taps mic to pause.
     */
    fun startListeningSafely(context: Context, retryOnSilence: Int = 999) {
        isContinuousListeningSessionActive = true
        startListeningInternal(context)
    }

    private fun startListeningInternal(context: Context) {
        if (!isContinuousListeningSessionActive) return
        speechManager.startListening(
            onResult = { recognizedText ->
                val trimmed = recognizedText.trim()
                if (trimmed.isNotBlank()) {
                    val isExit = com.example.ai.ZoyaCompanionManager.isExitPhrase(trimmed)
                    if (isExit) {
                        isContinuousListeningSessionActive = false
                    }
                    processUserQuery(trimmed, isVoice = true, context = context)
                }
            },
            onError = { error ->
                if (isContinuousListeningSessionActive) {
                    // Do not turn off mic! Keep listening seamlessly for Boss's next command
                    viewModelScope.launch(Dispatchers.Main) {
                        kotlinx.coroutines.delay(350)
                        if (isContinuousListeningSessionActive && !speechManager.isSpeaking.value) {
                            startListeningInternal(context)
                        }
                    }
                } else {
                    _lastActionNotice.value = error
                }
            },
            onFallbackToSystemDialog = {
                _lastActionNotice.value = "Mic ready hai — tap karke boliye! 🎙️"
            }
        )
    }

    fun processUserQuery(text: String, isVoice: Boolean = false, context: Context) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return

        // Direct shortcut for Boss Mood & Daily Chat
        if (trimmed.equals("boss mood & daily chat", ignoreCase = true) ||
            trimmed.equals("boss mood", ignoreCase = true) ||
            trimmed.equals("daily chat", ignoreCase = true) ||
            trimmed.equals("mood check", ignoreCase = true)) {
            initiateProactiveMoodCheckIn(context)
            return
        }

        // Direct shortcut for Zoya Vision Camera
        val lower = trimmed.lowercase()
        if (lower.contains("camera kholo") || lower.contains("camera on") || lower.contains("camera open") ||
            lower.contains("kamera kholo") || lower.contains("ye dekho") || lower.contains("photo dekho") ||
            lower.contains("vision kholo") || lower.contains("camera se dekho") || lower.contains("look at this") ||
            lower.contains("zoya vision") || lower.contains("zoya camera") || lower == "camera" || lower == "vision"
        ) {
            openVisionCamera()
            val reply = "Haan ji Boss! Zoya Vision Camera khol diya hai! Jo bhi cheez dikhana chahte hain, camera ke saamne laaiye aur 'Zoya Dekho' button dabaiye! 📸✨"
            viewModelScope.launch(Dispatchers.IO) {
                repository.insertConversation(role = "zoya", content = reply, isVoice = isVoice)
                kotlinx.coroutines.withContext(Dispatchers.Main) {
                    speechManager.speak(reply)
                }
            }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.insertConversation(role = "user", content = trimmed, isVoice = isVoice)

                _isThinking.value = true
                val currentMemories = repository.getAllMemoriesList()
                val currentContacts = repository.getAllContactsList()
                val recentHistory = repository.getRecentConversations(6).reversed()

                val zoyaResponse = GeminiClient.generateZoyaResponse(
                    userPrompt = trimmed,
                    conversationHistory = recentHistory,
                    memories = currentMemories,
                    contacts = currentContacts,
                    context = context
                )

                _isThinking.value = false

                // Update Zoya's live emotion state based on user's query and response
                com.example.ai.ZoyaCompanionManager.detectAndSetEmotion(trimmed, zoyaResponse.spokenText)

                // Update Neural Engine metrics, learned patterns and smart auto-replies
                com.example.ai.neural.NeuralEngine.recordInteraction(trimmed, zoyaResponse.actions.size)

                var actionDescription = ""
                for (action in zoyaResponse.actions) {
                    try {
                        executeParsedAction(action, context)
                        actionDescription += "${action.type} "
                    } catch (ae: Exception) {
                        android.util.Log.e("ZoyaViewModel", "Error executing action ${action.type}", ae)
                    }
                }

                repository.insertConversation(
                    role = "zoya",
                    content = zoyaResponse.spokenText,
                    actionExecuted = actionDescription.trim().ifEmpty { null },
                    isVoice = isVoice
                )

                viewModelScope.launch(Dispatchers.Main) {
                    speechManager.speak(zoyaResponse.spokenText) {
                        // Continuous voice conversation loop: automatically listen for follow-up command
                        val isExit = com.example.ai.ZoyaCompanionManager.isExitPhrase(trimmed)
                        if (!isExit) {
                            isContinuousListeningSessionActive = true
                            viewModelScope.launch(Dispatchers.Main) {
                                kotlinx.coroutines.delay(350)
                                if (_showWebAutomation.value) {
                                    startListeningForWebAutomation(context)
                                } else {
                                    startListeningSafely(context)
                                }
                            }
                        } else {
                            isContinuousListeningSessionActive = false
                        }
                    }
                }
            } catch (e: Exception) {
                _isThinking.value = false
                android.util.Log.e("ZoyaViewModel", "Error in processUserQuery", e)
                val fallbackText = "Main sun rahi hoon! Kuch problem aayi, dobara boliye na please! 😊"
                repository.insertConversation(role = "zoya", content = fallbackText, isVoice = isVoice)
                viewModelScope.launch(Dispatchers.Main) {
                    speechManager.speak(fallbackText) {
                        isContinuousListeningSessionActive = true
                        viewModelScope.launch(Dispatchers.Main) {
                            kotlinx.coroutines.delay(350)
                            startListeningSafely(context)
                        }
                    }
                }
            }
        }
    }

    private suspend fun executeParsedAction(action: ParsedAction, context: Context) {
        when (action.type) {
            "OPEN_APP" -> {
                val targetLower = action.target.lowercase().trim()
                if (targetLower.contains("ai studio") || targetLower.contains("aistudio") || targetLower.contains("google ai") ||
                    targetLower.contains("website") || targetLower.contains("web") || targetLower.contains(".com") || targetLower.startsWith("http")
                ) {
                    val targetUrl = when {
                        targetLower.contains("ai studio") || targetLower.contains("aistudio") -> com.example.ai.AiStudioAutomationHelper.AI_STUDIO_BUILD_URL
                        action.target.startsWith("http") -> action.target
                        else -> "https://www.google.com/search?q=" + android.net.Uri.encode(action.target)
                    }
                    openWebAutomation(
                        url = targetUrl,
                        title = action.target,
                        platform = if (targetLower.contains("ai studio")) "Google AI Studio" else "Web",
                        query = action.target
                    )
                    _lastActionNotice.value = "${action.target} in-app browser me open ho gaya! 🌐✨"
                } else {
                    val res = PhoneController.openApp(action.target, context)
                    _lastActionNotice.value = res.description
                }
            }
            "SEND_WHATSAPP" -> {
                val matchedContact = repository.findContact(action.target)
                val targetPhone = matchedContact?.phoneNumber ?: action.target
                val res = PhoneController.sendWhatsApp(targetPhone, action.message, context)
                _lastActionNotice.value = res.description
            }
            "CALL_PHONE" -> {
                val matchedContact = repository.findContact(action.target)
                val targetPhone = matchedContact?.phoneNumber ?: action.target
                val res = PhoneController.callPhone(targetPhone, context)
                _lastActionNotice.value = res.description
            }
            "SEND_SMS" -> {
                val matchedContact = repository.findContact(action.target)
                val targetPhone = matchedContact?.phoneNumber ?: action.target
                val res = PhoneController.sendSms(targetPhone, action.message, context)
                _lastActionNotice.value = res.description
            }
            "SEARCH_YOUTUBE" -> {
                val res = PhoneController.searchYouTube(action.target, context)
                _lastActionNotice.value = res.description
            }
            "SEARCH_SPOTIFY" -> {
                val res = PhoneController.playSpotify(action.target, context)
                _lastActionNotice.value = res.description
            }
            "SET_ALARM" -> {
                val res = PhoneController.setAlarm(action.hour, action.minute, action.message, context)
                _lastActionNotice.value = res.description
            }
            "SET_TIMER" -> {
                val res = PhoneController.setTimer(action.seconds, action.message, context)
                _lastActionNotice.value = res.description
            }
            "ADJUST_VOLUME" -> {
                val res = PhoneController.adjustVolume(action.target, context)
                _lastActionNotice.value = res.description
            }
            "TOGGLE_FLASHLIGHT" -> {
                val enable = if (action.target.lowercase() == "on") true else if (action.target.lowercase() == "off") false else null
                val res = PhoneController.toggleFlashlight(enable, context)
                _lastActionNotice.value = res.description
            }
            "CHANGE_WALLPAPER" -> {
                val res = PhoneController.changeWallpaper(action.target, context)
                _lastActionNotice.value = res.description
            }
            "SEARCH_WEB" -> {
                val searchUrl = "https://www.google.com/search?q=" + android.net.Uri.encode(action.target)
                openWebAutomation(
                    url = searchUrl,
                    title = "Google Search: ${action.target}",
                    platform = "Google",
                    query = action.target
                )
                _lastActionNotice.value = "'${action.target}' in-app browser me search kar diya! 🔍✨"
            }
            "OPEN_SETTINGS" -> {
                val res = PhoneController.openSettingsSection(action.target, context)
                _lastActionNotice.value = res.description
            }
            "TRIGGER_VIBRATION" -> {
                val duration = if (action.seconds > 0) (action.seconds * 1000).toLong() else 400L
                val res = PhoneController.triggerVibration(duration, context)
                _lastActionNotice.value = res.description
            }
            "GLOBAL_BACK" -> {
                if (_showWebAutomation.value) {
                    _lastActionNotice.value = "Web page me peeche gaye ⬅️"
                } else if (_showVisionCamera.value) {
                    closeVisionCamera()
                } else {
                    _lastActionNotice.value = "Back command: Zoya ke sath hi hain Boss! 🌸"
                }
            }
            "GLOBAL_HOME" -> {
                if (_showWebAutomation.value) closeWebAutomation()
                if (_showVisionCamera.value) closeVisionCamera()
                _lastActionNotice.value = "Zoya main screen par aa gaye! 🏠✨"
            }
            "EXIT_APP" -> {
                _lastActionNotice.value = "Zoya se bahar aa rahe hain Boss! Khayal rakhna apna! 💖"
                speechManager.speak("Theek hai Boss, Zoya band ho rahi hai! Khayal rakhna apna! 💖") {
                    (context as? android.app.Activity)?.finish()
                }
            }
            "GLOBAL_RECENTS" -> {
                com.example.service.ZoyaAccessibilityService.performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS)
                _lastActionNotice.value = "Recent apps khol diya 📑"
            }
            "GLOBAL_NOTIFICATIONS" -> {
                com.example.service.ZoyaAccessibilityService.performGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                _lastActionNotice.value = "Notification panel niche kiya 🔔"
            }
            "CLICK_SCREEN" -> {
                val success = com.example.service.ZoyaAccessibilityService.clickTextOnScreen(action.target)
                _lastActionNotice.value = if (success) "Screen par '${action.target}' click kar diya! 👆" else "Screen par '${action.target}' nahi mila"
            }
            "SCROLL_DOWN" -> {
                val success = com.example.service.ZoyaAccessibilityService.scrollDown()
                _lastActionNotice.value = if (success) "Neeche scroll kiya ⬇️" else "Scroll nahi ho paya"
            }
            "SCROLL_UP" -> {
                val success = com.example.service.ZoyaAccessibilityService.scrollUp()
                _lastActionNotice.value = if (success) "Upar scroll kiya ⬆️" else "Scroll nahi ho paya"
            }
            "TYPE_TEXT" -> {
                val success = com.example.service.ZoyaAccessibilityService.typeTextIntoInput(action.target)
                _lastActionNotice.value = if (success) "'${action.target}' type kiya ✍️" else "Input field nahi mila"
            }
            "READ_SCREEN" -> {
                val summary = com.example.service.ZoyaAccessibilityService.getVisibleScreenSummary()
                _lastActionNotice.value = "Screen: $summary"
                speechManager.speak("Screen par dikh raha hai: $summary")
            }
            "LOCK_SCREEN" -> {
                val res = PhoneController.lockScreen(context)
                _lastActionNotice.value = res.description
            }
            "ARM_TOUCH_GUARD" -> {
                com.example.security.AntiTheftSentinelController.armGuard(context, countdownSeconds = 5)
                _lastActionNotice.value = "Anti-Theft Touch Guard Active (5s countdown) 🛡️"
            }
            "DISARM_TOUCH_GUARD" -> {
                com.example.security.AntiTheftSentinelController.disarmGuard(context)
                _lastActionNotice.value = "Anti-Theft Touch Guard Band Ho Gaya 🔓"
            }
            "SHOW_INTRUDER_PHOTOS" -> {
                _showIntruderSecuritySheet.value = true
                _lastActionNotice.value = "Intruder security photos khol rahe hain 📸🚨"
            }
            "UNLOCK_SCREEN" -> {
                val res = PhoneController.unlockScreen(context)
                _lastActionNotice.value = res.description
            }
            "WAKE_SCREEN" -> {
                val res = PhoneController.unlockScreen(context)
                _lastActionNotice.value = res.description
            }
            "DISMISS_KEYGUARD" -> {
                val res = com.example.device.SmartLockController.requestUnlockPrompt(context as? android.app.Activity)
                _lastActionNotice.value = res.description
            }
            "SAVE_MEMORY" -> {
                if (action.key.isNotBlank() && action.value.isNotBlank()) {
                    repository.insertMemory(action.key, action.value, action.category)
                    _lastActionNotice.value = "Yaad rakh liya: ${action.key} 🧠"
                }
            }
            "ADD_CONTACT" -> {
                if (action.name.isNotBlank() && action.phone.isNotBlank()) {
                    repository.insertContact(
                        ContactEntity(
                            name = action.name,
                            phoneNumber = action.phone,
                            nickname = action.nickname,
                            relationship = action.relationship
                        )
                    )
                    _lastActionNotice.value = "Contact add ho gaya: ${action.name} 👥"
                }
            }
            "OPEN_ISLAMIC_HUB" -> {
                _showIslamicHub.value = true
                _lastActionNotice.value = "Islamic Knowledge & Quran Hub khol diya! 🕌✨"
            }
            "CREATE_PHOTO" -> {
                val promptText = if (action.title.isNotBlank()) action.title else if (action.target.isNotBlank()) action.target else "Beautiful Aesthetic Artwork"
                val res = com.example.device.ZoyaCreationEngine.createPhoto(promptText, context)
                _lastActionNotice.value = res.description
                if (res.file != null && res.isSuccess) {
                    com.example.device.ZoyaCreationEngine.openOrShareFile(context, res.file, "image/jpeg")
                }
            }
            "CREATE_PDF" -> {
                val pdfTitle = if (action.title.isNotBlank()) action.title else "Zoya Automation Report"
                val pdfContent = if (action.content.isNotBlank()) action.content else action.message.ifBlank { "Generated by Zoya Smart AI Assistant." }
                val res = com.example.device.ZoyaCreationEngine.createPdf(pdfTitle, pdfContent, context)
                _lastActionNotice.value = res.description
                if (res.file != null && res.isSuccess) {
                    com.example.device.ZoyaCreationEngine.openOrShareFile(context, res.file, "application/pdf")
                }
            }
            "CREATE_APK" -> {
                val appName = if (action.title.isNotBlank()) action.title else if (action.target.isNotBlank()) action.target else "ZoyaSmartApp"
                val res = com.example.device.ZoyaCreationEngine.createApk(appName, context)
                _lastActionNotice.value = res.description
                if (res.file != null && res.isSuccess) {
                    com.example.device.ZoyaCreationEngine.openOrShareFile(context, res.file, "application/vnd.android.package-archive")
                }
            }
            "CREATE_VIDEO" -> {
                val vidTitle = if (action.title.isNotBlank()) action.title else if (action.target.isNotBlank()) action.target else "Zoya Video"
                val res = com.example.device.ZoyaCreationEngine.createVideo(vidTitle, context)
                _lastActionNotice.value = res.description
                if (res.file != null && res.isSuccess) {
                    com.example.device.ZoyaCreationEngine.openOrShareFile(context, res.file, "video/mp4")
                }
            }
            "CREATE_FILE" -> {
                val fileName = if (action.target.isNotBlank()) action.target else "Zoya_Document.txt"
                val fileContent = if (action.content.isNotBlank()) action.content else action.message.ifBlank { "Created automatically by Zoya Smart Assistant." }
                val res = com.example.device.ZoyaCreationEngine.createFile(fileName, fileContent, context)
                _lastActionNotice.value = res.description
                if (res.file != null && res.isSuccess) {
                    com.example.device.ZoyaCreationEngine.openOrShareFile(context, res.file, "text/plain")
                }
            }
            "OPEN_ASSISTANT_SETTINGS" -> {
                try {
                    val intent = android.content.Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS).apply {
                        flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    _lastActionNotice.value = "Default Assistant Settings khol diya! 🚀"
                } catch (e: Exception) {
                    try {
                        val fallbackIntent = android.content.Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).apply {
                            flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(fallbackIntent)
                        _lastActionNotice.value = "Default Apps Settings khol diya! 🚀"
                    } catch (e2: Exception) {
                        _lastActionNotice.value = "Assistant settings nahi khul paya: ${e2.message}"
                    }
                }
            }
            "CREATE_AI_APP" -> {
                val appName = if (action.appName.isNotBlank()) action.appName else if (action.target.isNotBlank()) action.target else "New Application"
                val promptToInject = if (action.prompt.isNotBlank()) {
                    action.prompt
                } else {
                    com.example.ai.AiStudioAutomationHelper.generateAiStudioPrompt(appName, appName, "Application")
                }

                // Copy generated prompt to system clipboard for instant user access & backup
                try {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                    val clip = android.content.ClipData.newPlainText("Google AI Studio Prompt", promptToInject)
                    clipboard?.setPrimaryClip(clip)
                } catch (_: Exception) {}

                openWebAutomation(
                    url = com.example.ai.AiStudioAutomationHelper.AI_STUDIO_BUILD_URL,
                    title = "AI Studio • $appName (New App)",
                    platform = "Google AI Studio",
                    query = promptToInject
                )
                _lastActionNotice.value = "Google AI Studio New App Build Mode launch ho gaya! Prompt automatically inject ho raha hai... 🚀💻"
            }
            "ORDER_ITEM" -> {
                val platform = if (action.platform.isNotBlank()) action.platform else "amazon"
                val item = if (action.item.isNotBlank()) action.item else action.target
                val targetUrl = PhoneController.getOrderUrl(platform, item)
                val displayName = platform.replaceFirstChar { it.uppercase() }
                openWebAutomation(
                    url = targetUrl,
                    title = "$displayName Shopping",
                    platform = platform,
                    query = item
                )
                _lastActionNotice.value = "$displayName par '$item' ka live order page khol diya hai! 🛒✨"
            }
            "BOOK_TRAIN_TICKET" -> {
                val origin = if (action.origin.isNotBlank()) action.origin else "Ahmedabad"
                val destination = if (action.destination.isNotBlank()) action.destination else if (action.target.isNotBlank()) action.target else "Mumbai"
                val date = if (action.date.isNotBlank()) action.date else "today"
                val platform = if (action.platform.isNotBlank()) action.platform else "confirmtkt"
                val targetUrl = PhoneController.getTrainUrl(origin, destination, date, platform)
                openWebAutomation(
                    url = targetUrl,
                    title = "Train Booking ($origin -> $destination)",
                    platform = platform,
                    query = "$origin to $destination on $date"
                )
                _lastActionNotice.value = "$origin se $destination ke liye train tickets page khol diya hai! 🚆🎫"
            }
            "OPEN_WEBSITE" -> {
                val url = if (action.target.startsWith("http")) action.target else "https://${action.target}"
                openWebAutomation(
                    url = url,
                    title = action.title.ifBlank { action.target },
                    platform = "Web",
                    query = ""
                )
                _lastActionNotice.value = "$url open kar diya hai! 🌐"
            }
        }
    }

    fun startListening(context: Context) {
        startListeningSafely(context)
    }

    fun stopListening() {
        isContinuousListeningSessionActive = false
        speechManager.stopListening()
    }

    fun speakText(text: String, resumeListeningAfter: Boolean = true, context: Context? = null) {
        val ctx: Context = context ?: getApplication<Application>()
        speechManager.speak(text) {
            if (resumeListeningAfter) {
                isContinuousListeningSessionActive = true
                viewModelScope.launch(Dispatchers.Main) {
                    kotlinx.coroutines.delay(350)
                    if (_showWebAutomation.value) {
                        startListeningForWebAutomation(ctx)
                    } else {
                        startListeningSafely(ctx)
                    }
                }
            }
        }
    }

    fun stopSpeaking() {
        speechManager.stopSpeaking()
    }

    fun selectVoice(profile: FemaleVoiceProfile) {
        speechManager.selectVoice(profile)
        _voicePitch.value = profile.pitch
        _voiceSpeed.value = profile.speed
        _lastActionNotice.value = "Voice active: ${profile.name} ${profile.avatarEmoji}"
        speechManager.speak("Haan ji Boss! Zoya ki voice ${profile.name} select ho gayi hai! ✨")
    }

    fun previewVoice(profile: FemaleVoiceProfile) {
        speechManager.previewVoice(profile)
    }

    fun addContact(name: String, phone: String, nickname: String, relationship: String, notes: String = "", isFavorite: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertContact(
                ContactEntity(
                    name = name.trim(),
                    phoneNumber = phone.trim(),
                    nickname = nickname.trim(),
                    relationship = relationship.trim(),
                    notes = notes.trim(),
                    isFavorite = isFavorite
                )
            )
            _lastActionNotice.value = "Contact saved: $name 👥"
        }
    }

    fun updateContact(contact: ContactEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateContact(contact)
            _lastActionNotice.value = "Contact updated: ${contact.name}"
        }
    }

    fun deleteContact(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteContactById(id)
        }
    }

    fun addMemory(key: String, value: String, category: String, notes: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertMemory(key, value, category, notes)
            _lastActionNotice.value = "Memory saved: $key"
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteMemoryById(id)
        }
    }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearHistory()
        }
    }

    fun updateVoiceSettings(pitch: Float, speed: Float) {
        _voicePitch.value = pitch
        _voiceSpeed.value = speed
        speechManager.pitch = pitch
        speechManager.speed = speed
    }

    fun setPersonality(level: String) {
        _personalityLevel.value = level
    }

    fun clearActionNotice() {
        _lastActionNotice.value = null
    }

    override fun onCleared() {
        super.onCleared()
        speechManager.destroy()
    }
}
