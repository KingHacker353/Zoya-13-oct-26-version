package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonPink

data class QuickSuggestion(
    val label: String,
    val command: String,
    val icon: String = "✨"
)

@Composable
fun QuickActionChips(
    onChipClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val suggestions = listOf(
        QuickSuggestion("🎙️ 'Zoya' Wake Word", "Zoya", "🎙️"),
        QuickSuggestion("😤 Siri Se Baat Karoon? (Jalan)", "Zoya, mujhe lagta hai Siri tumse zyada achi hai", "😤"),
        QuickSuggestion("😡 Gussa Karke Dikhao", "Zoya, gussa ho jao aur apna gussa dikhao", "😡"),
        QuickSuggestion("🥰 Zoya I Love You (Pyaar)", "Zoya, I love you! Tum meri favorite ho", "🥰"),
        QuickSuggestion("Boss Mood & Daily Chat 💖", "Boss mood & daily chat", "💖"),
        QuickSuggestion("AI Studio App Banao 🚀", "Google AI studio se shopping app bana do", "🚀"),
        QuickSuggestion("Website Banao 🌐", "Google AI studio se ek portfolio website bana do", "🌐"),
        QuickSuggestion("Amazon Shopping 🛒", "Amazon se smart watch order kardo", "🛒"),
        QuickSuggestion("Zomato Biryani 🍕", "Zomato se biryani order kardo", "🍕"),
        QuickSuggestion("Train Ticket Book 🚆", "Ahmedabad se Mumbai train ticket book kardo", "🚆"),
        QuickSuggestion("Blinkit Delivery 🥛", "Blinkit se doodh order kardo", "🥛"),
        QuickSuggestion("Flipkart Order 🛍️", "Flipkart se t-shirt order kardo", "🛍️"),
        QuickSuggestion("Saved Address 📍", "Mera saved delivery address dikhao", "📍"),
        QuickSuggestion("Zoya Vision Camera 📷✨", "camera kholo", "📷"),
        QuickSuggestion("Boss Mood & Daily Chat 💖", "Boss mood & daily chat", "💖"),
        QuickSuggestion("Camera Se Dekho 🔍", "ye dekho aur batao ye kya hai", "🔍"),
        QuickSuggestion("Photo Banao 🖼️", "Zoya, ek beautiful sunset cyberpunk photo bana do", "🖼️"),
        QuickSuggestion("PDF Document Banao 📄", "Zoya, ek project summary ka PDF document banao", "📄"),
        QuickSuggestion("APK App Banao 📦", "Zoya, MyQuickApp naam ka APK app banao", "📦"),
        QuickSuggestion("Video Banao 🎬", "Zoya, ek animated short video clip banao", "🎬"),
        QuickSuggestion("Default Assistant Bano 👑", "Zoya ko phone ka default assistant bana do", "👑"),
        QuickSuggestion("App Kaise Banaye? 💻", "Android app kaise banaye step by step?", "💻"),
        QuickSuggestion("Super-Smart AI 🧠", "Tum ChatGPT aur Claude se kitni smart ho?", "🧠"),
        QuickSuggestion("इस्लामिक हब 🕌", "Zoya, Islamic Hub open karo", "🕌"),
        QuickSuggestion("सूरह फ़ातिहा 📖", "Zoya, Surah Fatiha sunao", "📖"),
        QuickSuggestion("आयतल कुर्सी ✨", "Zoya, Ayat ul Kursi padho", "✨"),
        QuickSuggestion("नात शरीफ़ 🌺", "Zoya, ek pyari Naat Sharif sunao", "🌺"),
        QuickSuggestion("इक़बाल की शायरी ✒️", "Zoya, Allama Iqbal ka sher sunao", "✒️"),
        QuickSuggestion("डिजिटल तस्बीह 📿", "Zoya, digital tasbeeh kholo", "📿"),
        QuickSuggestion("WhatsApp मैसेज 💬", "Zoya, WhatsApp par sarkar ko message karo ki main aa raha hoon", "💬"),
        QuickSuggestion("Wallpaper बदलो 🎨", "Zoya, phone ka wallpaper change kar do", "🎨"),
        QuickSuggestion("Call लगाओ 📞", "Zoya, Sarkar ko call lagao", "📞"),
        QuickSuggestion("Screen Home जाओ 🏠", "Home screen par jao", "🏠"),
        QuickSuggestion("YouTube गाना 🎬", "Zoya, YouTube par latest trending song chala do", "🎬"),
        QuickSuggestion("Spotify बजाओ 🎵", "Zoya, Spotify mein mera favourite playlist chala do", "🎵"),
        QuickSuggestion("Notification दिखाओ 🔔", "Notification panel open karo", "🔔"),
        QuickSuggestion("Google Search 🔍", "Google par search karo today weather news", "🔍"),
        QuickSuggestion("WiFi Settings ⚙️", "Zoya, WiFi settings open kar do", "⚙️"),
        QuickSuggestion("Flashlight ऑन 💡", "Flashlight on karo", "💡"),
        QuickSuggestion("अलार्म लगाओ ⏰", "Mujhe kal subah 8 baje uthana", "⏰"),
        QuickSuggestion("Creator कौन है? 👑", "Tumhe kisne banaya hai aur tumhara home location kya hai?", "👑")
    )

    Row(
        modifier = modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (item in suggestions) {
            AssistChip(
                onClick = { onChipClick(item.command) },
                label = {
                    Text(
                        text = "${item.icon} ${item.label}",
                        style = MaterialTheme.typography.labelMedium,
                        fontSize = 12.sp
                    )
                },
                shape = RoundedCornerShape(20.dp),
                colors = AssistChipDefaults.assistChipColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                border = AssistChipDefaults.assistChipBorder(
                    enabled = true,
                    borderColor = NeonPink.copy(alpha = 0.35f),
                    borderWidth = 1.dp
                ),
                modifier = Modifier.testTag("quick_chip_${item.label.take(8)}")
            )
        }
    }
}
