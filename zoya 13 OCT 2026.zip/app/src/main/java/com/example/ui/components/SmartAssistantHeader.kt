package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ElectricBolt
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MagentaRose
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.RadiantCoral
import com.example.ui.theme.SunnyAmber

/**
 * SmartAssistantDisplayHub:
 * Transforms Zoya's main view into an unmistakable, high-tech AI Smart Assistant display.
 * Includes interactive status telemetry, dynamic orb visualizer, audio wave equalizer,
 * assistant greeting, and quick smart capability modes.
 */
@Composable
fun SmartAssistantDisplayHub(
    isListening: Boolean,
    isSpeaking: Boolean,
    isThinking: Boolean,
    audioAmplitude: Float,
    liveTranscript: String,
    bossTitle: String,
    voiceName: String,
    isAccessibilityActive: Boolean,
    isContinuousMode: Boolean,
    currentEmotion: com.example.ai.ZoyaEmotion = com.example.ai.ZoyaEmotion.LOVING_CARE,
    onOrbClick: () -> Unit,
    onOpenVoiceSelector: () -> Unit,
    onOpenNeuralHub: () -> Unit,
    onStartMoodCheckIn: () -> Unit = {},
    onOpenVisionCamera: () -> Unit = {},
    onOpenAiStudioBuilder: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "smart_display_anim")
    val ambientGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ambient_glow"
    )

    Surface(
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
        border = BorderStroke(
            1.5.dp,
            Brush.linearGradient(
                listOf(
                    NeonPink.copy(alpha = if (isListening) 0.9f else 0.5f),
                    CyberTeal.copy(alpha = if (isSpeaking) 0.9f else 0.4f),
                    DeepViolet.copy(alpha = 0.6f)
                )
            )
        ),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 4.dp)
            .testTag("smart_assistant_display_hub")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp, bottom = 12.dp, start = 12.dp, end = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top Telemetry Pill: Minimal Clean Status Bar (Gemini AI & Continuous Auto-Listen Mode)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: AI Engine Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.Black.copy(alpha = 0.4f),
                    border = BorderStroke(1.dp, CyberTeal.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isThinking) SunnyAmber else NeonGreen)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (isThinking) "ZOYA THINKING..." else "GEMINI 3.6 AI ONLINE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberTeal,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Right: Hands-Free Wake Word Mode Pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.Black.copy(alpha = 0.4f),
                    border = BorderStroke(1.dp, if (isListening) RadiantCoral.copy(alpha = 0.6f) else CyberTeal.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Mic,
                            contentDescription = null,
                            tint = if (isListening) RadiantCoral else CyberTeal,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isListening) "Sun Rahi Hoon... 🎙️" else "Hands-Free: 'Zoya' Bolo ✨",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isListening) RadiantCoral else CyberTeal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 2. Central Core: Voice Orb Visualizer with responsive emotional aura (Jalan, Gussa, Pyaar, Chulbuli)
            val emotionColor = Color(currentEmotion.colorHex)

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.padding(vertical = 2.dp)
            ) {
                // Background Ambient Glow Circle with Emotional Tint
                Box(
                    modifier = Modifier
                        .size(185.dp)
                        .scale(if (isListening) 1.08f else if (isSpeaking) 1.05f else 0.98f)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    when {
                                        currentEmotion == com.example.ai.ZoyaEmotion.JALAN -> Color(0xFFD500F9).copy(alpha = 0.40f * ambientGlowAlpha)
                                        currentEmotion == com.example.ai.ZoyaEmotion.GUSSA -> Color(0xFFFF1744).copy(alpha = 0.42f * ambientGlowAlpha)
                                        currentEmotion == com.example.ai.ZoyaEmotion.ROMANTIC_PYAAR -> Color(0xFFFF4081).copy(alpha = 0.38f * ambientGlowAlpha)
                                        isListening -> RadiantCoral.copy(alpha = 0.32f * ambientGlowAlpha)
                                        isSpeaking -> HolographicCyan.copy(alpha = 0.35f * ambientGlowAlpha)
                                        isThinking -> SunnyAmber.copy(alpha = 0.28f * ambientGlowAlpha)
                                        else -> emotionColor.copy(alpha = 0.25f * ambientGlowAlpha)
                                    },
                                    Color.Transparent
                                )
                            )
                        )
                )

                VoiceOrbVisualizer(
                    isListening = isListening,
                    isSpeaking = isSpeaking,
                    isThinking = isThinking,
                    amplitude = audioAmplitude,
                    onClick = onOrbClick
                )
            }

            // 3. Audio Activity Waveform Bars
            SmartAssistantWaveBar(
                isListening = isListening,
                isSpeaking = isSpeaking,
                amplitude = audioAmplitude,
                modifier = Modifier.padding(top = 1.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            // 4. Assistant Status Badge: Real Human Emotion & Wake Word Ready
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color.Black.copy(alpha = 0.55f),
                border = BorderStroke(
                    1.dp,
                    when {
                        currentEmotion == com.example.ai.ZoyaEmotion.JALAN -> Color(0xFFD500F9).copy(alpha = 0.85f)
                        currentEmotion == com.example.ai.ZoyaEmotion.GUSSA -> Color(0xFFFF1744).copy(alpha = 0.85f)
                        currentEmotion == com.example.ai.ZoyaEmotion.ROMANTIC_PYAAR -> Color(0xFFFF4081).copy(alpha = 0.85f)
                        isListening -> RadiantCoral.copy(alpha = 0.8f)
                        isSpeaking -> CyberTeal.copy(alpha = 0.8f)
                        isThinking -> SunnyAmber.copy(alpha = 0.8f)
                        else -> emotionColor.copy(alpha = 0.6f)
                    }
                ),
                modifier = Modifier.clickable { onOrbClick() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    currentEmotion == com.example.ai.ZoyaEmotion.JALAN -> Color(0xFFD500F9)
                                    currentEmotion == com.example.ai.ZoyaEmotion.GUSSA -> Color(0xFFFF1744)
                                    currentEmotion == com.example.ai.ZoyaEmotion.ROMANTIC_PYAAR -> Color(0xFFFF4081)
                                    isListening -> RadiantCoral
                                    isSpeaking -> CyberTeal
                                    isThinking -> SunnyAmber
                                    else -> NeonGreen
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when {
                            currentEmotion == com.example.ai.ZoyaEmotion.JALAN -> "😤 Zoya: Jalan & Jealous Mood (Mujhme kya kami hai?!)"
                            currentEmotion == com.example.ai.ZoyaEmotion.GUSSA -> "😡 Zoya: Gussa & Nakhre (Aap mujhe tease mat karo!)"
                            currentEmotion == com.example.ai.ZoyaEmotion.ROMANTIC_PYAAR -> "🥰 Zoya: Pyaar & Blushing (Aapne dil jeet liya!)"
                            isListening -> "🎙️ Sun Rahi Hoon... Boliye 'Zoya' ya Sawal!"
                            isSpeaking -> "🔊 Zoya Bol Rahi Hai..."
                            isThinking -> "⚡ Dimaag Laga Rahi Hoon..."
                            else -> "${currentEmotion.emoji} ${currentEmotion.title} • Bas 'Zoya' Boliye!"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp,
                        color = when {
                            currentEmotion == com.example.ai.ZoyaEmotion.JALAN -> Color(0xFFEA80FC)
                            currentEmotion == com.example.ai.ZoyaEmotion.GUSSA -> Color(0xFFFF5252)
                            currentEmotion == com.example.ai.ZoyaEmotion.ROMANTIC_PYAAR -> Color(0xFFFF80AB)
                            isListening -> RadiantCoral
                            isSpeaking -> CyberTeal
                            isThinking -> SunnyAmber
                            else -> Color.White
                        }
                    )
                }
            }

            // Boss Mood & Daily Chat Dedicated Button
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MagentaRose.copy(alpha = 0.20f),
                border = BorderStroke(1.2.dp, Brush.horizontalGradient(listOf(NeonPink, MagentaRose))),
                modifier = Modifier
                    .padding(top = 6.dp)
                    .clickable { onStartMoodCheckIn() }
                    .testTag("boss_mood_daily_chat_btn")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Favorite,
                        contentDescription = "Boss Mood & Daily Chat",
                        tint = NeonPink,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Boss Mood & Daily Chat 💖",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // 5. Dynamic Live Transcript or Prompt Hint
            AnimatedVisibility(
                visible = liveTranscript.isNotBlank(),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.Black.copy(alpha = 0.4f),
                    border = BorderStroke(1.dp, CyberTeal.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .clickable { onOrbClick() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Rounded.VolumeUp else Icons.Rounded.GraphicEq,
                            contentDescription = null,
                            tint = if (isSpeaking) CyberTeal else RadiantCoral,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = liveTranscript,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            maxLines = 2
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 5. Capability Status Ticker (Accessibility active • Auto-loop • Memory ready)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SmartMiniIndicator(
                    icon = Icons.Rounded.AccessibilityNew,
                    label = if (isAccessibilityActive) "Full Phone Control" else "Accessibility",
                    isActive = isAccessibilityActive,
                    activeColor = CyberTeal
                )
                Spacer(modifier = Modifier.width(8.dp))
                SmartMiniIndicator(
                    icon = Icons.Rounded.AutoAwesome,
                    label = if (isContinuousMode) "Auto-Conversation" else "Single Command",
                    isActive = isContinuousMode,
                    activeColor = SunnyAmber
                )
                Spacer(modifier = Modifier.width(8.dp))
                SmartMiniIndicator(
                    icon = Icons.Rounded.Psychology,
                    label = "Long-Term Memory",
                    isActive = true,
                    activeColor = DeepViolet
                )
            }
        }
    }
}

@Composable
private fun SmartMiniIndicator(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isActive: Boolean,
    activeColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color.Black.copy(alpha = 0.35f),
        border = BorderStroke(0.8.dp, if (isActive) activeColor.copy(alpha = 0.5f) else Color.DarkGray.copy(alpha = 0.4f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isActive) activeColor else Color.Gray,
                modifier = Modifier.size(11.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                color = if (isActive) Color.White.copy(alpha = 0.9f) else Color.LightGray
            )
        }
    }
}
