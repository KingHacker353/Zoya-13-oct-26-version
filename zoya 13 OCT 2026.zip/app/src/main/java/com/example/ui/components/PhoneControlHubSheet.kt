package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.BubbleChart
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Message
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SheetState
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.device.PhoneController
import com.example.device.SmartLockController
import com.example.service.ZoyaAccessibilityService
import com.example.service.ZoyaFloatingService
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MagentaRose
import com.example.ui.theme.NeonPink
import com.example.ui.theme.RadiantCoral
import com.example.ui.theme.SunnyAmber

data class QuickAppItem(
    val name: String,
    val icon: ImageVector,
    val color: Color,
    val appKey: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneControlHubSheet(
    onDismiss: () -> Unit,
    sheetState: SheetState,
    onExecuteActionFeedback: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var flashlightState by remember { mutableStateOf(false) }
    var volumeSlider by remember { mutableFloatStateOf(0.7f) }
    var whatsappMessage by remember { mutableStateOf("Main aa raha hoon!") }
    var whatsappTarget by remember { mutableStateOf("Sarkar") }
    var callNumber by remember { mutableStateOf("Sarkar") }

    var savedPattern by remember { mutableStateOf(SmartLockController.getSavedPattern(context)) }
    var savedPin by remember { mutableStateOf(SmartLockController.getSavedPin(context)) }
    var autoListenOnUnlock by remember { mutableStateOf(SmartLockController.isAutoListenOnUnlockEnabled(context)) }
    var currentPatternInput by remember { mutableStateOf<List<Int>>(emptyList()) }
    var showPatternEditor by remember { mutableStateOf(false) }
    var youtubeSearchQuery by remember { mutableStateOf("") }

    val quickApps = listOf(
        QuickAppItem("WhatsApp", Icons.Rounded.Message, Color(0xFF25D366), "whatsapp"),
        QuickAppItem("Instagram", Icons.Rounded.PhotoLibrary, Color(0xFFE1306C), "instagram"),
        QuickAppItem("YouTube", Icons.Rounded.PlayArrow, Color(0xFFFF0000), "youtube"),
        QuickAppItem("Spotify", Icons.Rounded.Headphones, Color(0xFF1DB954), "spotify"),
        QuickAppItem("Camera", Icons.Rounded.CameraAlt, CyberTeal, "camera"),
        QuickAppItem("Maps", Icons.Rounded.Map, Color(0xFF4285F4), "maps"),
        QuickAppItem("Alarm / Clock", Icons.Rounded.Alarm, SunnyAmber, "clock"),
        QuickAppItem("Contacts", Icons.Rounded.Contacts, RadiantCoral, "contacts"),
        QuickAppItem("Settings", Icons.Rounded.Settings, Color.Gray, "settings"),
        QuickAppItem("Calculator", Icons.Rounded.Calculate, DeepViolet, "calculator")
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 28.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(CyberTeal, DeepViolet))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Smartphone,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Phone Control & Multi-Tasking Hub 🚀",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Real Android intents & hardware controls",
                        style = MaterialTheme.typography.bodySmall,
                        color = MagentaRose
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Background Floating Mode Card
            val isFloatingRunning by ZoyaFloatingService.isServiceRunning.collectAsState()
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isFloatingRunning) Brush.linearGradient(listOf(NeonPink, CyberTeal)) else Brush.linearGradient(listOf(Color.DarkGray, Color.DarkGray)),
                        RoundedCornerShape(16.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(NeonPink, DeepViolet))),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.BubbleChart,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Floating Assistant (Background)",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = if (isFloatingRunning) "Active! WhatsApp, YouTube ke upar chalega" else "Screen par floating bubble on karein",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (isFloatingRunning) CyberTeal else Color.LightGray,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = isFloatingRunning,
                            onCheckedChange = { enable ->
                                if (enable) {
                                    if (Settings.canDrawOverlays(context)) {
                                        ZoyaFloatingService.startService(context)
                                        Toast.makeText(context, "Zoya Floating Assistant Shuru! 💖", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val intent = Intent(
                                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:${context.packageName}")
                                        ).apply {
                                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                        }
                                        context.startActivity(intent)
                                        Toast.makeText(context, "Overlay permission allow karein", Toast.LENGTH_LONG).show()
                                    }
                                } else {
                                    ZoyaFloatingService.stopService(context)
                                    Toast.makeText(context, "Floating Assistant band ho gaya", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = NeonPink,
                                uncheckedThumbColor = Color.LightGray,
                                uncheckedTrackColor = Color.DarkGray
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Hardware Toggles Card (Flashlight & Volume)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Device Hardware Controls ⚙️",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = NeonPink
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Flashlight Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.FlashlightOn,
                                contentDescription = null,
                                tint = if (flashlightState) SunnyAmber else Color.Gray,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Flashlight / Torch",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (flashlightState) "ON 💡" else "OFF 🔦",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Switch(
                            checked = flashlightState,
                            onCheckedChange = {
                                flashlightState = it
                                val res = PhoneController.toggleFlashlight(it, context)
                                onExecuteActionFeedback(res.description)
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = NeonPink)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Volume Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.VolumeUp,
                                contentDescription = null,
                                tint = CyberTeal,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Volume Control (${(volumeSlider * 100).toInt()}%)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Button(
                                onClick = {
                                    val res = PhoneController.adjustVolume("down", context)
                                    onExecuteActionFeedback(res.description)
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("🔉 -", fontSize = 11.sp)
                            }
                            Button(
                                onClick = {
                                    val res = PhoneController.adjustVolume("up", context)
                                    onExecuteActionFeedback(res.description)
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("🔊 +", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Screen Lock & Pattern / PIN Unlock Controls (User Requested)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Screen Lock & Pattern / PIN 🔒🔓",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = SunnyAmber
                        )
                        Text(
                            text = if (savedPattern.isNotEmpty()) "Pattern Active" else if (savedPin.isNotBlank()) "PIN Active" else "Swipe Mode",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (savedPattern.isNotEmpty() || savedPin.isNotBlank()) CyberTeal else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val res = PhoneController.lockScreen(context)
                                onExecuteActionFeedback(res.description)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Lock Screen 🔒", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val res = PhoneController.unlockScreen(context)
                                onExecuteActionFeedback(res.description)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberTeal),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Rounded.LockOpen, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Unlock Screen 🔓", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Saved Status summary
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Black.copy(alpha = 0.25f))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (savedPattern.isNotEmpty()) "Configured Pattern: ${savedPattern.joinToString(" -> ")}"
                                    else if (savedPin.isNotBlank()) "Configured PIN: $savedPin"
                                    else "Koi Pattern ya PIN set nahi hai (Standard swipe)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White
                                )
                                Text(
                                    text = "Voice command: 'Zoya mera pattern hai 1 2 3 5 9' ya 'Phone unlock karo'",
                                    fontSize = 10.sp,
                                    color = SunnyAmber
                                )
                            }
                            Button(
                                onClick = { showPatternEditor = !showPatternEditor },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DeepViolet),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(if (showPatternEditor) "Hide" else "Setup ⚙️", fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Auto Listen on Unlock switch
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.Black.copy(alpha = 0.25f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Unlock hone par Voice sunna 🎤",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = CyberTeal
                                )
                                Text(
                                    text = "Phone unlock hote hi Zoya mic on karke aapka voice command sunegi",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = autoListenOnUnlock,
                                onCheckedChange = { enabled ->
                                    autoListenOnUnlock = enabled
                                    SmartLockController.setAutoListenOnUnlock(context, enabled)
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = NeonPink
                                )
                            )
                        }
                    }

                    if (showPatternEditor) {
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "3x3 Pattern Dots (Sequence me tap karein 1 se 9):",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Selected sequence preview
                        Text(
                            text = if (currentPatternInput.isNotEmpty()) "Sequence: ${currentPatternInput.joinToString(" -> ")}" else "Neeche dots (1 to 9) par tap karein",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberTeal
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // 3x3 Grid
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            for (row in 0..2) {
                                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                    for (col in 0..2) {
                                        val dotNumber = row * 3 + col + 1
                                        val isSelected = currentPatternInput.contains(dotNumber)
                                        val orderIndex = currentPatternInput.indexOf(dotNumber)
                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .clip(CircleShape)
                                                .background(if (isSelected) NeonPink else Color.DarkGray)
                                                .border(2.dp, if (isSelected) CyberTeal else Color.Gray, CircleShape)
                                                .clickable {
                                                    if (!currentPatternInput.contains(dotNumber)) {
                                                        currentPatternInput = currentPatternInput + dotNumber
                                                    }
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = if (isSelected) "${orderIndex + 1}" else "$dotNumber",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                        }
                                    }
                                }
                                if (row < 2) Spacer(modifier = Modifier.height(10.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (currentPatternInput.isNotEmpty()) {
                                        SmartLockController.savePattern(context, currentPatternInput)
                                        savedPattern = currentPatternInput
                                        onExecuteActionFeedback("Pattern (${currentPatternInput.joinToString("->")}) save ho gaya! 🔐")
                                    }
                                },
                                enabled = currentPatternInput.isNotEmpty(),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberTeal),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Save 💾", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { currentPatternInput = emptyList() },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                                modifier = Modifier.weight(0.7f)
                            ) {
                                Text("Reset 🔄", fontSize = 11.sp)
                            }

                            if (savedPattern.isNotEmpty()) {
                                Button(
                                    onClick = {
                                        SmartLockController.clearPattern(context)
                                        savedPattern = emptyList()
                                        currentPatternInput = emptyList()
                                        onExecuteActionFeedback("Pattern delete kar diya! 🗑️")
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MagentaRose),
                                    modifier = Modifier.weight(0.8f)
                                ) {
                                    Text("Delete ❌", fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Test Pattern Draw Button
                        Button(
                            onClick = {
                                val testPattern = currentPatternInput.ifEmpty { savedPattern }
                                if (testPattern.isNotEmpty()) {
                                    ZoyaAccessibilityService.drawPatternGesture(testPattern) { success ->
                                        onExecuteActionFeedback(if (success) "Pattern gesture screen par draw kar diya! ✏️✨" else "Accessibility service gesture perform nahi kar saki")
                                    }
                                } else {
                                    onExecuteActionFeedback("Pehle pattern dots select karein!")
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = DeepViolet),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Test Gesture Draw on Screen ✏️", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // YouTube Instant Search & Video Auto-Playback Box (User Requested)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "YouTube Auto Video Playback 🎬🍿",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFF0000)
                        )
                        Text(
                            text = "Auto Click & Play",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberTeal
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Video search karke direct playback shuru hoga: boliye 'Zoya YouTube par gaana chalao'!",
                        fontSize = 11.sp,
                        color = Color.LightGray
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = youtubeSearchQuery,
                        onValueChange = { youtubeSearchQuery = it },
                        label = { Text("Video ya gaane ka naam") },
                        placeholder = { Text("e.g. Arijit Singh Songs, Funny Reels...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            val res = PhoneController.searchYouTube(youtubeSearchQuery.ifBlank { "trending songs" }, context)
                            onExecuteActionFeedback(res.description)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF0000)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Search & Play Video Directly 🎬", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // WhatsApp Quick Sender Box
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Direct WhatsApp & Call Dispatcher 💬📞",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF25D366)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = whatsappTarget,
                        onValueChange = { whatsappTarget = it },
                        label = { Text("Contact Name / Number") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = whatsappMessage,
                        onValueChange = { whatsappMessage = it },
                        label = { Text("WhatsApp Message Text") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val res = PhoneController.sendWhatsApp(whatsappTarget, whatsappMessage, context)
                                onExecuteActionFeedback(res.description)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Rounded.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Send WhatsApp", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                val res = PhoneController.callPhone(whatsappTarget, context)
                                onExecuteActionFeedback(res.description)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DeepViolet),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Rounded.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call Contact", fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // App Launcher Grid
            Text(
                text = "Instant App Launchers 📱",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(5),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(quickApps) { app ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                val res = PhoneController.openApp(app.appKey, context)
                                onExecuteActionFeedback(res.description)
                            }
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(app.color.copy(alpha = 0.18f))
                                .border(1.dp, app.color.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = app.icon,
                                contentDescription = app.name,
                                tint = app.color,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = app.name,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            maxLines = 1
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Dynamic Wallpaper Customizer Section (Requested by User)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AI Aesthetic Wallpaper Changer 🎨",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = NeonPink
                        )
                        Text(
                            text = "Full Access",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTeal,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Voice se boliye 'Zoya wallpaper change karo' ya neeche diye aesthetic theme par tap karein:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val wallpaperThemes = listOf(
                        "Romantic Pink" to "pink",
                        "Cyber Neon" to "blue",
                        "AMOLED Dark" to "dark",
                        "Sunset Glow" to "sunset",
                        "Nature Mint" to "nature",
                        "Galaxy Purple" to "galaxy"
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        wallpaperThemes.take(3).forEach { (label, theme) ->
                            Button(
                                onClick = {
                                    val res = PhoneController.changeWallpaper(theme, context)
                                    onExecuteActionFeedback(res.description)
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = DeepViolet),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(label.substringBefore(" "), fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        wallpaperThemes.drop(3).forEach { (label, theme) ->
                            Button(
                                onClick = {
                                    val res = PhoneController.changeWallpaper(theme, context)
                                    onExecuteActionFeedback(res.description)
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MagentaRose),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(label.substringBefore(" "), fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}
