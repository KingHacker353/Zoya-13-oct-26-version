package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.FemaleVoiceProfile
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MagentaRose
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SunnyAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceSelectorSheet(
    availableVoices: List<FemaleVoiceProfile>,
    selectedVoice: FemaleVoiceProfile,
    onSelectVoice: (FemaleVoiceProfile) -> Unit,
    onPreviewVoice: (FemaleVoiceProfile) -> Unit,
    onUpdateVoiceTuning: (pitch: Float, speed: Float) -> Unit,
    onDismiss: () -> Unit,
    sheetState: SheetState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var pitchSlider by remember { mutableFloatStateOf(selectedVoice.pitch) }
    var speedSlider by remember { mutableFloatStateOf(selectedVoice.speed) }
    var showFineTuning by remember { mutableStateOf(false) }

    var savedApiKey by remember { mutableStateOf(com.example.data.ZoyaPreferences.getGeminiApiKey(context)) }
    var isEditingKey by remember { mutableStateOf(false) }
    var keyInputValue by remember { mutableStateOf(savedApiKey) }
    var keyStatusMsg by remember { mutableStateOf<String?>(null) }
    val isKeyConfigured = savedApiKey.isNotBlank() && savedApiKey != "MY_GEMINI_API_KEY"

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 32.dp)
        ) {
            // Sheet Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(NeonPink, MagentaRose))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.RecordVoiceOver,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Zoya Gemini AI Voices 🎙️✨",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "100% Gemini API Key Neural Speech • No Robotic Voice",
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonPink
                        )
                    }
                }

                OutlinedButton(
                    onClick = { showFineTuning = !showFineTuning },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("fine_tune_voice_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Tune,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (showFineTuning) "Hide" else "Tune", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Top Active Voice Status Banner
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.5.dp, if (selectedVoice.isGeminiVoice) CyberTeal else NeonPink),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    if (selectedVoice.isGeminiVoice) listOf(CyberTeal, DeepViolet)
                                    else listOf(NeonPink, MagentaRose)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(selectedVoice.avatarEmoji, fontSize = 18.sp)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Active: ${selectedVoice.name}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = if (selectedVoice.isGeminiVoice) "⚡ Gemini AI Neural Voice Engine Active" else "🔊 System High-Definition Speech Engine",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = if (selectedVoice.isGeminiVoice) CyberTeal else NeonPink
                        )
                    }
                }
            }

            // Voice Fine Tuning Sliders
            if (showFineTuning) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Voice Pitch / Tone", style = MaterialTheme.typography.labelMedium)
                            Text(
                                "%.2f (Higher = Sweeter)".format(pitchSlider),
                                style = MaterialTheme.typography.labelSmall,
                                color = MagentaRose
                            )
                        }
                        Slider(
                            value = pitchSlider,
                            onValueChange = {
                                pitchSlider = it
                                onUpdateVoiceTuning(pitchSlider, speedSlider)
                            },
                            valueRange = 0.8f..1.5f,
                            colors = SliderDefaults.colors(thumbColor = NeonPink, activeTrackColor = NeonPink)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Speech Speed / Tempo", style = MaterialTheme.typography.labelMedium)
                            Text(
                                "%.2fx".format(speedSlider),
                                style = MaterialTheme.typography.labelSmall,
                                color = DeepViolet
                            )
                        }
                        Slider(
                            value = speedSlider,
                            onValueChange = {
                                speedSlider = it
                                onUpdateVoiceTuning(pitchSlider, speedSlider)
                            },
                            valueRange = 0.8f..1.4f,
                            colors = SliderDefaults.colors(thumbColor = DeepViolet, activeTrackColor = DeepViolet)
                        )
                    }
                }
            }

            // Gemini API Key Status & Quick Config Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isKeyConfigured) CyberTeal.copy(alpha = 0.12f) else SunnyAmber.copy(alpha = 0.15f)
                ),
                border = BorderStroke(1.dp, if (isKeyConfigured) CyberTeal.copy(alpha = 0.4f) else SunnyAmber.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Key,
                                contentDescription = null,
                                tint = if (isKeyConfigured) CyberTeal else SunnyAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isKeyConfigured) "Gemini API Key Active 🚀" else "Gemini API Key Required 🔑",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isKeyConfigured) CyberTeal else SunnyAmber
                            )
                        }

                        OutlinedButton(
                            onClick = { isEditingKey = !isEditingKey },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Icon(
                                imageVector = if (isEditingKey) Icons.Rounded.Check else Icons.Rounded.Edit,
                                contentDescription = null,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isEditingKey) "Close" else if (isKeyConfigured) "Change" else "Add Key", fontSize = 10.sp)
                        }
                    }

                    if (isEditingKey || !isKeyConfigured) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Gemini voices (Aoede, Kore, Puck, Leda, Zephyr) use your Gemini API key for ultra-realistic neural speech:",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = keyInputValue,
                                onValueChange = { keyInputValue = it },
                                placeholder = { Text("AIzaSy...", fontSize = 11.sp) },
                                singleLine = true,
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberTeal,
                                    unfocusedBorderColor = CyberTeal.copy(alpha = 0.4f)
                                ),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("gemini_key_input_sheet")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val trimmedKey = keyInputValue.trim()
                                    com.example.data.ZoyaPreferences.setGeminiApiKey(context, trimmedKey)
                                    savedApiKey = trimmedKey
                                    isEditingKey = false
                                    keyStatusMsg = "Key saved! Gemini voices activated ✨"
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberTeal),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Save", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (keyStatusMsg != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = keyStatusMsg ?: "",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen
                        )
                    }
                }
            }

            // Voice List
            Text(
                text = "GEMINI AI NEURAL VOICES (${availableVoices.size}) • API KEY EXCLUSIVE ⚡",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(360.dp)
            ) {
                items(availableVoices, key = { it.id }) { voice ->
                    val isSelected = selectedVoice.id == voice.id

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) NeonPink.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectVoice(voice)
                                pitchSlider = voice.pitch
                                speedSlider = voice.speed
                            }
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) NeonPink else Color.Transparent,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .testTag("voice_item_${voice.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Emoji / Avatar & Voice Info
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isSelected) Brush.linearGradient(listOf(NeonPink, MagentaRose))
                                            else Brush.linearGradient(listOf(DeepViolet.copy(alpha = 0.4f), CyberTeal.copy(alpha = 0.4f)))
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = voice.avatarEmoji,
                                        fontSize = 20.sp
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = voice.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        if (isSelected) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                imageVector = Icons.Rounded.CheckCircle,
                                                contentDescription = "Active",
                                                tint = NeonPink,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                    if (voice.isGeminiVoice) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    Brush.horizontalGradient(listOf(CyberTeal.copy(alpha = 0.25f), NeonPink.copy(alpha = 0.25f))),
                                                    RoundedCornerShape(6.dp)
                                                )
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "✨ GEMINI VOICE ENGINE (${voice.geminiVoiceName})",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = CyberTeal
                                            )
                                        }
                                    }
                                    Text(
                                        text = voice.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isSelected) MagentaRose else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Preview & Select Buttons
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                IconButton(
                                    onClick = { onPreviewVoice(voice) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(DeepViolet.copy(alpha = 0.25f), CircleShape)
                                        .testTag("preview_voice_${voice.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.VolumeUp,
                                        contentDescription = "Preview",
                                        tint = if (isSelected) NeonPink else Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Button(
                                    onClick = {
                                        onSelectVoice(voice)
                                        pitchSlider = voice.pitch
                                        speedSlider = voice.speed
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) NeonPink else CyberTeal.copy(alpha = 0.85f),
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("select_voice_btn_${voice.id}")
                                ) {
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Rounded.CheckCircle,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Active", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    } else {
                                        Text("Select", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
