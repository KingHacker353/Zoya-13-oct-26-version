package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Camera
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.FlashOff
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.FlipCameraAndroid
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import android.media.ExifInterface
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MagentaRose
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.SunnyAmber
import java.io.File
import java.io.InputStream
import java.util.concurrent.Executors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZoyaVisionCameraSheet(
    isAnalyzing: Boolean,
    analysisResult: String?,
    capturedBitmap: Bitmap?,
    onCaptureImage: (Bitmap, String) -> Unit,
    onSpeakResult: (String) -> Unit,
    onDismiss: () -> Unit,
    isSpeaking: Boolean = false,
    onStopSpeaking: () -> Unit = {},
    isListening: Boolean = false,
    audioAmplitude: Float = 0f,
    liveTranscript: String = "",
    onStartListening: (Bitmap?) -> Unit = {},
    onStopListening: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    // Camera State
    var lensFacing by remember { mutableStateOf(CameraSelector.LENS_FACING_BACK) }
    var isTorchOn by remember { mutableStateOf(false) }
    var currentCamera by remember { mutableStateOf<Camera?>(null) }
    var imageCaptureUseCase by remember { mutableStateOf<ImageCapture?>(null) }

    var selectedQuestionPrompt by remember {
        mutableStateOf("Is photo ko ghaur se dekho aur iske baare me POORI DETAILS (Full In-Depth Breakdown, Features, Working, Solutions aur Tips) samjhao bina kisi kami ke!")
    }
    var isResultExpanded by remember { mutableStateOf(false) }
    var followUpInput by remember { mutableStateOf("") }
    var localCapturedBitmap by remember { mutableStateOf<Bitmap?>(capturedBitmap) }

    // Synchronize bitmap when external state updates
    LaunchedEffect(capturedBitmap) {
        if (capturedBitmap != null) {
            localCapturedBitmap = capturedBitmap
        }
    }

    // Gallery Picker launcher
    val galleryPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (bitmap != null) {
                    localCapturedBitmap = bitmap
                    onCaptureImage(bitmap, selectedQuestionPrompt)
                }
            } catch (e: Exception) {
                android.util.Log.e("ZoyaVision", "Error loading image from gallery", e)
            }
        }
    }

    androidx.activity.compose.BackHandler {
        if (localCapturedBitmap != null && analysisResult != null) {
            localCapturedBitmap = null
        } else {
            onDismiss()
        }
    }

    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "vision_anim")
    val laserOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "laser_scan"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shutter_pulse"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (!hasCameraPermission) {
            // Permission Request Card
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(NeonPink, DeepViolet))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CameraAlt,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "Zoya Vision Camera 📷✨",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Zoya ko camera se dikhane ke liye Camera permission allow kijiye taaki Zoya har object, book, text aur problem dekh kar bol sake!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(28.dp))
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(52.dp)
                        .testTag("request_camera_perm_btn")
                ) {
                    Icon(imageVector = Icons.Rounded.Camera, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Camera Allow Karein 📸", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { galleryPickerLauncher.launch("image/*") },
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberTeal.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth(0.85f)
                ) {
                    Icon(imageVector = Icons.Rounded.Image, contentDescription = null, tint = CyberTeal)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Gallery Se Photo Chunein 🖼️", color = Color.White)
                }
                Spacer(modifier = Modifier.height(16.dp))
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                }
            }
        } else {
            // Live Camera View or Captured Photo
            if (localCapturedBitmap != null) {
                // Show frozen captured frame
                Image(
                    bitmap = localCapturedBitmap!!.asImageBitmap(),
                    contentDescription = "Captured Photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Laser Scan Animation when analyzing
                if (isAnalyzing) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.35f))
                    ) {
                        // Vertical moving laser beam
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .align(Alignment.TopCenter)
                                .padding(top = (laserOffset * 650).dp)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            Color.Transparent,
                                            CyberTeal,
                                            NeonPink,
                                            CyberTeal,
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                    }
                }
            } else {
                // Live CameraX Preview
                key(lensFacing) {
                    AndroidView(
                        factory = { ctx ->
                            val previewView = PreviewView(ctx).apply {
                                scaleType = PreviewView.ScaleType.FILL_CENTER
                            }
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                            cameraProviderFuture.addListener({
                                val cameraProvider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }
                                val imageCapture = ImageCapture.Builder()
                                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                                    .build()
                                imageCaptureUseCase = imageCapture

                                val cameraSelector = CameraSelector.Builder()
                                    .requireLensFacing(lensFacing)
                                    .build()

                                try {
                                    cameraProvider.unbindAll()
                                    currentCamera = cameraProvider.bindToLifecycle(
                                        lifecycleOwner,
                                        cameraSelector,
                                        preview,
                                        imageCapture
                                    )
                                } catch (e: Exception) {
                                    android.util.Log.e("ZoyaVision", "Camera binding failed", e)
                                }
                            }, ContextCompat.getMainExecutor(ctx))
                            previewView
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Sci-Fi Hologram Targeting Reticle
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 40.dp, vertical = 120.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(260.dp)
                            .border(
                                width = 1.5.dp,
                                brush = Brush.linearGradient(listOf(CyberTeal.copy(alpha = 0.7f), NeonPink.copy(alpha = 0.7f))),
                                shape = RoundedCornerShape(28.dp)
                            )
                    )
                }
            }

            // Top Control Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Close Button
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                        .testTag("close_camera_btn")
                ) {
                    Icon(imageVector = Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                }

                // Header Title Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.65f),
                    border = BorderStroke(1.dp, CyberTeal.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isAnalyzing) SunnyAmber else NeonGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isAnalyzing) "ZOYA DEKH RAHI HAI ✨" else "ZOYA VISION CAMERA 📷",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Controls on Right: Flash & Flip Lens
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (localCapturedBitmap == null) {
                        // Flashlight Toggle
                        IconButton(
                            onClick = {
                                isTorchOn = !isTorchOn
                                currentCamera?.cameraControl?.enableTorch(isTorchOn)
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isTorchOn) Icons.Rounded.FlashOn else Icons.Rounded.FlashOff,
                                contentDescription = "Flash",
                                tint = if (isTorchOn) SunnyAmber else Color.White
                            )
                        }

                        // Flip Front/Back Lens
                        IconButton(
                            onClick = {
                                lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                                    CameraSelector.LENS_FACING_FRONT
                                } else {
                                    CameraSelector.LENS_FACING_BACK
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                        ) {
                            Icon(imageVector = Icons.Rounded.FlipCameraAndroid, contentDescription = "Flip", tint = Color.White)
                        }
                    } else {
                        // Reset to Take Another Photo
                        IconButton(
                            onClick = {
                                localCapturedBitmap = null
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                .testTag("retake_photo_btn")
                        ) {
                            Icon(imageVector = Icons.Rounded.Refresh, contentDescription = "Retake", tint = Color.White)
                        }
                    }
                }
            }

            // Bottom Area: Prompts, Controls & Result Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp, start = 16.dp, end = 16.dp)
            ) {
                // If Result is Available, Display Response Card
                if (analysisResult != null && !isAnalyzing) {
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1730).copy(alpha = 0.95f)),
                        border = BorderStroke(1.5.dp, Brush.linearGradient(listOf(NeonPink, CyberTeal))),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .testTag("vision_result_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(Brush.linearGradient(listOf(NeonPink, MagentaRose))),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("✨", fontSize = 16.sp)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Zoya ne dekha 💖",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Color.White
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Play / Stop Voice Button
                                    IconButton(
                                        onClick = {
                                            if (isSpeaking) {
                                                onStopSpeaking()
                                            } else {
                                                onSpeakResult(analysisResult)
                                            }
                                        },
                                        modifier = Modifier
                                            .size(34.dp)
                                            .background(if (isSpeaking) NeonPink.copy(alpha = 0.35f) else CyberTeal.copy(alpha = 0.2f), CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = if (isSpeaking) Icons.Rounded.GraphicEq else Icons.Rounded.VolumeUp,
                                            contentDescription = if (isSpeaking) "Stop Voice" else "Listen Full Details",
                                            tint = if (isSpeaking) NeonPink else CyberTeal,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                            val clip = android.content.ClipData.newPlainText("Zoya Vision Analysis", analysisResult)
                                            clipboard.setPrimaryClip(clip)
                                            android.widget.Toast.makeText(context, "📋 Poori details copy ho gayi!", android.widget.Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier
                                            .size(34.dp)
                                            .background(Color.White.copy(alpha = 0.12f), CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.ContentCopy,
                                            contentDescription = "Copy Details",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { isResultExpanded = !isResultExpanded },
                                        modifier = Modifier
                                            .size(34.dp)
                                            .background(Color.White.copy(alpha = 0.12f), CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = if (isResultExpanded) Icons.Rounded.FullscreenExit else Icons.Rounded.Fullscreen,
                                            contentDescription = if (isResultExpanded) "Collapse" else "Expand Full Screen",
                                            tint = CyberTeal,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { localCapturedBitmap = null },
                                        modifier = Modifier
                                            .size(34.dp)
                                            .background(NeonPink.copy(alpha = 0.2f), CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Refresh,
                                            contentDescription = "New Photo",
                                            tint = NeonPink,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Scrollable Full Text Body - Never cut off
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 140.dp, max = if (isResultExpanded) 520.dp else 280.dp)
                                    .verticalScroll(rememberScrollState())
                                    .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                                    .border(1.dp, CyberTeal.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = analysisResult,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontSize = 14.sp,
                                        lineHeight = 22.sp
                                    ),
                                    color = Color.White.copy(alpha = 0.96f)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // If Listening: Glowing live voice transcription banner
                            if (isListening) {
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2B1038)),
                                    border = BorderStroke(1.5.dp, Brush.horizontalGradient(listOf(NeonPink, CyberTeal))),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(Brush.linearGradient(listOf(NeonPink, DeepViolet))),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Rounded.Mic, contentDescription = "Listening", tint = Color.White, modifier = Modifier.size(20.dp))
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Zoya sun rahi hai... Boliye Boss! 🎙️✨",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = CyberTeal
                                            )
                                            Text(
                                                text = if (liveTranscript.isNotBlank()) "\"$liveTranscript\"" else "Photo ke baare me sawal boliye...",
                                                fontSize = 12.sp,
                                                color = Color.White,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        IconButton(
                                            onClick = onStopListening,
                                            modifier = Modifier
                                                .size(32.dp)
                                                .background(Color.White.copy(alpha = 0.15f), CircleShape)
                                        ) {
                                            Icon(Icons.Rounded.Stop, contentDescription = "Stop", tint = NeonPink, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }

                            // Big Voice Action Button: "🎤 Awaz Se Poochiye"
                            Button(
                                onClick = {
                                    if (isListening) {
                                        onStopListening()
                                    } else {
                                        onStartListening(localCapturedBitmap)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        Brush.horizontalGradient(
                                            if (isListening) listOf(NeonPink, Color(0xFF880E4F))
                                            else listOf(CyberTeal, DeepViolet, NeonPink)
                                        ),
                                        RoundedCornerShape(16.dp)
                                    )
                                    .testTag("vision_voice_ask_btn")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = if (isListening) Icons.Rounded.GraphicEq else Icons.Rounded.Mic,
                                        contentDescription = "Voice Ask",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isListening) "Sun rahi hoon... (Tap to stop)" else "🎤 Awaz Se Poochiye (Ask with Voice)",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Quick Follow-up Question Chips
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val quickQueries = listOf(
                                    "🔍 Ye kya hai?" to "Ye cheez kya hai, iska exact brand aur naam kya hai?",
                                    "🛡️ Security & Vulnerabilities" to "Is photo me jo device/system/code/cheez hai usme kaunse security risks ya vulnerabilities hain aur ethical hacking perspective se unhe kaise protect karein?",
                                    "🔴 Red Hat Exploit Analysis" to "Red Hat hacking aur offensive security ke mutabiq iska attack vector aur complete security analysis samjhao.",
                                    "💡 Kaise use karein?" to "Isko use karne ka sabse sahi tareeqa aur benefits batao.",
                                    "🛠️ Problem kaise theek karein?" to "Isme jo issue ya problem dikh rahi hai uska step-by-step solution batao.",
                                    "📄 Text padho" to "Is photo me jo text ya labels hain unko padhkar aasan Hindi me matlab samjhao.",
                                    "💰 Price & Specs" to "Iska market price, specs aur model details kya hain?"
                                )
                                quickQueries.forEach { (label, query) ->
                                    AssistChip(
                                        onClick = {
                                            if (localCapturedBitmap != null) {
                                                onCaptureImage(localCapturedBitmap!!, query)
                                            }
                                        },
                                        label = { Text(label, fontSize = 11.sp, color = Color.White) },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = AssistChipDefaults.assistChipColors(containerColor = Color.Black.copy(alpha = 0.55f)),
                                        border = BorderStroke(1.dp, CyberTeal.copy(alpha = 0.4f))
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Follow-up question manual input
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = followUpInput,
                                    onValueChange = { followUpInput = it },
                                    placeholder = { Text("Ya likhkar poochiye...", fontSize = 11.sp, color = Color.LightGray) },
                                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 12.sp),
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyberTeal,
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                                        focusedContainerColor = Color.Black.copy(alpha = 0.4f),
                                        unfocusedContainerColor = Color.Black.copy(alpha = 0.4f)
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = {
                                        if (followUpInput.isNotBlank() && localCapturedBitmap != null) {
                                            val query = followUpInput
                                            followUpInput = ""
                                            onCaptureImage(localCapturedBitmap!!, query)
                                        }
                                    },
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(Brush.linearGradient(listOf(NeonPink, DeepViolet)))
                                ) {
                                    Icon(imageVector = Icons.Rounded.Send, contentDescription = "Ask", tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                } else if (localCapturedBitmap != null && analysisResult == null && !isAnalyzing) {
                    // Photo Captured - Ready to Ask via Voice Card
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1730).copy(alpha = 0.95f)),
                        border = BorderStroke(1.5.dp, Brush.linearGradient(listOf(NeonPink, CyberTeal))),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "📸 Photo Ready!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                                IconButton(
                                    onClick = { localCapturedBitmap = null },
                                    modifier = Modifier
                                        .size(28.dp)
                                        .background(Color.White.copy(alpha = 0.15f), CircleShape)
                                ) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Cancel", tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isListening) "🎙️ Zoya sun rahi hai... Boliye Boss, is photo me kya janna hai?" else "Ab mic dabakar boliye, aapki aawaz sunkar Zoya jawab degi:",
                                fontSize = 13.sp,
                                color = if (isListening) CyberTeal else Color.White.copy(alpha = 0.85f),
                                textAlign = TextAlign.Center
                            )
                            if (isListening && liveTranscript.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "\"$liveTranscript\"",
                                    fontSize = 13.sp,
                                    color = NeonPink,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center
                                )
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            // Mic Button
                            Button(
                                onClick = {
                                    if (isListening) onStopListening() else onStartListening(localCapturedBitmap)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        Brush.horizontalGradient(
                                            if (isListening) listOf(NeonPink, Color(0xFF880E4F))
                                            else listOf(CyberTeal, DeepViolet, NeonPink)
                                        ),
                                        RoundedCornerShape(24.dp)
                                    )
                                    .testTag("captured_photo_speak_btn")
                            ) {
                                Icon(
                                    imageVector = if (isListening) Icons.Rounded.GraphicEq else Icons.Rounded.Mic,
                                    contentDescription = "Voice",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isListening) "Sun Rahi Hoon... (Tap to stop)" else "🎤 Awaz Se Poochiye (Speak Your Question)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    onCaptureImage(localCapturedBitmap!!, selectedQuestionPrompt)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f))
                            ) {
                                Text("Poori Details & Full Analysis Dekhein 🔍", color = Color.White, fontSize = 12.sp)
                            }
                        }
                    }
                } else if (isAnalyzing) {
                    // Analyzing Status Card
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1730).copy(alpha = 0.9f)),
                        border = BorderStroke(1.dp, CyberTeal.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(32.dp),
                                color = CyberTeal,
                                strokeWidth = 3.dp
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "Zoya photo dekh rahi hai... ✨",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = "Gemini Vision AI se live detail aur voice reply generate ho raha hai!",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                } else {
                    // Quick Question Chips Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val promptOptions = listOf(
                            "Poori Details & Analysis 🔍" to "Is photo ko ghaur se dekho aur iske baare me POORI DETAILS (Full In-Depth Breakdown, Features, Working, Solutions aur Tips) samjhao bina kisi kami ke!",
                            "Ethical Hacking & Security 🛡️" to "Is photo ko cybersecurity, ethical hacking aur red hat security ke perspective se analyze karo aur iske vulnerabilities, working aur defensive best practices vistaar se batao.",
                            "Kaise Use Karein & Tips 💡" to "Isko use karne ka sahi tareeqa, practical tips aur fayde vistaar se samjhao.",
                            "Identify & Specs 🧠" to "Iska exact naam, brand, model, components aur specifications vistaar se batao.",
                            "Problem Solution & Fix 🛠️" to "Isme jo samasya ya problem dikh rahi hai uska exact step-by-step 1, 2, 3 solution aur guide do.",
                            "Text / Document Padho 📄" to "Is photo me jo bhi text ya likha hua hai usko poora padho aur aasan Hindi me matlab samjhao."
                        )

                        promptOptions.forEach { (chipLabel, promptText) ->
                            val isSelected = selectedQuestionPrompt == promptText
                            AssistChip(
                                onClick = { selectedQuestionPrompt = promptText },
                                label = { Text(chipLabel, fontSize = 12.sp, color = if (isSelected) Color.White else Color.White.copy(alpha = 0.85f)) },
                                shape = RoundedCornerShape(16.dp),
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = if (isSelected) NeonPink.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.55f)
                                ),
                                border = BorderStroke(1.dp, if (isSelected) NeonPink else Color.White.copy(alpha = 0.25f))
                            )
                        }
                    }
                }

                // Bottom Camera Control Bar (Only show if not analyzing and photo not yet captured)
                if (!isAnalyzing && analysisResult == null && localCapturedBitmap == null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Gallery Button
                        IconButton(
                            onClick = { galleryPickerLauncher.launch("image/*") },
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.6f))
                                .border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                        ) {
                            Icon(imageVector = Icons.Rounded.Image, contentDescription = "Gallery", tint = Color.White)
                        }

                        // Big Shutter Button: "Zoya Dekho 📸"
                        Box(
                            modifier = Modifier
                                .scale(pulseScale)
                                .size(82.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(NeonPink, DeepViolet, CyberTeal)
                                    )
                                )
                                .clickable {
                                    val capture = imageCaptureUseCase
                                    if (capture != null) {
                                        val tempFile = File(context.cacheDir, "zoya_capture_${System.currentTimeMillis()}.jpg")
                                        val outputOptions = ImageCapture.OutputFileOptions.Builder(tempFile).build()

                                        capture.takePicture(
                                            outputOptions,
                                            cameraExecutor,
                                            object : ImageCapture.OnImageSavedCallback {
                                                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                                    val bitmap = decodeOrientedBitmap(tempFile)
                                                    tempFile.delete()
                                                    if (bitmap != null) {
                                                        ContextCompat.getMainExecutor(context).execute {
                                                            localCapturedBitmap = bitmap
                                                            onCaptureImage(bitmap, selectedQuestionPrompt)
                                                        }
                                                    }
                                                }

                                                override fun onError(exception: ImageCaptureException) {
                                                    android.util.Log.e("ZoyaVision", "Capture failed", exception)
                                                    ContextCompat.getMainExecutor(context).execute {
                                                        android.widget.Toast.makeText(context, "Camera capture retry kijiye: ${exception.localizedMessage ?: "Please try again"}", android.widget.Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            }
                                        )
                                    }
                                }
                                .testTag("shutter_capture_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Rounded.CameraAlt,
                                    contentDescription = "Capture",
                                    tint = Color.White,
                                    modifier = Modifier.size(34.dp)
                                )
                                Text(
                                    text = "DEKHO",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        // Capture & Speak Button (Instant 1-Tap Voice Q&A)
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        if (isListening) listOf(NeonPink, Color(0xFFD81B60))
                                        else listOf(CyberTeal, DeepViolet)
                                    )
                                )
                                .border(1.5.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                                .clickable {
                                    val capture = imageCaptureUseCase
                                    if (capture != null) {
                                        val tempFile = File(context.cacheDir, "zoya_capture_${System.currentTimeMillis()}.jpg")
                                        val outputOptions = ImageCapture.OutputFileOptions.Builder(tempFile).build()
                                        capture.takePicture(
                                            outputOptions,
                                            cameraExecutor,
                                            object : ImageCapture.OnImageSavedCallback {
                                                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                                    val bitmap = decodeOrientedBitmap(tempFile)
                                                    tempFile.delete()
                                                    if (bitmap != null) {
                                                        ContextCompat.getMainExecutor(context).execute {
                                                            localCapturedBitmap = bitmap
                                                            onStartListening(bitmap)
                                                        }
                                                    }
                                                }
                                                override fun onError(exception: ImageCaptureException) {
                                                    android.util.Log.e("ZoyaVision", "Capture failed", exception)
                                                    ContextCompat.getMainExecutor(context).execute {
                                                        android.widget.Toast.makeText(context, "Camera capture retry kijiye: ${exception.localizedMessage ?: "Please try again"}", android.widget.Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            }
                                        )
                                    }
                                }
                                .testTag("shutter_voice_capture_btn"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = if (isListening) Icons.Rounded.GraphicEq else Icons.Rounded.Mic,
                                    contentDescription = "Capture and Speak",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    text = "BOLIYE",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Decode bitmap with ExifInterface rotation check to ensure upright display.
 */
private fun decodeOrientedBitmap(file: File): Bitmap? {
    return try {
        // Measure bounds first to avoid OutOfMemory on high-resolution cameras
        val boundsOptions = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeFile(file.absolutePath, boundsOptions)

        var inSampleSize = 1
        val maxTargetDim = 1920
        while ((boundsOptions.outWidth / (inSampleSize * 2)) >= maxTargetDim ||
            (boundsOptions.outHeight / (inSampleSize * 2)) >= maxTargetDim
        ) {
            inSampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bitmap = BitmapFactory.decodeFile(file.absolutePath, decodeOptions) ?: return null
        val exif = ExifInterface(file.absolutePath)
        val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            else -> return bitmap
        }
        Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    } catch (e: Exception) {
        android.util.Log.e("ZoyaVision", "Error decoding oriented bitmap", e)
        null
    }
}
