package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Zoya Signature Neon & Pastel Palette
val NeonPink = Color(0xFFFF2A85)
val MagentaRose = Color(0xFFFF4081)
val SoftPink = Color(0xFFFF80AB)
val DeepViolet = Color(0xFF8B5CF6)
val ElectricPurple = Color(0xFF7C3AED)
val RadiantCoral = Color(0xFFFF5252)
val SunnyAmber = Color(0xFFFFB300)
val CyberTeal = Color(0xFF00E5FF)
val NeonGreen = Color(0xFF00E676)

// Midnight OLED Black Surfaces
val PureBlack = Color(0xFF000000)
val DarkBackground = Color(0xFF07060B)
val DarkSurface = Color(0xFF0F0D17)
val DarkSurfaceVariant = Color(0xFF191526)
val DarkSurfaceElevated = Color(0xFF221D33)
val DarkBorder = Color(0xFF32284D)
val DarkBorderGlow = Color(0xFFFF2A85)

// Light Surfaces (fallback)
val LightBackground = Color(0xFF07060B)
val LightSurface = Color(0xFF0F0D17)
val LightSurfaceVariant = Color(0xFF191526)
val LightBorder = Color(0xFF32284D)

// Crystal Clear Text Colors for Ultimate Readability
val TextPrimaryDark = Color(0xFFFFFFFF)       // 100% Crisp White
val TextSecondaryDark = Color(0xFFD4CEE2)     // High-contrast soft lavender/silver
val TextTertiaryDark = Color(0xFF9E95B3)      // Subtle label color
val TextPrimaryLight = Color(0xFFFFFFFF)
val TextSecondaryLight = Color(0xFFD4CEE2)


