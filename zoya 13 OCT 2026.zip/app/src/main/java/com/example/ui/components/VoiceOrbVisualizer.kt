package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MagentaRose
import com.example.ui.theme.NeonPink
import com.example.ui.theme.RadiantCoral
import com.example.ui.theme.SunnyAmber
import kotlin.math.cos
import kotlin.math.sin

// High-tech Cyan/Holographic neural constants
val HolographicCyan = Color(0xFF00F5FF)
val LuminousWhite = Color(0xFFE8FFFF)
val DeepSpaceBlack = Color(0xFF030810)

@Composable
fun VoiceOrbVisualizer(
    isListening: Boolean,
    isSpeaking: Boolean,
    isThinking: Boolean,
    amplitude: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_pulse")

    // Gentle 3D spherical rotation
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isSpeaking) 4000 else if (isListening) 5500 else 9000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val counterRotationAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 11000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counter_rotation"
    )

    val breatheScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 750 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathe"
    )

    val neuralPulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 600 else 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "neural_pulse"
    )

    // Dynamic reaction to assistant's voice: pulsing, expanding & contracting
    val dynamicScale = when {
        isSpeaking -> 1.0f + (amplitude * 0.42f) + (breatheScale - 1f)
        isListening -> 1.0f + (amplitude * 0.35f)
        isThinking -> breatheScale * 1.07f
        else -> breatheScale
    }

    // Dynamic color accentuation: primary holographic cyan-white with status nuances
    val coreCyan = when {
        isSpeaking -> HolographicCyan
        isListening -> RadiantCoral
        isThinking -> SunnyAmber
        else -> HolographicCyan
    }

    Box(
        modifier = modifier
            .size(170.dp)
            .testTag("voice_orb_visualizer")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        // 1. Multi-layered 3D Volumetric Neural Network Canvas with Dynamic Node Interconnections
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = (size.minDimension / 2f) * 0.68f

            // Soft cyan-blue volumetric glow aura
            val outerAuraRadius = baseRadius * dynamicScale * 1.35f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreCyan.copy(alpha = if (isSpeaking) 0.38f * neuralPulseAlpha else 0.22f),
                        HoloBlue.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = outerAuraRadius
                ),
                radius = outerAuraRadius,
                center = center
            )

            // Dynamic neural node generation: interconnected with thin luminous lines
            val nodeCount = 18
            val nodes = ArrayList<Offset>(nodeCount)

            for (i in 0 until nodeCount) {
                // Spherical pseudo-3D orbital coordinate calculation
                val angleDeg = (rotationAngle * (if (i % 2 == 0) 1.2f else -0.8f)) + (i * (360f / nodeCount))
                val angleRad = Math.toRadians(angleDeg.toDouble())
                // Latitude inclination factor for 3D sphere look
                val latFactor = sin(Math.toRadians((i * 45.0) + (counterRotationAngle * 0.4)))
                val orbitRadius = baseRadius * dynamicScale * (0.88f + (if (isSpeaking) amplitude * 0.28f else 0.05f))

                val nx = center.x + (orbitRadius * cos(angleRad) * cos(latFactor)).toFloat()
                val ny = center.y + (orbitRadius * sin(angleRad)).toFloat()
                val nodePos = Offset(nx, ny)
                nodes.add(nodePos)
            }

            // Draw interconnected luminous lines between nearby nodes (living neural network effect)
            val connectionAlpha = if (isSpeaking) 0.65f * neuralPulseAlpha else 0.32f
            for (i in 0 until nodes.size) {
                for (j in i + 1 until nodes.size) {
                    val p1 = nodes[i]
                    val p2 = nodes[j]
                    val distance = kotlin.math.hypot(p1.x - p2.x, p1.y - p2.y)
                    val maxDistance = baseRadius * 0.95f

                    if (distance < maxDistance) {
                        val lineAlpha = (1f - (distance / maxDistance)) * connectionAlpha
                        drawLine(
                            color = coreCyan.copy(alpha = lineAlpha.coerceIn(0f, 1f)),
                            start = p1,
                            end = p2,
                            strokeWidth = if (isSpeaking) 1.5f else 1.0f
                        )
                    }
                }
            }

            // Draw glowing cyan-white particle nodes
            for (i in 0 until nodes.size) {
                val nodePos = nodes[i]
                // Node outer glow
                drawCircle(
                    color = coreCyan.copy(alpha = if (isSpeaking) 0.55f else 0.35f),
                    radius = if (isSpeaking) 4.5f else 3.0f,
                    center = nodePos
                )
                // Node intense white core
                drawCircle(
                    color = LuminousWhite.copy(alpha = 0.95f),
                    radius = if (isSpeaking) 2.2f else 1.5f,
                    center = nodePos
                )
            }

            // Subtle floating particles orbiting around sphere edges
            val floatingCount = 10
            for (k in 0 until floatingCount) {
                val fAngle = Math.toRadians((counterRotationAngle * 1.4 + (k * (360f / floatingCount))).toDouble())
                val fDistance = baseRadius * dynamicScale * (1.18f + (k % 3) * 0.08f)
                val fx = center.x + (fDistance * cos(fAngle)).toFloat()
                val fy = center.y + (fDistance * sin(fAngle)).toFloat()

                drawCircle(
                    color = coreCyan.copy(alpha = 0.5f * neuralPulseAlpha),
                    radius = 2.0f,
                    center = Offset(fx, fy)
                )
            }

            // Fine holographic equatorial ring
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        coreCyan.copy(alpha = 0.8f),
                        LuminousWhite.copy(alpha = 0.3f),
                        HoloBlue.copy(alpha = 0.7f),
                        coreCyan.copy(alpha = 0.8f)
                    ),
                    center = center
                ),
                radius = baseRadius * dynamicScale * 1.02f,
                center = center,
                style = Stroke(width = if (isSpeaking) 2.2f else 1.4f)
            )
        }

        // 2. Inner Volumetric Holographic Neural Sphere Container
        Box(
            modifier = Modifier
                .size(118.dp)
                .scale(dynamicScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            DeepSpaceBlack,
                            DeepSpaceBlack.copy(alpha = 0.92f),
                            coreCyan.copy(alpha = 0.35f)
                        )
                    )
                )
                .border(1.5.dp, coreCyan.copy(alpha = 0.7f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            // High-detail Volumetric 3D Holographic Particle Globe Image
            Image(
                painter = painterResource(id = R.drawable.img_holographic_neural_sphere),
                contentDescription = "Holographic AI Assistant Neural Sphere",
                modifier = Modifier
                    .fillMaxSize()
                    .rotate(rotationAngle * 0.25f)
                    .clip(CircleShape),
                contentScale = ContentScale.Crop
            )

            // Inner soft glowing radial vignette overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color.Transparent,
                                coreCyan.copy(alpha = if (isSpeaking) 0.25f else 0.12f),
                                DeepSpaceBlack.copy(alpha = 0.45f)
                            )
                        )
                    )
            )

            // Subtle Status glyph badge on bottom edge
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = (-4).dp, y = (-4).dp)
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            isSpeaking -> HolographicCyan
                            isListening -> RadiantCoral
                            isThinking -> SunnyAmber
                            else -> HoloBlue
                        }
                    )
                    .border(1.2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        isSpeaking -> Icons.Rounded.VolumeUp
                        isListening -> Icons.Rounded.Mic
                        isThinking -> Icons.Rounded.GraphicEq
                        else -> Icons.Rounded.AutoAwesome
                    },
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
fun SmartAssistantWaveBar(
    isListening: Boolean,
    isSpeaking: Boolean,
    amplitude: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_bars")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Row(
        modifier = modifier
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val barCount = 7
        val baseColors = listOf(HolographicCyan, LuminousWhite, HoloBlue, HolographicCyan, LuminousWhite, HoloBlue, HolographicCyan)

        for (i in 0 until barCount) {
            val wave = (sin(phase + (i * 0.85f)) + 1f) / 2f
            val baseHeight = 6.dp
            val dynamicHeight = when {
                isListening -> (8 + (amplitude * 24f * wave)).dp
                isSpeaking -> (7 + (wave * 18f)).dp
                else -> (4 + (wave * 4f)).dp
            }

            Box(
                modifier = Modifier
                    .width(3.5.dp)
                    .height(dynamicHeight.coerceIn(4.dp, 28.dp))
                    .clip(RoundedCornerShape(2.dp))
                    .background(baseColors[i % baseColors.size])
            )
        }
    }
}
