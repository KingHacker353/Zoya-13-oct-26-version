package com.example.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Accessibility
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BubbleChart
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.ElectricBolt
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.KeyboardVoice
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.service.ZoyaAccessibilityService
import com.example.service.ZoyaNotificationHelper
import com.example.ui.components.ChatMessageItem
import com.example.ui.components.ContactsDirectorySheet
import com.example.ui.components.MemoryBankSheet
import com.example.ui.components.PhoneControlHubSheet
import com.example.ui.components.QuickActionChips
import com.example.ui.components.SettingsSheet
import com.example.ui.components.SmartAssistantDisplayHub
import com.example.ui.components.SmartAssistantWaveBar
import com.example.ui.components.VoiceOrbVisualizer
import com.example.ui.components.VoiceSelectorSheet
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MagentaRose
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPink
import com.example.ui.theme.RadiantCoral
import com.example.ui.theme.SunnyAmber

import com.example.ui.components.FuturisticNeuralDashboard
import com.example.ai.neural.NeuralEngine
import androidx.compose.foundation.lazy.LazyRow

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun ZoyaMainScreen(
    viewModel: ZoyaViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val contacts by viewModel.contacts.collectAsStateWithLifecycle()
    val availableVoices by viewModel.availableVoices.collectAsStateWithLifecycle()
    val selectedVoice by viewModel.selectedVoice.collectAsStateWithLifecycle()

    val isListening by viewModel.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
    val isThinking by viewModel.isThinking.collectAsStateWithLifecycle()
    val audioAmplitude by viewModel.audioAmplitude.collectAsStateWithLifecycle()
    val liveTranscript by viewModel.liveTranscript.collectAsStateWithLifecycle()
    val lastActionNotice by viewModel.lastActionNotice.collectAsStateWithLifecycle()
    val voicePitch by viewModel.voicePitch.collectAsStateWithLifecycle()
    val voiceSpeed by viewModel.voiceSpeed.collectAsStateWithLifecycle()
    val personalityLevel by viewModel.personalityLevel.collectAsStateWithLifecycle()

    val isContinuousConversationActive by viewModel.isContinuousConversationActive.collectAsStateWithLifecycle()
    val isProactiveCheckInActive by viewModel.isProactiveCheckInActive.collectAsStateWithLifecycle()
    val bossTitle by viewModel.bossTitle.collectAsStateWithLifecycle()
    val currentEmotion by viewModel.currentEmotion.collectAsStateWithLifecycle()

    val smartAutoReplies by NeuralEngine.smartAutoReplies.collectAsStateWithLifecycle()
    val showIslamicHubFromVm by viewModel.showIslamicHub.collectAsStateWithLifecycle()
    val fallbackToSystemVoiceDialog by viewModel.fallbackToSystemVoiceDialog.collectAsStateWithLifecycle()
    val showVisionCamera by viewModel.showVisionCamera.collectAsStateWithLifecycle()
    val isVisionAnalyzing by viewModel.isVisionAnalyzing.collectAsStateWithLifecycle()
    val visionResultText by viewModel.visionResultText.collectAsStateWithLifecycle()
    val capturedVisionBitmap by viewModel.capturedVisionBitmap.collectAsStateWithLifecycle()

    val showWebAutomation by viewModel.showWebAutomation.collectAsStateWithLifecycle()
    val webAutomationUrl by viewModel.webAutomationUrl.collectAsStateWithLifecycle()
    val webAutomationTitle by viewModel.webAutomationTitle.collectAsStateWithLifecycle()
    val webAutomationPlatform by viewModel.webAutomationPlatform.collectAsStateWithLifecycle()
    val webAutomationQuery by viewModel.webAutomationQuery.collectAsStateWithLifecycle()
    var showSavedProfileDialog by remember { mutableStateOf(false) }

    val isTouchGuardArmed by viewModel.isTouchGuardArmed.collectAsStateWithLifecycle()
    val armCountdown by viewModel.armCountdown.collectAsStateWithLifecycle()
    val intruderIncidents by viewModel.intruderIncidents.collectAsStateWithLifecycle()
    val unreviewedIncidents by viewModel.unreviewedIncidents.collectAsStateWithLifecycle()
    val hasUnreviewedIntruderIncident by viewModel.hasUnreviewedIntruderIncident.collectAsStateWithLifecycle()
    val lastCapturedIncident by viewModel.lastCapturedIncident.collectAsStateWithLifecycle()
    val showIntruderSecuritySheet by viewModel.showIntruderSecuritySheet.collectAsStateWithLifecycle()

    var showNeuralDashboard by remember { mutableStateOf(false) }

    var textInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    var showContactsSheet by remember { mutableStateOf(false) }
    var showVoiceSelectorSheet by remember { mutableStateOf(false) }
    var showMemorySheet by remember { mutableStateOf(false) }
    var showMemoryPasswordDialog by remember { mutableStateOf(false) }
    var isMemoryVaultUnlocked by remember { mutableStateOf(false) }
    var showPhoneHubSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    val contactsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val voiceSelectorSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val memorySheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val phoneHubSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val settingsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val islamicHubSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var isAccessibilityActive by remember { mutableStateOf(ZoyaAccessibilityService.isAccessibilityEnabled(context)) }
    var hasNotificationPermission by remember { mutableStateOf(ZoyaNotificationHelper.hasNotificationPermission(context)) }

    // Launcher for notification permission (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
        if (isGranted) {
            ZoyaNotificationHelper.showVoiceControlNotification(context)
            Toast.makeText(context, "🔔 Zoya Notification Active! Upar se click karke bolo!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Notification permission allow karein taaki Zoya status bar me rahe", Toast.LENGTH_SHORT).show()
        }
    }

    // Safety BackHandler: Ensure app never unexpectedly closes or exits unless user explicitly intends
    var lastBackPressTime by remember { mutableStateOf(0L) }
    BackHandler {
        when {
            showWebAutomation -> {
                viewModel.closeWebAutomation()
            }
            showVisionCamera -> {
                viewModel.closeVisionCamera()
            }
            showContactsSheet -> {
                showContactsSheet = false
            }
            showVoiceSelectorSheet -> {
                showVoiceSelectorSheet = false
            }
            showMemoryPasswordDialog -> {
                showMemoryPasswordDialog = false
            }
            showMemorySheet -> {
                showMemorySheet = false
            }
            showPhoneHubSheet -> {
                showPhoneHubSheet = false
            }
            showSettingsSheet -> {
                showSettingsSheet = false
            }
            showIntruderSecuritySheet -> {
                viewModel.closeIntruderSecuritySheet()
            }
            showNeuralDashboard -> {
                showNeuralDashboard = false
            }
            showIslamicHubFromVm -> {
                viewModel.setShowIslamicHub(false)
            }
            else -> {
                val now = System.currentTimeMillis()
                if (now - lastBackPressTime < 2500L) {
                    (context as? Activity)?.finish()
                } else {
                    lastBackPressTime = now
                    Toast.makeText(context, "App se bahar aane ke liye dobara Back dabayein ya boliye 'Zoya bahar aao' 🌸", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    // Refresh state when coming back from settings
    val accessibilitySettingsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        isAccessibilityActive = ZoyaAccessibilityService.isAccessibilityEnabled(context)
    }

    fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        accessibilitySettingsLauncher.launch(intent)
        Toast.makeText(context, "⚙️ 'Zoya Voice Access' ko Enable karein aur Shortcut on karein", Toast.LENGTH_LONG).show()
    }

    fun toggleNotificationService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!ZoyaNotificationHelper.hasNotificationPermission(context)) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        ZoyaNotificationHelper.showVoiceControlNotification(context)
        Toast.makeText(context, "🔔 Zoya Notification on ho gaya! Upar notification bar se direct command dein!", Toast.LENGTH_SHORT).show()
    }

    // System Google Voice Input Dialog Launcher (Native fallback & direct access)
    val speechInputLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = matches?.firstOrNull()?.trim()
            if (!spokenText.isNullOrBlank()) {
                viewModel.processUserQuery(spokenText, isVoice = true, context = context)
            }
        }
    }

    fun launchSystemVoiceDialog() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("hi-IN", "en-IN", "en-US", "ur-IN", "hi"))
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Zoya se boliye... 🎤")
            }
            speechInputLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Voice dialog open nahi ho paya: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // React to automatic fallback when in-app speech recognizer needs system dialog
    LaunchedEffect(fallbackToSystemVoiceDialog) {
        if (fallbackToSystemVoiceDialog) {
            viewModel.onSystemVoiceDialogHandled()
            launchSystemVoiceDialog()
        }
    }

    // Permission launcher for audio recording
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startListeningSafely(context)
        } else {
            Toast.makeText(context, "Voice input ke liye microphone permission zaroori hai", Toast.LENGTH_SHORT).show()
        }
    }

    // Auto-start hands-free wake word listening as soon as app opens ("button dabane ki zarurat na pade"):
    LaunchedEffect(Unit) {
        val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            kotlinx.coroutines.delay(400)
            viewModel.startListeningSafely(context)
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun handleMicClick(forceSystemDialog: Boolean = false) {
        if (isSpeaking) {
            viewModel.stopSpeaking()
            return
        }
        if (forceSystemDialog) {
            launchSystemVoiceDialog()
            return
        }
        if (isListening) {
            viewModel.stopListening()
        } else {
            val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                viewModel.startListeningSafely(context)
            } else {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    // Auto-scroll on new message
    LaunchedEffect(conversations.size, isThinking) {
        if (conversations.isNotEmpty()) {
            listState.animateScrollToItem(conversations.size - 1)
        }
    }

    val isKeyboardOpen = WindowInsets.isImeVisible

    // Auto-scroll when keyboard opens
    LaunchedEffect(isKeyboardOpen) {
        if (isKeyboardOpen && conversations.isNotEmpty()) {
            listState.animateScrollToItem(conversations.size - 1)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.statusBars,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(NeonPink, DeepViolet)))
                                .border(1.5.dp, Color.White.copy(alpha = 0.8f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = selectedVoice.avatarEmoji,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Zoya",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(NeonPink.copy(alpha = 0.15f))
                                        .clickable { showVoiceSelectorSheet = true }
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = selectedVoice.name.take(12),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NeonPink,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = when {
                                    isListening -> "Sun rahi hoon... (Boliye 'Zoya') 🎙️"
                                    isThinking -> "Dimaag laga rahi hoon... 💭"
                                    isSpeaking -> "Bol rahi hoon... 🔊"
                                    else -> "${currentEmotion.emoji} ${currentEmotion.title}"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = when {
                                    currentEmotion == com.example.ai.ZoyaEmotion.JALAN -> Color(0xFFEA80FC)
                                    currentEmotion == com.example.ai.ZoyaEmotion.GUSSA -> Color(0xFFFF5252)
                                    currentEmotion == com.example.ai.ZoyaEmotion.ROMANTIC_PYAAR -> Color(0xFFFF80AB)
                                    isListening -> RadiantCoral
                                    isThinking -> DeepViolet
                                    isSpeaking -> CyberTeal
                                    else -> MagentaRose
                                },
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                actions = {
                    // 1. Phone Directory Action (Contacts & Calling Hub)
                    IconButton(
                        onClick = { showContactsSheet = true },
                        modifier = Modifier.testTag("open_contacts_btn")
                    ) {
                        BadgedBox(
                            badge = {
                                if (contacts.isNotEmpty()) {
                                    Badge(
                                        containerColor = CyberTeal,
                                        contentColor = Color.White
                                    ) {
                                        Text(text = contacts.size.toString())
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Contacts,
                                contentDescription = "Phone Directory",
                                tint = CyberTeal
                            )
                        }
                    }

                    // 2. Memory Storage Action with Secure Password Lock
                    IconButton(
                        onClick = {
                            if (isMemoryVaultUnlocked) {
                                showMemorySheet = true
                            } else {
                                showMemoryPasswordDialog = true
                            }
                        },
                        modifier = Modifier.testTag("open_memory_bank_btn")
                    ) {
                        BadgedBox(
                            badge = {
                                Badge(
                                    containerColor = if (isMemoryVaultUnlocked) NeonGreen else RadiantCoral,
                                    contentColor = Color.White
                                ) {
                                    Text(
                                        text = if (isMemoryVaultUnlocked) "🔓" else "🔒",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Psychology,
                                contentDescription = "Memory Storage Vault",
                                tint = DeepViolet
                            )
                        }
                    }

                    // 3. Settings Action (Contains all settings & modules moved from Desktop)
                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier.testTag("open_settings_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.shadow(2.dp)
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
        ) {
            // Action Notification Banner (if any action recently triggered)
            AnimatedVisibility(
                visible = lastActionNotice != null,
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut() + slideOutVertically()
            ) {
                lastActionNotice?.let { notice ->
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(12.dp),
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ElectricBolt,
                                    contentDescription = null,
                                    tint = NeonPink,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = notice,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            IconButton(
                                onClick = { viewModel.clearActionNotice() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Dismiss",
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Accessibility Shortcut Quick Alert (Compact, only shown when permission is needed)
            AnimatedVisibility(
                visible = !isKeyboardOpen && !isAccessibilityActive,
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut() + slideOutVertically()
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
                    border = BorderStroke(1.dp, Brush.linearGradient(listOf(NeonPink.copy(alpha = 0.5f), CyberTeal.copy(alpha = 0.3f)))),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AccessibilityNew,
                                contentDescription = null,
                                tint = NeonPink,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Enable Zoya Voice Access",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Screen band ya doosre apps me Zoya use karne ke liye",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.LightGray,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Button(
                            onClick = { openAccessibilitySettings() },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("Enable", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Smart Assistant Display Hub (Collapsed when typing to keep chat & text input 100% visible)
            AnimatedVisibility(
                visible = !isKeyboardOpen,
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut() + slideOutVertically()
            ) {
                SmartAssistantDisplayHub(
                    isListening = isListening,
                    isSpeaking = isSpeaking,
                    isThinking = isThinking,
                    audioAmplitude = audioAmplitude,
                    liveTranscript = liveTranscript,
                    bossTitle = bossTitle,
                    voiceName = selectedVoice.name,
                    isAccessibilityActive = isAccessibilityActive,
                    isContinuousMode = isContinuousConversationActive,
                    currentEmotion = currentEmotion,
                    onOrbClick = { handleMicClick() },
                    onOpenVoiceSelector = { showVoiceSelectorSheet = true },
                    onOpenNeuralHub = { showNeuralDashboard = true },
                    onOpenVisionCamera = { viewModel.openVisionCamera() },
                    onStartMoodCheckIn = {
                        viewModel.initiateProactiveMoodCheckIn(context)
                    },
                    onOpenAiStudioBuilder = {
                        viewModel.processUserQuery("Google AI studio se shopping app bana do", isVoice = false, context = context)
                    }
                )
            }

            // Quick Interactive Suggestions Row (Hidden when typing)
            AnimatedVisibility(
                visible = !isKeyboardOpen,
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut() + slideOutVertically()
            ) {
                QuickActionChips(
                    onChipClick = { prompt ->
                        if (com.example.ai.ZoyaCompanionManager.isMoodChatQuery(prompt)) {
                            viewModel.initiateProactiveMoodCheckIn(context)
                        } else {
                            viewModel.processUserQuery(prompt, isVoice = false, context = context)
                        }
                    }
                )
            }

            // Conversation Chat List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 4.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                if (conversations.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp, horizontal = 20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(NeonPink.copy(alpha = 0.25f), CyberTeal.copy(alpha = 0.25f)))),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(Brush.linearGradient(listOf(NeonPink.copy(alpha = 0.3f), CyberTeal.copy(alpha = 0.3f)))),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("✨", fontSize = 18.sp)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "Zoya Ready Hai $bossTitle!",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                        Text(
                                            text = "Boliye 'Call Papa', 'Flashlight on karo', 'YouTube par naat chalao'...",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFFA59EB5),
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                items(conversations, key = { it.id }) { msg ->
                    ChatMessageItem(
                        message = msg,
                        onSpeakClick = { text -> viewModel.speakText(text) }
                    )
                }

                if (isThinking) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = NeonPink,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Zoya soch rahi hai... 💭✨",
                                style = MaterialTheme.typography.bodySmall,
                                color = MagentaRose,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Smart Auto-Replies Bar
            if (smartAutoReplies.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(smartAutoReplies) { reply ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, MagentaRose.copy(alpha = 0.3f)),
                                modifier = Modifier.clickable {
                                    viewModel.processUserQuery(reply, isVoice = false, context = context)
                                }
                            ) {
                                Text(
                                    text = reply,
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Input & Voice Command Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Text Input Field
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = {
                            Text(
                                text = if (isListening) "Sun rahi hoon... 🎤" else "Zoya se boliye ya likhiye...",
                                fontSize = 14.sp,
                                color = Color(0xFFA59EB5)
                            )
                        },
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f),
                            cursorColor = NeonPink,
                            focusedBorderColor = NeonPink,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                            focusedPlaceholderColor = Color(0xFFA59EB5),
                            unfocusedPlaceholderColor = Color(0xFF7E7595)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("user_text_input")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Zoya Vision Camera Quick Button
                    IconButton(
                        onClick = { viewModel.openVisionCamera() },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(CyberTeal.copy(alpha = 0.2f))
                            .border(1.2.dp, CyberTeal.copy(alpha = 0.5f), CircleShape)
                            .testTag("vision_camera_quick_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CameraAlt,
                            contentDescription = "Zoya Vision Camera",
                            tint = CyberTeal,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    if (textInput.isNotBlank()) {
                        // Send Text Button
                        IconButton(
                            onClick = {
                                val query = textInput
                                textInput = ""
                                viewModel.processUserQuery(query, isVoice = false, context = context)
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(NeonPink, DeepViolet)))
                                .testTag("send_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Send,
                                contentDescription = "Send",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    } else {
                        // Unified Single Smart Assistant Microphone Button
                        val infiniteTransition = rememberInfiniteTransition(label = "unified_mic_pulse")
                        val micPulseScale by infiniteTransition.animateFloat(
                            initialValue = 1f,
                            targetValue = if (isListening) 1.16f else if (isSpeaking) 1.08f else 1f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(if (isListening) 550 else 900, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "mic_pulse"
                        )

                        Box(
                            modifier = Modifier
                                .size(54.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            // Pulsing glow halo when active
                            if (isListening || isSpeaking) {
                                Box(
                                    modifier = Modifier
                                        .size(54.dp)
                                        .scale(micPulseScale)
                                        .clip(CircleShape)
                                        .background(
                                            if (isListening) RadiantCoral.copy(alpha = 0.35f)
                                            else CyberTeal.copy(alpha = 0.35f)
                                        )
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            isListening -> Brush.linearGradient(listOf(RadiantCoral, SunnyAmber))
                                            isSpeaking -> Brush.linearGradient(listOf(CyberTeal, DeepViolet))
                                            else -> Brush.linearGradient(listOf(NeonPink, MagentaRose))
                                        }
                                    )
                                    .border(
                                        width = if (isListening) 2.5.dp else 1.5.dp,
                                        color = Color.White.copy(alpha = 0.9f),
                                        shape = CircleShape
                                    )
                                    .combinedClickable(
                                        onClick = { handleMicClick(forceSystemDialog = false) },
                                        onLongClick = { handleMicClick(forceSystemDialog = true) }
                                    )
                                    .testTag("mic_toggle_btn"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when {
                                        isListening -> Icons.Rounded.GraphicEq
                                        isSpeaking -> Icons.Rounded.Stop
                                        else -> Icons.Rounded.Mic
                                    },
                                    contentDescription = "Voice Input - Tap to speak, Hold for Google Dialog",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Bottom Sheets
    if (showContactsSheet) {
        ContactsDirectorySheet(
            contacts = contacts,
            onAddContact = { name, phone, nickname, relationship, notes, isFav ->
                viewModel.addContact(name, phone, nickname, relationship, notes, isFav)
            },
            onUpdateContact = { contact -> viewModel.updateContact(contact) },
            onDeleteContact = { id -> viewModel.deleteContact(id) },
            onDismiss = { showContactsSheet = false },
            sheetState = contactsSheetState
        )
    }

    if (showVoiceSelectorSheet) {
        VoiceSelectorSheet(
            availableVoices = availableVoices,
            selectedVoice = selectedVoice,
            onSelectVoice = { voice -> viewModel.selectVoice(voice) },
            onPreviewVoice = { voice -> viewModel.previewVoice(voice) },
            onUpdateVoiceTuning = { pitch, speed -> viewModel.updateVoiceSettings(pitch, speed) },
            onDismiss = { showVoiceSelectorSheet = false },
            sheetState = voiceSelectorSheetState
        )
    }

    if (showMemorySheet) {
        MemoryBankSheet(
            memories = memories,
            onAddMemory = { key, value, category, notes ->
                viewModel.addMemory(key, value, category, notes)
            },
            onDeleteMemory = { id -> viewModel.deleteMemory(id) },
            onDismiss = { showMemorySheet = false },
            sheetState = memorySheetState
        )
    }

    if (showPhoneHubSheet) {
        PhoneControlHubSheet(
            onDismiss = { showPhoneHubSheet = false },
            sheetState = phoneHubSheetState,
            onExecuteActionFeedback = { notice ->
                Toast.makeText(context, notice, Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showSettingsSheet) {
        SettingsSheet(
            voicePitch = voicePitch,
            voiceSpeed = voiceSpeed,
            personalityLevel = personalityLevel,
            isContinuousConversation = isContinuousConversationActive,
            isProactiveCheckIn = isProactiveCheckInActive,
            bossTitle = bossTitle,
            onUpdateVoice = { pitch, speed -> viewModel.updateVoiceSettings(pitch, speed) },
            onSetPersonality = { level -> viewModel.setPersonality(level) },
            onToggleContinuousConversation = { viewModel.setContinuousConversation(it) },
            onToggleProactiveCheckIn = { viewModel.setProactiveCheckIn(it) },
            onUpdateBossTitle = { viewModel.setBossTitle(it) },
            onTestVoice = { viewModel.speakText("Haan ji haan $bossTitle! Zoya aapke saath hai! Sab kaam chutki mein ho jayega! 🎉💃") },
            onOpenVoiceSelector = { showVoiceSelectorSheet = true },
            onOpenPhoneHub = { showPhoneHubSheet = true },
            onOpenSavedProfile = { showSavedProfileDialog = true },
            onOpenVisionCamera = { viewModel.openVisionCamera() },
            onOpenAiStudioBuilder = {
                viewModel.processUserQuery("Google AI studio shopping app bana do", isVoice = false, context = context)
            },
            onOpenAccessibilitySettings = { openAccessibilitySettings() },
            onToggleNotificationService = { toggleNotificationService() },
            onOpenIslamicHub = { viewModel.setShowIslamicHub(true) },
            onOpenNeuralHub = { showNeuralDashboard = true },
            isAccessibilityActive = isAccessibilityActive,
            isTouchGuardArmed = isTouchGuardArmed,
            onOpenIntruderSecurity = { viewModel.openIntruderSecuritySheet() },
            onToggleTouchGuard = { arm -> viewModel.toggleTouchGuard(context, arm) },
            onClearHistory = { viewModel.clearHistory() },
            onDismiss = { showSettingsSheet = false },
            sheetState = settingsSheetState
        )
    }

    // Intruder Alert Dialog (Shown to owner when they return: "Or me jab aau tab mujhe dikhao")
    val activeIncident = lastCapturedIncident ?: unreviewedIncidents.firstOrNull()
    if (hasUnreviewedIntruderIncident && activeIncident != null) {
        com.example.ui.components.IntruderIncidentDialog(
            incident = activeIncident,
            totalUnreviewedCount = unreviewedIncidents.size,
            onDismiss = {
                viewModel.markIntruderIncidentsReviewed(context)
            },
            onOpenAllLogs = {
                viewModel.markIntruderIncidentsReviewed(context)
                viewModel.openIntruderSecuritySheet()
            }
        )
    }

    // Intruder Security & Touch Guard Bottom Sheet
    if (showIntruderSecuritySheet) {
        com.example.ui.components.IntruderSecuritySheet(
            isArmed = isTouchGuardArmed,
            armCountdown = armCountdown,
            incidents = intruderIncidents,
            onToggleArm = { arm -> viewModel.toggleTouchGuard(context, arm) },
            onTestTrigger = { viewModel.testTriggerIntruderSecurity(context) },
            onDeleteIncident = { id -> viewModel.deleteIntruderIncident(context, id) },
            onClearAll = { viewModel.clearAllIntruderIncidents(context) },
            onDismiss = { viewModel.closeIntruderSecuritySheet() }
        )
    }

    if (showMemoryPasswordDialog) {
        com.example.ui.components.MemoryStoragePasswordDialog(
            onDismiss = { showMemoryPasswordDialog = false },
            onUnlockSuccess = {
                isMemoryVaultUnlocked = true
                showMemoryPasswordDialog = false
                showMemorySheet = true
                viewModel.speakText("Memory Storage vault unlock ho gaya hai Boss! Aapki memories open kar di hain. 🔐💖")
            }
        )
    }

    if (showNeuralDashboard) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showNeuralDashboard = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = false
            )
        ) {
            FuturisticNeuralDashboard(
                onTriggerVoiceCommand = { command ->
                    showNeuralDashboard = false
                    viewModel.processUserQuery(command, isVoice = false, context = context)
                },
                onDismiss = { showNeuralDashboard = false }
            )
        }
    }

    if (showIslamicHubFromVm) {
        com.example.ui.components.IslamicHubSheet(
            onDismiss = { viewModel.setShowIslamicHub(false) },
            sheetState = islamicHubSheetState,
            onReciteText = { text -> viewModel.speakText(text) },
            onStopSpeaking = { viewModel.stopSpeaking() },
            isSpeaking = isSpeaking,
            onAskZoya = { prompt ->
                viewModel.setShowIslamicHub(false)
                viewModel.processUserQuery(prompt, isVoice = false, context = context)
            }
        )
    }

    // Zoya Vision Camera Full Screen Experience (Direct overlay so it never dismisses unexpectedly)
    if (showVisionCamera) {
        com.example.ui.components.ZoyaVisionCameraSheet(
            isAnalyzing = isVisionAnalyzing,
            analysisResult = visionResultText,
            capturedBitmap = capturedVisionBitmap,
            onCaptureImage = { bitmap, prompt ->
                viewModel.analyzeCapturedImage(bitmap, prompt, context)
            },
            onSpeakResult = { text ->
                viewModel.speakText(text)
            },
            isSpeaking = isSpeaking,
            onStopSpeaking = { viewModel.stopSpeaking() },
            isListening = isListening,
            audioAmplitude = audioAmplitude,
            liveTranscript = liveTranscript,
            onStartListening = { bitmap ->
                viewModel.startListeningForVision(bitmap, context)
            },
            onStopListening = { viewModel.stopListening() },
            onDismiss = { viewModel.closeVisionCamera() },
            modifier = Modifier.fillMaxSize()
        )
    }

    // Saved Profile & Delivery Details Dialog
    if (showSavedProfileDialog) {
        com.example.ui.components.SavedProfileManagerDialog(
            onDismiss = { showSavedProfileDialog = false },
            onProfileSaved = {
                showSavedProfileDialog = false
                viewModel.speakText("Aapka profile aur delivery address update ho gaya hai Boss! 🏠✨")
            }
        )
    }

    // Zoya Web Automation Assistant & Browser Full Screen Experience
    if (showWebAutomation) {
        com.example.ui.components.ZoyaWebAutomationSheet(
            initialUrl = webAutomationUrl,
            title = webAutomationTitle,
            platform = webAutomationPlatform,
            searchQuery = webAutomationQuery,
            isListening = isListening,
            isSpeaking = isSpeaking,
            liveTranscript = liveTranscript,
            onStartListening = {
                viewModel.startListeningForWebAutomation(context)
            },
            onStopListening = { viewModel.stopListening() },
            onSpeakFeedback = { text ->
                viewModel.speakText(text)
            },
            onStopSpeaking = { viewModel.stopSpeaking() },
            onExecuteVoiceQuery = { query ->
                viewModel.processUserQuery(query, isVoice = true, context = context)
            },
            onDismiss = { viewModel.closeWebAutomation() },
            modifier = Modifier.fillMaxSize()
        )
    }
}
