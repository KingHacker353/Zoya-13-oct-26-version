package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ElectricBolt
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockReset
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.VolumeUp
import com.example.data.ZoyaPreferences
import com.example.ui.theme.NeonGreen
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import com.example.BuildConfig
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MagentaRose
import com.example.ui.theme.NeonPink
import com.example.ui.theme.RadiantCoral
import com.example.ui.theme.SunnyAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    voicePitch: Float,
    voiceSpeed: Float,
    personalityLevel: String,
    isContinuousConversation: Boolean = true,
    isProactiveCheckIn: Boolean = true,
    bossTitle: String = "Boss",
    onUpdateVoice: (Float, Float) -> Unit,
    onSetPersonality: (String) -> Unit,
    onToggleContinuousConversation: (Boolean) -> Unit = {},
    onToggleProactiveCheckIn: (Boolean) -> Unit = {},
    onUpdateBossTitle: (String) -> Unit = {},
    onTestVoice: () -> Unit,
    onOpenVoiceSelector: () -> Unit,
    onOpenPhoneHub: () -> Unit = {},
    onOpenSavedProfile: () -> Unit = {},
    onOpenVisionCamera: () -> Unit = {},
    onOpenAiStudioBuilder: () -> Unit = {},
    onOpenAccessibilitySettings: () -> Unit = {},
    onToggleNotificationService: () -> Unit = {},
    onOpenIslamicHub: () -> Unit = {},
    onOpenNeuralHub: () -> Unit = {},
    isAccessibilityActive: Boolean = false,
    isTouchGuardArmed: Boolean = false,
    onOpenIntruderSecurity: () -> Unit = {},
    onToggleTouchGuard: (Boolean) -> Unit = {},
    onClearHistory: () -> Unit,
    onDismiss: () -> Unit,
    sheetState: SheetState,
    modifier: Modifier = Modifier
) {
    var pitch by remember { mutableFloatStateOf(voicePitch) }
    var speed by remember { mutableFloatStateOf(voiceSpeed) }
    var titleInput by remember { mutableStateOf(bossTitle) }
    val personalityOptions = listOf("Max Chulbuli 💖", "Balanced Friendly 🌸", "Chill Mode ☕")

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var apiKeyInput by remember { mutableStateOf(com.example.data.ZoyaPreferences.getGeminiApiKey(context)) }
    var isKeyVisible by remember { mutableStateOf(false) }
    var keyTestStatus by remember { mutableStateOf<String?>(null) }
    var isTestingKey by remember { mutableStateOf(false) }

    var memoryPinInput by remember { mutableStateOf(com.example.data.ZoyaPreferences.getMemoryStoragePin(context)) }
    var isMemoryPinVisible by remember { mutableStateOf(false) }
    var memoryPinNotice by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 28.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(NeonPink, DeepViolet))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Settings,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Zoya Settings & AI Voice 🎛️",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Customize Gemini API, voice tone, speed & personality",
                        style = MaterialTheme.typography.bodySmall,
                        color = MagentaRose
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 🔑 Gemini AI API Key & Voice Configuration Card
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, Brush.horizontalGradient(listOf(CyberTeal, NeonPink)), RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Key,
                                contentDescription = null,
                                tint = CyberTeal,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Gemini AI API Key 🔑",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = CyberTeal
                            )
                        }

                        // Status Badge
                        val hasKey = apiKeyInput.isNotBlank() && apiKeyInput != "MY_GEMINI_API_KEY"
                        Box(
                            modifier = Modifier
                                .background(
                                    if (hasKey) NeonPink.copy(alpha = 0.2f) else SunnyAmber.copy(alpha = 0.2f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (hasKey) "Key Active ✨" else "Enter Key",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (hasKey) NeonPink else SunnyAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Apni Gemini API key yahan dalein. Isse Zoya ke saare high-intelligence features aur ultra-realistic Gemini Voices (Aoede, Kore, Leda, Puck, Zephyr) direct chalte hain.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = {
                            apiKeyInput = it
                            keyTestStatus = null
                        },
                        label = { Text("Gemini API Key (AIzaSy...)") },
                        placeholder = { Text("Paste your Gemini API Key here") },
                        singleLine = true,
                        visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isKeyVisible = !isKeyVisible }) {
                                Icon(
                                    imageVector = if (isKeyVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = "Toggle key visibility",
                                    tint = CyberTeal
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberTeal,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gemini_api_key_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                com.example.data.ZoyaPreferences.setGeminiApiKey(context, apiKeyInput)
                                android.widget.Toast.makeText(context, "Gemini API Key Saved! 🚀", android.widget.Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberTeal),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).testTag("save_api_key_btn")
                        ) {
                            Text("Save Key 💾", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = {
                                if (apiKeyInput.isBlank()) {
                                    keyTestStatus = "Pehle API Key paste kijiye!"
                                    return@OutlinedButton
                                }
                                isTestingKey = true
                                keyTestStatus = "Testing connection..."
                                scope.launch {
                                    val (success, msg) = com.example.data.ZoyaPreferences.testGeminiApiKey(apiKeyInput)
                                    isTestingKey = false
                                    keyTestStatus = if (success) "✓ $msg" else "❌ $msg"
                                    if (success) {
                                        com.example.data.ZoyaPreferences.setGeminiApiKey(context, apiKeyInput)
                                    }
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            enabled = !isTestingKey,
                            modifier = Modifier.weight(1f).testTag("test_api_key_btn")
                        ) {
                            Icon(Icons.Rounded.ElectricBolt, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isTestingKey) "Testing..." else "Test Key ⚡", fontSize = 12.sp)
                        }
                    }

                    if (keyTestStatus != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = keyTestStatus ?: "",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (keyTestStatus?.startsWith("✓") == true) CyberTeal else SunnyAmber
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Multi Voice Selector Direct Banner
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NeonPink.copy(alpha = 0.12f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NeonPink.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Multi-Voice Female Selector 🎙️",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = NeonPink
                        )
                        Text(
                            text = "Switch between Zoya, Pari, Simran, Aanya, Zara...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = {
                            onDismiss()
                            onOpenVoiceSelector()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonPink),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Change Voice", fontSize = 11.sp, color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Voice Customization Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Female Voice Synthesis 🎙️",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = NeonPink
                        )

                        Button(
                            onClick = onTestVoice,
                            colors = ButtonDefaults.buttonColors(containerColor = MagentaRose),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("test_voice_btn")
                        ) {
                            Icon(imageVector = Icons.Rounded.VolumeUp, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test Voice", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Pitch Slider
                    Text(
                        text = "Voice Pitch: ${String.format("%.2f", pitch)}x (Cheerful & Friendly)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = pitch,
                        onValueChange = {
                            pitch = it
                            onUpdateVoice(pitch, speed)
                        },
                        valueRange = 0.8f..1.4f,
                        colors = SliderDefaults.colors(
                            thumbColor = NeonPink,
                            activeTrackColor = NeonPink
                        ),
                        modifier = Modifier.testTag("pitch_slider")
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Speech Rate Slider
                    Text(
                        text = "Voice Speed: ${String.format("%.2f", speed)}x (Natural Flow)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Slider(
                        value = speed,
                        onValueChange = {
                            speed = it
                            onUpdateVoice(pitch, speed)
                        },
                        valueRange = 0.8f..1.3f,
                        colors = SliderDefaults.colors(
                            thumbColor = CyberTeal,
                            activeTrackColor = CyberTeal
                        ),
                        modifier = Modifier.testTag("speed_slider")
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Personality Style Selector
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Personality Vibe ✨",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = SunnyAmber
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        for (opt in personalityOptions) {
                            val isSel = personalityLevel == opt
                            FilterChip(
                                selected = isSel,
                                onClick = { onSetPersonality(opt) },
                                label = { Text(opt, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeonPink.copy(alpha = 0.25f),
                                    selectedLabelColor = NeonPink
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Google Assistant Auto-Conversation & Boss Mood Settings Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Brush.linearGradient(listOf(NeonPink, CyberTeal)), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Google Assistant Mode & Companion 🎙️💖",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = NeonPink
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Hands-free automatic answers & proactive mood conversations",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Continuous Conversation Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Auto-Answer Loop (Google Assistant)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Voice sunte hi automatic jawab degi aur aage baat continue rakhegi",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        androidx.compose.material3.Switch(
                            checked = isContinuousConversation,
                            onCheckedChange = { onToggleContinuousConversation(it) }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Proactive Mood Check-In Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Saamne Se Mood & Daily Check-In",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Zoya saamne se poochegi: 'Boss aaj aapka mood kaisa hai, aaj kya hua?'",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        androidx.compose.material3.Switch(
                            checked = isProactiveCheckIn,
                            onCheckedChange = { onToggleProactiveCheckIn(it) }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Boss Title Selector
                    Text(
                        text = "Aapko kis naam se pukare?",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Boss", "Sarkar", "Bhai", "Sir").forEach { title ->
                            FilterChip(
                                selected = titleInput.equals(title, ignoreCase = true),
                                onClick = {
                                    titleInput = title
                                    onUpdateBossTitle(title)
                                },
                                label = { Text(title, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyberTeal.copy(alpha = 0.25f),
                                    selectedLabelColor = CyberTeal
                                ),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Default Assistant & Full Automation Permissions Card
            val localContext = androidx.compose.ui.platform.LocalContext.current
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Brush.linearGradient(listOf(CyberTeal, SunnyAmber)), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Default Assistant & Full Automation ⚡🛠️",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = CyberTeal
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Home/Power button se Zoya kholne aur Photo, PDF, APK, Video, File automatic banane ki permissions",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Set Default Assistant Button
                    Button(
                        onClick = {
                            try {
                                val intent = android.content.Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS).apply {
                                    flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                localContext.startActivity(intent)
                            } catch (e: Exception) {
                                try {
                                    val fallback = android.content.Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).apply {
                                        flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                                    }
                                    localContext.startActivity(fallback)
                                } catch (e2: Exception) {
                                    android.widget.Toast.makeText(localContext, "Settings open nahi ho payi", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberTeal),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Set Zoya as Default Assistant 👑", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "💡 'Default digital assistant app' me jakar Zoya select karein. Iske baad phone lock/unlock hone par ya Home button dabane se Zoya turant khulegi!",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 🔐 Memory Storage Vault Password & Security Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Brush.horizontalGradient(listOf(DeepViolet, NeonPink)), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Rounded.Lock, contentDescription = null, tint = NeonPink, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Memory Storage Vault Password 🔐",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = NeonPink
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(NeonPink.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "Protected 🔒",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonPink
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Aapke personal notes, saved memories aur secret baatein password protected hain. Sirf aap access kar sakte hain. Default password: '1234'.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = memoryPinInput,
                        onValueChange = {
                            memoryPinInput = it.take(12)
                            memoryPinNotice = null
                        },
                        label = { Text("Vault Password / PIN") },
                        singleLine = true,
                        visualTransformation = if (isMemoryPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isMemoryPinVisible = !isMemoryPinVisible }) {
                                Icon(
                                    imageVector = if (isMemoryPinVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = "Toggle password visibility",
                                    tint = CyberTeal
                                )
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberTeal,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (memoryPinNotice != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = memoryPinNotice ?: "",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (memoryPinNotice?.startsWith("✓") == true) CyberTeal else RadiantCoral
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (memoryPinInput.length >= 4) {
                                ZoyaPreferences.setMemoryStoragePin(context, memoryPinInput)
                                memoryPinNotice = "✓ Naya Memory Storage Password save ho gaya! 🔐"
                            } else {
                                memoryPinNotice = "⚠️ Password kam se kam 4 characters ka hona chahiye!"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepViolet),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Rounded.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Update Vault Password", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }

            // 🛡️ Anti-Theft Touch Guard & Intruder Protection Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Brush.horizontalGradient(listOf(RadiantCoral, CyberTeal)), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Security,
                                contentDescription = null,
                                tint = RadiantCoral,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Anti-Theft Touch Guard 🛡️📸",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = RadiantCoral
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(
                                    if (isTouchGuardArmed) NeonGreen.copy(alpha = 0.2f) else RadiantCoral.copy(alpha = 0.2f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isTouchGuardArmed) "Active 🛡️" else "Off ⭕",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isTouchGuardArmed) NeonGreen else RadiantCoral
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Aapki permission ke bina koi phone ko touch kare toh front camera se photo capture hogi, silent alert bajega aur phone turant lock ho jayega.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onToggleTouchGuard(!isTouchGuardArmed) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isTouchGuardArmed) RadiantCoral else CyberTeal
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (isTouchGuardArmed) "Turn Off Guard" else "Arm Guard (5s)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                onDismiss()
                                onOpenIntruderSecurity()
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1.2f)
                        ) {
                            Text("Photos & Logs 📸", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 📲 Assistant Hubs & System Modules (Consolidated from Desktop Top Bar)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Brush.linearGradient(listOf(CyberTeal, SunnyAmber)), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Assistant Hubs & System Features 📲🛠️",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = CyberTeal
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Saare advanced controls aur modules ek jagah:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Phone Control Hub Button
                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onOpenPhoneHub()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Rounded.Smartphone, contentDescription = null, tint = SunnyAmber, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Phone Control Hub 📱 (Flashlight, Volume, Apps)", color = MaterialTheme.colorScheme.onSurface)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Accessibility Service Shortcut Button
                    OutlinedButton(
                        onClick = {
                            onOpenAccessibilitySettings()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AccessibilityNew,
                            contentDescription = null,
                            tint = if (isAccessibilityActive) CyberTeal else RadiantCoral,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isAccessibilityActive) "Accessibility Voice: Active ✅" else "Accessibility Voice: Inactive (Tap to Enable)",
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Background Notification Service Button
                    OutlinedButton(
                        onClick = {
                            onToggleNotificationService()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Rounded.NotificationsActive, contentDescription = null, tint = NeonPink, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Trigger Notification Floating Overlay 🔔", color = MaterialTheme.colorScheme.onSurface)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Islamic Hub Button
                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onOpenIslamicHub()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("🕌", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Islamic Quran & Naat Hub 📖", color = MaterialTheme.colorScheme.onSurface)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Neural HUD Button
                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onOpenNeuralHub()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Rounded.ElectricBolt, contentDescription = null, tint = CyberTeal, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Futuristic Neural Engine HUD ⚡", color = MaterialTheme.colorScheme.onSurface)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Saved Profile & Delivery Details
                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onOpenSavedProfile()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Rounded.AccountCircle, contentDescription = null, tint = NeonPink, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Saved Profile & Delivery Address 🏠", color = MaterialTheme.colorScheme.onSurface)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // AI Studio App Builder & In-App Browser
                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onOpenAiStudioBuilder()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Rounded.AutoAwesome, contentDescription = null, tint = CyberTeal, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Google AI Studio App Builder (Desktop Mode) 🚀", color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Identity & Creator Information Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DeepViolet.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Zoya Identity & Origins 👑",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = DeepViolet
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Rounded.Person, contentDescription = null, tint = NeonPink, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Creator: Muhammad Zubair Irshadi",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Rounded.LocationOn, contentDescription = null, tint = RadiantCoral, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Home Location: Mahudha",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Rounded.AutoAwesome, contentDescription = null, tint = CyberTeal, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AI Model: Gemini 3.5 Flash Reasoning Engine",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Clear conversation history button
            OutlinedButton(
                onClick = onClearHistory,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("clear_history_btn")
            ) {
                Icon(imageVector = Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Clear Conversation History")
            }
        }
    }
}
