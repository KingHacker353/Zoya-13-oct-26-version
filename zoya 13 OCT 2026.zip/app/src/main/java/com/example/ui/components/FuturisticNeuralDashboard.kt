package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ai.neural.*
import com.example.device.*
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.NeonPink

val HoloBlue = Color(0xFF00F0FF)
val HoloPurple = Color(0xFF9D00FF)
val NeonGreen = Color(0xFF00FF88)
val DarkHudBg = Color(0xFF0A0D14)
val CardHudBg = Color(0xFF101524)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FuturisticNeuralDashboard(
    onTriggerVoiceCommand: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    LaunchedEffect(Unit) {
        NeuralEngine.startSystemMonitoring(context)
        SmartLockController.inspectLockState(context)
    }

    val telemetry by NeuralEngine.telemetry.collectAsStateWithLifecycle()
    val metrics by NeuralEngine.neuralMetrics.collectAsStateWithLifecycle()
    val plugins by NeuralEngine.plugins.collectAsStateWithLifecycle()
    val autoReplies by NeuralEngine.smartAutoReplies.collectAsStateWithLifecycle()
    val visionState by VisionPerceptionEngine.state.collectAsStateWithLifecycle()
    val lockState by SmartLockController.state.collectAsStateWithLifecycle()

    var selectedSection by remember { mutableStateOf(0) } // 0: Overview, 1: Vision HUD, 2: Auto-Chat, 3: Plugins

    // Infinite pulsing animation for HUD glow
    val infiniteTransition = rememberInfiniteTransition(label = "hud_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkHudBg)
    ) {
        // Top HUD Status Bar
        Surface(
            color = CardHudBg,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(NeonGreen.copy(alpha = pulseAlpha))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ZOYA NEURAL CORE v4.8",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = HoloBlue
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("close_neural_dashboard_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close Dashboard",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Navigation Tabs: Overview, Vision HUD, WhatsApp Auto-Relay, Plugins
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("⚡ Overview", "👁️ Vision HUD", "💬 Auto-Chat", "🧩 Plugins").forEachIndexed { index, label ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedSection == index) HoloBlue.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f),
                            border = BorderStroke(
                                1.dp,
                                if (selectedSection == index) HoloBlue else Color.DarkGray
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedSection = index }
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (selectedSection == index) HoloBlue else Color.LightGray,
                                modifier = Modifier.padding(vertical = 8.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // Main Dynamic Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (selectedSection) {
                0 -> {
                    // OVERVIEW: System Telemetry & Neural Metrics & Smart Screen Wake
                    item {
                        NeuralCoreMetricCard(metrics, pulseAlpha)
                    }

                    item {
                        SystemTelemetryHudCard(telemetry)
                    }

                    item {
                        SmartLockSentinelCard(
                            lockState = lockState,
                            onWakeScreen = {
                                SmartLockController.wakeUpScreen(context)
                                onTriggerVoiceCommand("Screen wake up kar diya!")
                            }
                        )
                    }

                    item {
                        SmartAutoRepliesCard(
                            replies = autoReplies,
                            onReplyClick = { reply ->
                                onTriggerVoiceCommand(reply)
                            }
                        )
                    }
                }

                1 -> {
                    // VISION SYSTEM HUD
                    item {
                        VisionScannerHudCard(
                            state = visionState,
                            onScanToggle = {
                                if (visionState.isScanning) {
                                    VisionPerceptionEngine.stopLivePerception()
                                } else {
                                    VisionPerceptionEngine.startLivePerception()
                                }
                            },
                            onAnalyze = {
                                val reply = VisionPerceptionEngine.analyzeStaticScene("Analyze room")
                                onTriggerVoiceCommand(reply)
                            }
                        )
                    }
                }

                2 -> {
                    // AUTONOMOUS WHATSAPP CHAT & AUTO-REPLY ENGINE
                    item {
                        AutonomousChatHubCard(
                            metrics = metrics,
                            onAutonomyChange = { mode ->
                                NeuralEngine.setAutonomyMode(mode)
                            },
                            onSendTestBroadcast = {
                                onTriggerVoiceCommand("Zoya, WhatsApp par Sarkar ko bolo main 10 min me aa raha hu")
                            }
                        )
                    }
                }

                3 -> {
                    // EXTENSIBLE PLUGIN ECOSYSTEM
                    item {
                        Text(
                            text = "AI PLUGIN ECOSYSTEM",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = HoloBlue,
                            fontSize = 14.sp
                        )
                    }
                    items(plugins) { plugin ->
                        PluginItemCard(
                            plugin = plugin,
                            onToggle = { enable ->
                                NeuralEngine.togglePlugin(plugin.id, enable)
                            }
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
fun NeuralCoreMetricCard(metrics: NeuralCoreMetrics, pulse: Float) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardHudBg),
        border = BorderStroke(1.dp, Brush.linearGradient(listOf(HoloBlue.copy(alpha = 0.5f), HoloPurple.copy(alpha = 0.5f))) )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Psychology, contentDescription = null, tint = HoloBlue, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "NEURAL COGNITIVE MATRIX",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = HoloBlue.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "${metrics.tokenProcessingSpeedTps.toInt()} TPS",
                        color = HoloBlue,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Cognitive Load & Active Intent
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(text = "Cognitive Load", color = Color.Gray, fontSize = 11.sp)
                    Text(
                        text = "${metrics.cognitiveLoadPercent}%",
                        color = if (metrics.cognitiveLoadPercent > 60) NeonPink else NeonGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
                Column {
                    Text(text = "Active Intent", color = Color.Gray, fontSize = 11.sp)
                    Text(
                        text = metrics.activeIntent.replace("INTENT_", ""),
                        color = HoloBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column {
                    Text(text = "Memory Nodes", color = Color.Gray, fontSize = 11.sp)
                    Text(
                        text = "${metrics.contextMemoryNodesCount}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Attention focus weight bars
            Text(text = "Attention Tensors", color = Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(6.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                metrics.attentionWeights.forEach { (tensor, weight) ->
                    Column(modifier = Modifier.weight(1f)) {
                        LinearProgressIndicator(
                            progress = { weight },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(CircleShape),
                            color = HoloBlue,
                            trackColor = Color.DarkGray
                        )
                        Text(text = tensor, fontSize = 8.sp, color = Color.LightGray, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun SystemTelemetryHudCard(telemetry: SystemTelemetry) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardHudBg),
        border = BorderStroke(1.dp, Color.DarkGray)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Memory, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "REAL-TIME HARDWARE MONITOR",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
                Text(
                    text = "UPTIME: ${telemetry.uptimeFormatted}",
                    fontFamily = FontFamily.Monospace,
                    color = Color.Gray,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4 Grid Gauges: CPU, RAM, Battery, Latency
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TelemetryGaugeItem("CPU LOAD", "${telemetry.cpuLoadPercentage}%", HoloBlue, telemetry.cpuLoadPercentage / 100f, Modifier.weight(1f))
                TelemetryGaugeItem("RAM HEAP", "${telemetry.ramPercentage}%", NeonPink, telemetry.ramPercentage / 100f, Modifier.weight(1f))
                TelemetryGaugeItem("BATTERY", "${telemetry.batteryLevel}%", NeonGreen, telemetry.batteryLevel / 100f, Modifier.weight(1f))
                TelemetryGaugeItem("PING", "${telemetry.networkLatencyMs}ms", HoloPurple, (100 - telemetry.networkLatencyMs) / 100f, Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun TelemetryGaugeItem(title: String, value: String, accentColor: Color, progress: Float, modifier: Modifier) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color.Black.copy(alpha = 0.4f),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.3f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, fontSize = 9.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = accentColor)
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(CircleShape),
                color = accentColor,
                trackColor = Color.DarkGray
            )
        }
    }
}

@Composable
fun SmartLockSentinelCard(
    lockState: LockSecurityState,
    onWakeScreen: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardHudBg),
        border = BorderStroke(1.dp, Brush.linearGradient(listOf(NeonGreen.copy(alpha = 0.4f), HoloBlue.copy(alpha = 0.4f))))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Lock, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SMART LOCK & SCREEN SENTINEL",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = NeonGreen.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "PROTECTED",
                        color = NeonGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Security Architecture: ${lockState.securityLevelText}. Screen wake and keyguard dismiss trigger enabled.",
                fontSize = 11.sp,
                color = Color.LightGray
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onWakeScreen,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen.copy(alpha = 0.2f)),
                border = BorderStroke(1.dp, NeonGreen),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.LightMode, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Instant Screen Wake Trigger ⚡", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun SmartAutoRepliesCard(
    replies: List<String>,
    onReplyClick: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardHudBg),
        border = BorderStroke(1.dp, Color.DarkGray)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = NeonPink, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "CONTEXTUAL SMART AUTO-REPLIES",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(replies) { reply ->
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, NeonPink.copy(alpha = 0.5f)),
                        modifier = Modifier.clickable { onReplyClick(reply) }
                    ) {
                        Text(
                            text = reply,
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VisionScannerHudCard(
    state: VisionPerceptionState,
    onScanToggle: () -> Unit,
    onAnalyze: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardHudBg),
        border = BorderStroke(1.dp, HoloBlue)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Visibility, contentDescription = null, tint = HoloBlue, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NEURAL VISION SYSTEM HUD",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (state.isScanning) NeonPink.copy(alpha = 0.2f) else Color.DarkGray
                ) {
                    Text(
                        text = if (state.isScanning) "SCANNING 🔴" else "STANDBY ⚪",
                        color = if (state.isScanning) NeonPink else Color.LightGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Sci-fi Viewfinder Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
                    .border(1.dp, HoloBlue.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    .drawBehind {
                        // Futuristic grid & target reticle
                        val step = 30.dp.toPx()
                        for (x in 0..(size.width / step).toInt()) {
                            drawLine(
                                color = HoloBlue.copy(alpha = 0.1f),
                                start = Offset(x * step, 0f),
                                end = Offset(x * step, size.height)
                            )
                        }
                        for (y in 0..(size.height / step).toInt()) {
                            drawLine(
                                color = HoloBlue.copy(alpha = 0.1f),
                                start = Offset(0f, y * step),
                                end = Offset(size.width, y * step)
                            )
                        }
                    }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "FRAME_PERCEPTION_01", color = HoloBlue, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        Text(text = "94.8% ACC", color = NeonGreen, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    }

                    // Detected object tags
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        state.detectedObjects.forEach { obj ->
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = HoloBlue.copy(alpha = 0.2f),
                                border = BorderStroke(1.dp, HoloBlue)
                            ) {
                                Text(
                                    text = "TARGET: ${obj.label} [${(obj.confidence * 100).toInt()}%]",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = state.extractedText.ifBlank { "OPTICAL SENSORS ACTIVE • READY" },
                        color = Color.LightGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(text = state.sceneDescription, fontSize = 12.sp, color = Color.White)

            Spacer(modifier = Modifier.height(14.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onScanToggle,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.isScanning) NeonPink else HoloBlue
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (state.isScanning) Icons.Rounded.Stop else Icons.Rounded.CenterFocusStrong,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (state.isScanning) "Stop Scanner" else "Live Scan 👁️",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Button(
                    onClick = onAnalyze,
                    colors = ButtonDefaults.buttonColors(containerColor = DeepViolet),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Scene Analyze 🧠", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun AutonomousChatHubCard(
    metrics: NeuralCoreMetrics,
    onAutonomyChange: (AutonomyMode) -> Unit,
    onSendTestBroadcast: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardHudBg),
        border = BorderStroke(1.dp, NeonGreen)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Forum, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AUTONOMOUS WHATSAPP & CHAT",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = NeonGreen.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = metrics.autonomyLevel.label,
                        color = NeonGreen,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Zoya understands conversations deeply in Hindi & Hinglish, generates contextual auto-replies, and dispatches WhatsApp messages autonomously.",
                fontSize = 11.sp,
                color = Color.LightGray
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(text = "Autonomy Mode Controller:", color = Color.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(6.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AutonomyMode.values().forEach { mode ->
                    val isSelected = metrics.autonomyLevel == mode
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) NeonGreen.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.05f),
                        border = BorderStroke(1.dp, if (isSelected) NeonGreen else Color.DarkGray),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onAutonomyChange(mode) }
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = mode.label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) NeonGreen else Color.LightGray
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onSendTestBroadcast,
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.Send, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Test Autonomous WhatsApp Relay 💬", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun PluginItemCard(
    plugin: AiPlugin,
    onToggle: (Boolean) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardHudBg),
        border = BorderStroke(1.dp, if (plugin.isEnabled) HoloBlue.copy(alpha = 0.4f) else Color.DarkGray)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(if (plugin.isEnabled) HoloBlue.copy(alpha = 0.2f) else Color.DarkGray),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = plugin.icon, fontSize = 18.sp)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = plugin.name,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color.White.copy(alpha = 0.08f)
                        ) {
                            Text(
                                text = plugin.category,
                                fontSize = 8.sp,
                                color = HoloBlue,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Text(
                        text = plugin.description,
                        fontSize = 11.sp,
                        color = Color.Gray,
                        maxLines = 2
                    )
                    Text(
                        text = plugin.statusText,
                        fontSize = 9.sp,
                        color = if (plugin.isEnabled) NeonGreen else Color.DarkGray,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Switch(
                checked = plugin.isEnabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black,
                    checkedTrackColor = HoloBlue,
                    uncheckedThumbColor = Color.Gray,
                    uncheckedTrackColor = Color.DarkGray
                )
            )
        }
    }
}
