package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreditCard
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.ElectricBolt
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Train
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.ZoyaPreferences
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MagentaRose
import com.example.ui.theme.NeonPink
import com.example.ui.theme.RadiantCoral
import com.example.ui.theme.SunnyAmber
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Full-Featured In-App AI Web Automation Assistant & Browser
 * Executes user voice commands directly on websites:
 * - Amazon, Flipkart, Meesho, Zomato, Swiggy, Blinkit, Zepto, ConfirmTkt, IRCTC
 * - Automatically searches, clicks "Add to Cart", "Buy Now", fills saved delivery address,
 *   fills passenger details, scrolls, and place orders!
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ZoyaWebAutomationSheet(
    initialUrl: String,
    title: String,
    platform: String,
    searchQuery: String = "",
    isListening: Boolean,
    isSpeaking: Boolean,
    liveTranscript: String,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    onSpeakFeedback: (String) -> Unit,
    onStopSpeaking: () -> Unit,
    onExecuteVoiceQuery: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var currentUrl by remember { mutableStateOf(initialUrl) }
    var currentTitle by remember { mutableStateOf(title) }
    var pageProgress by remember { mutableIntStateOf(0) }
    var isPageLoading by remember { mutableStateOf(true) }
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var typedCommand by remember { mutableStateOf("") }
    var showProfileDialog by remember { mutableStateOf(false) }
    var liveActionNotice by remember { mutableStateOf<String?>("Zoya live website par active hai! ⚡") }

    val isAiStudioInitial = platform.contains("Google AI Studio", ignoreCase = true) ||
            initialUrl.contains("aistudio.google.com")
    var isDesktopMode by remember { mutableStateOf(isAiStudioInitial) }
    val isAiStudioMode = platform.contains("Google AI Studio", ignoreCase = true) ||
            currentUrl.contains("aistudio.google.com")

    var aiStudioBuildStatus by remember { mutableStateOf("IDLE") } // "IDLE", "STARTING", "BUILDING", "ERROR", "COMPLETED"
    var aiStudioErrorMessage by remember { mutableStateOf<String?>(null) }
    var hasAnnouncedBuildStart by remember { mutableStateOf(false) }
    var hasAnnouncedError by remember { mutableStateOf(false) }
    var hasAnnouncedCompletion by remember { mutableStateOf(false) }

    val userProfile = remember { ZoyaPreferences.getUserOrderProfile(context) }

    // Pulsing mic animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isListening) 1.25f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    // Back button handling: Back in webview if possible, else dismiss
    BackHandler {
        if (webViewInstance?.canGoBack() == true) {
            webViewInstance?.goBack()
        } else {
            onDismiss()
        }
    }

    // Helper to evaluate JavaScript safely
    fun runJs(jsCode: String, callback: ((String?) -> Unit)? = null) {
        webViewInstance?.post {
            webViewInstance?.evaluateJavascript(jsCode) { result ->
                callback?.invoke(result)
            }
        }
    }

    // Helper to copy prompt to Android system clipboard
    fun copyPromptToClipboard(text: String = searchQuery) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
            val clip = android.content.ClipData.newPlainText("AI Studio Prompt", text)
            clipboard?.setPrimaryClip(clip)
            Toast.makeText(context, "AI Studio Prompt clipboard me copy ho gaya! 📋✨", Toast.LENGTH_SHORT).show()
            liveActionNotice = "Prompt copied to clipboard! 📋"
        } catch (e: Exception) {
            Toast.makeText(context, "Copy failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // Autonomous Google AI Studio prompt injection and auto-run
    fun executeAiStudioPromptInjection(promptToInject: String = searchQuery) {
        val targetPrompt = if (promptToInject.isNotBlank()) promptToInject else searchQuery
        liveActionNotice = "Google AI Studio Desktop: Prompt inject & build... 🚀"
        aiStudioBuildStatus = "STARTING"
        hasAnnouncedBuildStart = false
        hasAnnouncedError = false
        hasAnnouncedCompletion = false
        aiStudioErrorMessage = null

        val js = com.example.ai.AiStudioAutomationHelper.getAiStudioAutomationJs(targetPrompt)
        runJs(js) { res ->
            if (res != null && res.contains("SUCCESS")) {
                aiStudioBuildStatus = "BUILDING"
                hasAnnouncedBuildStart = true
                val msg = "Boss! Google AI Studio Desktop Mode me aapka prompt automatically inject karke Build shuru kar diya hai! Application banana start ho gaya hai, screen par dekhiye! 💻🚀✨"
                liveActionNotice = "⚡ App Banana Shuru Ho Gaya! (Building in Desktop Mode...)"
                onSpeakFeedback(msg)
            } else if (res != null && res.contains("STATUS_LOGIN_REQUIRED")) {
                val msg = "Boss, Google AI Studio sign-in page par hai. 1 tap sign-in ke baad Zoya New App me turant prompt daal kar app bana degi!"
                liveActionNotice = "Google Sign In required for AI Studio"
                onSpeakFeedback(msg)
            } else if (res != null && res.contains("REDIRECTED_FROM_PLAYGROUND")) {
                liveActionNotice = "Playground se New App Build Mode me jaa rahe hain... 🚀"
            } else {
                liveActionNotice = "AI Studio Desktop Mode me active hai! ⚡"
            }
        }
    }

    // Continuous Live Status Monitor for Google AI Studio Build Lifecycle
    LaunchedEffect(isAiStudioMode, currentUrl) {
        if (!isAiStudioMode) return@LaunchedEffect
        while (true) {
            delay(2200)
            if (webViewInstance != null && isAiStudioMode) {
                val statusJs = com.example.ai.AiStudioAutomationHelper.getAiStudioStatusCheckJs()
                webViewInstance?.evaluateJavascript(statusJs) { rawResult ->
                    try {
                        if (!rawResult.isNullOrBlank() && rawResult != "null") {
                            val cleanJson = if (rawResult.startsWith("\"") && rawResult.endsWith("\"")) {
                                org.json.JSONTokener(rawResult).nextValue().toString()
                            } else {
                                rawResult
                            }
                            val jsonObj = JSONObject(cleanJson)
                            val status = jsonObj.optString("status", "")
                            val message = jsonObj.optString("message", "")

                            when (status) {
                                "BUILDING" -> {
                                    aiStudioBuildStatus = "BUILDING"
                                    if (!hasAnnouncedBuildStart) {
                                        hasAnnouncedBuildStart = true
                                        val startMsg = "Boss! Google AI Studio me application banana shuru ho gaya hai! Code generation aur build process chal raha hai, screen par dekhiye!"
                                        liveActionNotice = "⚡ App banana start ho gaya hai! (Code generating...)"
                                        onSpeakFeedback(startMsg)
                                    }
                                }
                                "ERROR" -> {
                                    aiStudioBuildStatus = "ERROR"
                                    aiStudioErrorMessage = if (message.isNotBlank()) message else "Build error in AI Studio"
                                    if (!hasAnnouncedError) {
                                        hasAnnouncedError = true
                                        val errAnnounce = "Boss, AI Studio me ek error aayi hai: ${aiStudioErrorMessage}. Please screen par check kijiye!"
                                        liveActionNotice = "⚠️ Error: ${aiStudioErrorMessage}"
                                        onSpeakFeedback(errAnnounce)
                                    }
                                }
                                "COMPLETED" -> {
                                    aiStudioBuildStatus = "COMPLETED"
                                    if (!hasAnnouncedCompletion) {
                                        hasAnnouncedCompletion = true
                                        val completeMsg = "Boss! Mubarak ho! Google AI Studio me aapka application ban kar bilkul taiyar ho gaya hai! Screen par live preview dekhiye! 🎉✨"
                                        liveActionNotice = "🎉 Application Ban Kar Ready Ho Gaya! 🚀"
                                        onSpeakFeedback(completeMsg)
                                    }
                                }
                            }
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    // Comprehensive in-page action executor
    fun executeInPageAction(command: String) {
        val lower = command.lowercase().trim()
        liveActionNotice = "Command: $command"

        when {
            // DESKTOP / MOBILE MODE SWITCH
            lower.contains("desktop mode") || lower.contains("desktop view") || lower.contains("computer mode") -> {
                isDesktopMode = true
                webViewInstance?.let { wv ->
                    wv.settings.userAgentString = com.example.ai.AiStudioAutomationHelper.DESKTOP_USER_AGENT
                    wv.settings.useWideViewPort = true
                    wv.settings.loadWithOverviewMode = true
                    wv.reload()
                }
                liveActionNotice = "Desktop Mode Chalu Ho Gaya 🖥️"
                onSpeakFeedback("Boss, Desktop mode chalu kar diya hai taaki poora workspace, code aur build preview screen par dikhe!")
            }

            lower.contains("mobile mode") || lower.contains("phone mode") -> {
                isDesktopMode = false
                webViewInstance?.let { wv ->
                    wv.settings.userAgentString = com.example.ai.AiStudioAutomationHelper.MOBILE_USER_AGENT
                    wv.settings.useWideViewPort = false
                    wv.settings.loadWithOverviewMode = false
                    wv.reload()
                }
                liveActionNotice = "Mobile Mode Chalu Ho Gaya 📱"
                onSpeakFeedback("Boss, Mobile mode switch kar diya hai!")
            }

            // BUILD STATUS CHECK VOICE COMMAND
            lower.contains("status batao") || lower.contains("app ban gaya") || lower.contains("build status") ||
            lower.contains("kya chal raha") || lower.contains("app bana kya") -> {
                when (aiStudioBuildStatus) {
                    "BUILDING" -> onSpeakFeedback("Boss, application abhi banna shuru ho chuka hai aur code generate ho raha hai!")
                    "COMPLETED" -> onSpeakFeedback("Boss, mubarak ho! Application ban kar bilkul ready ho gaya hai, screen par live preview chal raha hai!")
                    "ERROR" -> onSpeakFeedback("Boss, AI Studio me ek issue aaya hai: ${aiStudioErrorMessage ?: "error"}")
                    else -> onSpeakFeedback("Boss, AI Studio page loaded hai, prompt injection active hai!")
                }
            }

            // 0. GOOGLE AI STUDIO NEW APP & BUILD AUTOMATION
            lower.contains("new app") || lower.contains("open new app") || lower.contains("create app") || lower.contains("build mode") -> {
                liveActionNotice = "New App Build Mode khol rahi hoon... 🚀"
                val js = com.example.ai.AiStudioAutomationHelper.getNavigateToNewAppJs()
                runJs(js) {
                    executeAiStudioPromptInjection(searchQuery)
                }
            }

            lower.contains("ai studio") || lower.contains("run prompt") || lower.contains("prompt run") ||
            lower.contains("inject") || lower.contains("application bana") || lower.contains("website bana") ||
            lower.contains("build app") || (lower.contains("generate") && (lower.contains("prompt") || lower.contains("app") || lower.contains("code"))) ||
            lower == "run" || lower == "build" -> {
                executeAiStudioPromptInjection(searchQuery)
            }

            // COPY PROMPT COMMAND
            lower.contains("copy prompt") || lower.contains("prompt copy") -> {
                copyPromptToClipboard()
                onSpeakFeedback("Prompt clipboard me copy kar diya hai Boss! 📋✨")
            }

            // 1. ADD TO CART / CART ME DALO
            lower.contains("cart") || lower.contains("bag") || lower.contains("basket") || lower.contains("add to") -> {
                val js = """
                    (function() {
                        const keywords = ['add to cart', 'add to bag', 'add to basket', 'add item', 'add', 'kart', 'daalein', 'cart me'];
                        const elements = Array.from(document.querySelectorAll('button, a, div[role="button"], span[role="button"], input[type="button"], input[type="submit"]'));
                        for (const el of elements) {
                            const text = (el.innerText || el.textContent || el.value || el.getAttribute('aria-label') || '').toLowerCase().trim();
                            if (keywords.some(k => text.includes(k))) {
                                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                el.click();
                                return 'SUCCESS_CLICKED: ' + text;
                            }
                        }
                        // Fallback: search for buttons with cart in id or class
                        const cartEl = document.querySelector('[id*="cart" i], [class*="add-to-cart" i], [class*="add_to_cart" i], [aria-label*="cart" i]');
                        if (cartEl) {
                            cartEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                            cartEl.click();
                            return 'SUCCESS_CLICKED_FALLBACK';
                        }
                        return 'NOT_FOUND';
                    })();
                """.trimIndent()
                runJs(js) { res ->
                    if (res != null && res.contains("SUCCESS")) {
                        val msg = "Item cart me add kar diya hai Boss! 🛒✨ Ab boliye 'buy now' karna hai ya 'address fill' karna hai?"
                        liveActionNotice = "Cart me item add ho gaya!"
                        onSpeakFeedback(msg)
                    } else {
                        val msg = "Cart button search kar rahi hoon... Aap screen par item choose kijiye aur boliye 'Add to cart'!"
                        liveActionNotice = "Item select karke 'Add to cart' boliye"
                        onSpeakFeedback(msg)
                    }
                }
            }

            // 2. BUY NOW / ORDER NOW / PLACE ORDER / CHECKOUT / PROCEED
            lower.contains("buy now") || lower.contains("order now") || lower.contains("place order") ||
            lower.contains("checkout") || lower.contains("proceed") || lower.contains("kharido") || lower.contains("kharid") ||
            lower.contains("order kardo") || lower.contains("order karde") || lower.contains("order karo") -> {
                val js = """
                    (function() {
                        const keywords = ['buy now', 'place order', 'proceed to checkout', 'proceed to pay', 'deliver here', 'order now', 'continue', 'pay now', 'kharide', 'proceed'];
                        const elements = Array.from(document.querySelectorAll('button, a, div[role="button"], span[role="button"], input[type="submit"]'));
                        for (const el of elements) {
                            const text = (el.innerText || el.textContent || el.value || el.getAttribute('aria-label') || '').toLowerCase().trim();
                            if (keywords.some(k => text.includes(k))) {
                                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                el.click();
                                return 'SUCCESS_CLICKED: ' + text;
                            }
                        }
                        return 'NOT_FOUND';
                    })();
                """.trimIndent()
                runJs(js) { res ->
                    if (res != null && res.contains("SUCCESS")) {
                        val msg = "Buy Now aur Checkout page par proceed kar diya hai Boss! ⚡ Aapka address aur account details ready hain!"
                        liveActionNotice = "Proceed to Buy Now/Checkout!"
                        onSpeakFeedback(msg)
                    } else {
                        val msg = "Order place/Buy now button par click karne ki koshish ki hai Boss! Screen check kijiye!"
                        onSpeakFeedback(msg)
                    }
                }
            }

            // 3. AUTO-FILL ADDRESS FROM SAVED PROFILE
            lower.contains("address") || lower.contains("pata") || lower.contains("details") || lower.contains("profile") ||
            lower.contains("fill") || lower.contains("bhar") || lower.contains("daal") -> {
                val profile = ZoyaPreferences.getUserOrderProfile(context)
                val profileJson = JSONObject().apply {
                    put("name", profile.fullName)
                    put("phone", profile.phoneNumber)
                    put("email", profile.email)
                    put("address1", profile.addressLine1)
                    put("address2", profile.addressLine2)
                    put("landmark", profile.landmark)
                    put("city", profile.city)
                    put("state", profile.state)
                    put("pincode", profile.pincode)
                }.toString()

                val js = """
                    (function() {
                        const p = $profileJson;
                        let count = 0;
                        function setVal(el, val) {
                            if (!el || !val) return;
                            el.focus();
                            el.value = val;
                            el.dispatchEvent(new Event('input', { bubbles: true }));
                            el.dispatchEvent(new Event('change', { bubbles: true }));
                            el.dispatchEvent(new Event('blur', { bubbles: true }));
                            count++;
                        }

                        // Full Name
                        document.querySelectorAll('input[name*="name" i], input[id*="name" i], input[placeholder*="name" i], input[autocomplete*="name" i]').forEach(el => {
                            if (!el.value) setVal(el, p.name);
                        });

                        // Phone
                        document.querySelectorAll('input[name*="phone" i], input[name*="mobile" i], input[id*="phone" i], input[id*="mobile" i], input[type="tel"]').forEach(el => {
                            if (!el.value) setVal(el, p.phone);
                        });

                        // Pincode
                        document.querySelectorAll('input[name*="pin" i], input[name*="postal" i], input[id*="pin" i], input[placeholder*="pin" i]').forEach(el => {
                            if (!el.value) setVal(el, p.pincode);
                        });

                        // City
                        document.querySelectorAll('input[name*="city" i], input[id*="city" i], input[placeholder*="city" i]').forEach(el => {
                            if (!el.value) setVal(el, p.city);
                        });

                        // State
                        document.querySelectorAll('input[name*="state" i], input[id*="state" i], select[name*="state" i]').forEach(el => {
                            setVal(el, p.state);
                        });

                        // Address / Street / House
                        document.querySelectorAll('textarea, input[name*="address" i], input[name*="street" i], input[name*="flat" i], input[name*="house" i], input[placeholder*="address" i]').forEach(el => {
                            if (!el.value) setVal(el, p.address1 + ', ' + p.address2 + (p.landmark ? ' (Near ' + p.landmark + ')' : ''));
                        });

                        // Landmark
                        document.querySelectorAll('input[name*="landmark" i], input[id*="landmark" i], input[placeholder*="landmark" i]').forEach(el => {
                            if (!el.value) setVal(el, p.landmark);
                        });

                        return 'FILLED_' + count;
                    })();
                """.trimIndent()
                runJs(js) { res ->
                    val msg = "Aapka saved profile naam (${profile.fullName}), phone number (${profile.phoneNumber}) aur delivery address (${profile.city}, ${profile.pincode}) fill kar diya hai Boss! 🏠✨"
                    liveActionNotice = "Saved Address & Details auto-filled!"
                    onSpeakFeedback(msg)
                }
            }

            // 4. TRAIN TICKET BOOKING & PASSENGER AUTO-FILL
            lower.contains("passenger") || lower.contains("train") || lower.contains("ticket") || lower.contains("yatri") ||
            lower.contains("seat") || lower.contains("berth") || lower.contains("irctc") -> {
                val profile = ZoyaPreferences.getUserOrderProfile(context)
                val passengerJson = JSONObject().apply {
                    put("name", profile.fullName)
                    put("age", profile.passengerAge)
                    put("gender", profile.passengerGender)
                    put("berth", profile.berthPreference)
                    put("irctcUser", profile.irctcUsername)
                }.toString()

                val js = """
                    (function() {
                        const p = $passengerJson;
                        let count = 0;
                        function setVal(el, val) {
                            if (!el || !val) return;
                            el.focus();
                            el.value = val;
                            el.dispatchEvent(new Event('input', { bubbles: true }));
                            el.dispatchEvent(new Event('change', { bubbles: true }));
                            el.dispatchEvent(new Event('blur', { bubbles: true }));
                            count++;
                        }

                        // Passenger Name
                        document.querySelectorAll('input[placeholder*="passenger" i], input[name*="passenger" i], input[name*="pax" i], input[id*="passenger" i]').forEach(el => {
                            if (!el.value) setVal(el, p.name);
                        });

                        // Age
                        document.querySelectorAll('input[name*="age" i], input[placeholder*="age" i], input[id*="age" i]').forEach(el => {
                            if (!el.value) setVal(el, p.age);
                        });

                        // IRCTC User
                        document.querySelectorAll('input[placeholder*="irctc" i], input[name*="irctc" i]').forEach(el => {
                            if (!el.value) setVal(el, p.irctcUser);
                        });

                        // Also try clicking "Book Now" / "Search Trains" / "Review Booking"
                        const bookButtons = Array.from(document.querySelectorAll('button, a, div[role="button"]'));
                        for (const b of bookButtons) {
                            const txt = (b.innerText || b.textContent || '').toLowerCase();
                            if (txt.includes('book now') || txt.includes('book ticket') || txt.includes('proceed to book') || txt.includes('continue')) {
                                b.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                b.click();
                                count++;
                                break;
                            }
                        }

                        return 'PASSENGER_FILLED_' + count;
                    })();
                """.trimIndent()
                runJs(js) {
                    val msg = "Train passenger details (${profile.fullName}, Age ${profile.passengerAge}, ${profile.passengerGender}) aur booking fields update kar diye hain Boss! 🚆🎫✨"
                    liveActionNotice = "Passenger details filled!"
                    onSpeakFeedback(msg)
                }
            }

            // 5. SCROLL DOWN
            lower.contains("scroll down") || lower.contains("niche") || lower.contains("neeche") || lower == "down" || lower.contains("scroll") && !lower.contains("up") -> {
                runJs("window.scrollBy({ top: 500, behavior: 'smooth' }); 'SCROLLED_DOWN';") {
                    liveActionNotice = "Page scrolled down ⬇️"
                }
            }

            // 6. SCROLL UP
            lower.contains("scroll up") || lower.contains("upar") || lower == "up" -> {
                runJs("window.scrollBy({ top: -500, behavior: 'smooth' }); 'SCROLLED_UP';") {
                    liveActionNotice = "Page scrolled up ⬆️"
                }
            }

            // 7. CLICK FIRST ITEM / SELECT ITEM
            lower.contains("first") || lower.contains("pehla") || lower.contains("select") || lower.contains("kholo") || lower.contains("open") -> {
                val js = """
                    (function() {
                        // Look for product cards / main items
                        const items = Array.from(document.querySelectorAll('a[href*="/dp/"], a[href*="/product/"], a[href*="/item/"], a[href*="/p/"], a[class*="product" i], div[data-component-type="s-search-result"] a'));
                        if (items.length > 0) {
                            items[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
                            items[0].click();
                            return 'CLICKED_FIRST_PRODUCT';
                        }
                        // Fallback: first prominent link in results
                        const firstLink = document.querySelector('h2 a, h3 a, [class*="title" i] a, [class*="card" i] a');
                        if (firstLink) {
                            firstLink.click();
                            return 'CLICKED_FIRST_LINK';
                        }
                        return 'NOT_FOUND';
                    })();
                """.trimIndent()
                runJs(js) { res ->
                    if (res != null && res.contains("CLICKED")) {
                        val msg = "Pehla item open kar diya hai Boss! Details load ho rahi hain! 📦"
                        liveActionNotice = "Item selected!"
                        onSpeakFeedback(msg)
                    } else {
                        onSpeakFeedback("Item open karne ke liye screen par product tap kijiye Boss!")
                    }
                }
            }

            // 8. SEARCH ON PAGE
            lower.startsWith("search") || lower.contains("khojo") || lower.contains("dhoondo") -> {
                val queryToSearch = command.replace(Regex("""(?i)\b(search|karo|khojo|dhoondo|kardo|on|in|page)\b"""), "").trim()
                val cleanQuery = if (queryToSearch.isBlank()) searchQuery else queryToSearch
                val js = """
                    (function() {
                        const input = document.querySelector('input[type="search"], input[name*="search" i], input[name="q"], input[placeholder*="search" i], input[placeholder*="khoje" i], input[id*="search" i]');
                        if (input) {
                            input.focus();
                            input.value = '$cleanQuery';
                            input.dispatchEvent(new Event('input', { bubbles: true }));
                            input.dispatchEvent(new Event('change', { bubbles: true }));
                            // Try submitting form
                            if (input.form) {
                                input.form.submit();
                                return 'SUBMITTED_FORM';
                            }
                            // Or press enter
                            input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
                            return 'ENTER_PRESSED';
                        }
                        return 'SEARCH_BOX_NOT_FOUND';
                    })();
                """.trimIndent()
                runJs(js) {
                    val msg = "'$cleanQuery' search kar diya hai Boss! 🔍"
                    liveActionNotice = "Searched: $cleanQuery"
                    onSpeakFeedback(msg)
                }
            }

            // 9. REFRESH / BACK
            lower.contains("refresh") || lower.contains("reload") -> {
                webViewInstance?.reload()
                liveActionNotice = "Page reloading..."
                onSpeakFeedback("Page refresh kar diya hai! 🔄")
            }

            lower.contains("back") || lower.contains("piche") -> {
                if (webViewInstance?.canGoBack() == true) {
                    webViewInstance?.goBack()
                    liveActionNotice = "Went back"
                    onSpeakFeedback("Piche wale page par aa gaye hain Boss! 🔙")
                } else {
                    onSpeakFeedback("Piche koi page nahi hai Boss!")
                }
            }

            // 10. GENERAL QUERY / COMPREHENSION: Let Zoya AI process it
            else -> {
                onExecuteVoiceQuery(command)
            }
        }
    }

    // When new voice query arrives through transcript while web automation is active
    LaunchedEffect(liveTranscript) {
        if (liveTranscript.isNotBlank() && !isSpeaking) {
            typedCommand = liveTranscript
        }
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = DarkSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Top Navigation & Control Header
            Surface(
                color = DarkSurfaceVariant,
                tonalElevation = 4.dp,
                border = BorderStroke(0.8.dp, DarkBorder)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Close / Back button
                        IconButton(onClick = {
                            if (webViewInstance?.canGoBack() == true) {
                                webViewInstance?.goBack()
                            } else {
                                onDismiss()
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = NeonPink
                            )
                        }

                        // Web Title & URL bar
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    Toast.makeText(context, currentUrl, Toast.LENGTH_SHORT).show()
                                }
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.Lock,
                                    contentDescription = "SSL Secure",
                                    tint = CyberTeal,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = currentTitle.ifBlank { platform.replaceFirstChar { it.uppercase() } },
                                    style = MaterialTheme.typography.titleSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                text = try { Uri.parse(currentUrl).host ?: currentUrl } catch (_: Exception) { currentUrl },
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberTeal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontSize = 11.sp
                            )
                        }

                        // Profile & Address Manager quick button
                        IconButton(
                            onClick = { showProfileDialog = true }
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AccountCircle,
                                contentDescription = "Saved Profile",
                                tint = SunnyAmber,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Reload button
                        IconButton(onClick = { webViewInstance?.reload() }) {
                            Icon(
                                imageVector = Icons.Rounded.Refresh,
                                contentDescription = "Reload",
                                tint = Color.LightGray
                            )
                        }

                        // Desktop Mode Toggle button
                        IconButton(onClick = {
                            isDesktopMode = !isDesktopMode
                            webViewInstance?.let { wv ->
                                wv.settings.userAgentString = if (isDesktopMode) {
                                    com.example.ai.AiStudioAutomationHelper.DESKTOP_USER_AGENT
                                } else {
                                    com.example.ai.AiStudioAutomationHelper.MOBILE_USER_AGENT
                                }
                                wv.settings.useWideViewPort = isDesktopMode
                                wv.settings.loadWithOverviewMode = isDesktopMode
                                wv.reload()
                            }
                            val modeMsg = if (isDesktopMode) "Desktop Mode On 🖥️ (Full Workspace)" else "Mobile Mode On 📱"
                            Toast.makeText(context, modeMsg, Toast.LENGTH_SHORT).show()
                            liveActionNotice = modeMsg
                        }) {
                            Icon(
                                imageVector = if (isDesktopMode) Icons.Rounded.DesktopWindows else Icons.Rounded.Smartphone,
                                contentDescription = if (isDesktopMode) "Desktop Mode Active" else "Mobile Mode Active",
                                tint = if (isDesktopMode) CyberTeal else Color.LightGray,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // Open in Chrome / External browser
                        IconButton(onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl)).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Chrome nahi khul paya: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Rounded.OpenInBrowser,
                                contentDescription = "Open in Chrome",
                                tint = RadiantCoral
                            )
                        }

                        // Exit button
                        IconButton(onClick = onDismiss) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Close",
                                tint = Color.LightGray
                            )
                        }
                    }

                    // Progress indicator
                    if (isPageLoading) {
                        LinearProgressIndicator(
                            progress = { pageProgress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(2.5.dp),
                            color = CyberTeal,
                            trackColor = DarkSurface
                        )
                    }
                }
            }

            // WebView Container
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )

                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                setSupportZoom(true)
                                builtInZoomControls = true
                                displayZoomControls = false
                                loadWithOverviewMode = true
                                useWideViewPort = true
                                cacheMode = WebSettings.LOAD_DEFAULT
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                // Set User Agent according to Desktop Mode
                                userAgentString = if (isDesktopMode) {
                                    com.example.ai.AiStudioAutomationHelper.DESKTOP_USER_AGENT
                                } else {
                                    com.example.ai.AiStudioAutomationHelper.MOBILE_USER_AGENT
                                }
                            }

                            // Allow third-party cookies for login/e-commerce sessions
                            val cookieManager = CookieManager.getInstance()
                            cookieManager.setAcceptCookie(true)
                            cookieManager.setAcceptThirdPartyCookies(this, true)

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    isPageLoading = true
                                    url?.let { currentUrl = it }
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    isPageLoading = false
                                    url?.let { currentUrl = it }
                                    currentTitle = view?.title ?: platform

                                    val isAiStudio = platform.contains("Google AI Studio", ignoreCase = true) ||
                                            (url ?: "").contains("aistudio.google.com")

                                    if (isDesktopMode) {
                                        view?.evaluateJavascript(com.example.ai.AiStudioAutomationHelper.getForceDesktopViewportJs(), null)
                                    }

                                    if (isAiStudio && searchQuery.isNotBlank()) {
                                        // Execute Google AI Studio prompt injection & run automation
                                        executeAiStudioPromptInjection(searchQuery)
                                    } else if (searchQuery.isNotBlank()) {
                                        executeInPageAction("search $searchQuery")
                                    }
                                }

                                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                    val uri = request?.url ?: return false
                                    val scheme = uri.scheme?.lowercase() ?: ""
                                    if (scheme == "http" || scheme == "https") {
                                        return false
                                    }
                                    // For intent:// schemes, try extracting fallback browser URL to stay inside WebView!
                                    if (scheme == "intent") {
                                        try {
                                            val parsedIntent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                                            val fallbackUrl = parsedIntent?.getStringExtra("browser_fallback_url")
                                            if (!fallbackUrl.isNullOrBlank()) {
                                                view?.loadUrl(fallbackUrl)
                                                return true
                                            }
                                        } catch (_: Exception) {}
                                        return true // Swallow external intent to prevent leaving the application!
                                    }
                                    if (scheme == "tel" || scheme == "mailto" || scheme == "upi") {
                                        return try {
                                            val intent = Intent(Intent.ACTION_VIEW, uri)
                                            ctx.startActivity(intent)
                                            true
                                        } catch (_: Exception) {
                                            true
                                        }
                                    }
                                    return true // Always stay inside the app!
                                }
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    pageProgress = newProgress
                                    if (newProgress >= 100) {
                                        isPageLoading = false
                                    }
                                }

                                override fun onReceivedTitle(view: WebView?, title: String?) {
                                    if (!title.isNullOrBlank()) {
                                        currentTitle = title
                                    }
                                }
                            }

                            loadUrl(initialUrl)
                            webViewInstance = this
                        }
                    },
                    update = { view ->
                        webViewInstance = view
                    }
                )
            }

            // Persistent Zoya AI Voice Co-Pilot Bar (Bottom Overlay)
            Surface(
                color = DarkSurface,
                tonalElevation = 8.dp,
                border = BorderStroke(
                    1.2.dp,
                    Brush.horizontalGradient(listOf(NeonPink, CyberTeal, SunnyAmber))
                ),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Status and Live Feedback row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (isListening) CyberTeal else if (isSpeaking) NeonPink else SunnyAmber)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when {
                                    isListening -> "Zoya Sun Rahi Hai... 🎙️"
                                    isSpeaking -> "Zoya Bol Rahi Hai... 🔊"
                                    else -> "Zoya Co-Pilot Active ⚡"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isListening) CyberTeal else if (isSpeaking) NeonPink else Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (liveActionNotice != null) {
                            Text(
                                text = liveActionNotice!!,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.LightGray,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontSize = 10.sp
                            )
                        }
                    }

                    val isAiStudioMode = platform.contains("Google AI Studio", ignoreCase = true) ||
                            currentUrl.contains("aistudio.google.com")

                    // Live AI Studio Build Status Banner (Starts, Errors, Completed)
                    if (isAiStudioMode) {
                        when (aiStudioBuildStatus) {
                            "BUILDING" -> {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = CyberTeal.copy(alpha = 0.18f),
                                    border = BorderStroke(1.2.dp, CyberTeal),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("⚡", fontSize = 15.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "Application Banana Start Ho Gaya Hai! 🚀",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = CyberTeal
                                            )
                                            Text(
                                                text = "Desktop Mode Active • Code generating & compiling in AI Studio...",
                                                fontSize = 9.5.sp,
                                                color = Color.LightGray
                                            )
                                        }
                                    }
                                }
                            }
                            "COMPLETED" -> {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = SunnyAmber.copy(alpha = 0.22f),
                                    border = BorderStroke(1.2.dp, SunnyAmber),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("🎉", fontSize = 16.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "Mubarak Ho Boss! Application Ban Kar Ready Ho Gaya! ✨",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = SunnyAmber
                                            )
                                            Text(
                                                text = "Application complete ho gaya hai! Live preview screen par chal raha hai.",
                                                fontSize = 9.5.sp,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                            "ERROR" -> {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = RadiantCoral.copy(alpha = 0.18f),
                                    border = BorderStroke(1.2.dp, RadiantCoral),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("⚠️", fontSize = 15.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "AI Studio Build Error",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = RadiantCoral
                                            )
                                            Text(
                                                text = aiStudioErrorMessage ?: "Build me problem aayi hai",
                                                fontSize = 9.5.sp,
                                                color = Color.LightGray,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Dedicated AI Studio Prompt Card Preview
                    if (isAiStudioMode && searchQuery.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color.Black.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, CyberTeal.copy(alpha = 0.4f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.ElectricBolt,
                                            contentDescription = null,
                                            tint = SunnyAmber,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Google AI Studio Developer Prompt (Auto-Injected)",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CyberTeal
                                        )
                                    }
                                    Text(
                                        text = "📋 Copy",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NeonPink,
                                        modifier = Modifier.clickable { copyPromptToClipboard() }
                                    )
                                }
                                Text(
                                    text = searchQuery.take(140) + if (searchQuery.length > 140) "..." else "",
                                    fontSize = 10.sp,
                                    color = Color.LightGray,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Quick Voice/Action Pills Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isAiStudioMode) {
                            AssistChip(
                                onClick = { executeAiStudioPromptInjection(searchQuery) },
                                label = { Text("🚀 Build New App", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = CyberTeal.copy(alpha = 0.25f), labelColor = Color.White),
                                border = BorderStroke(1.dp, CyberTeal.copy(alpha = 0.6f))
                            )

                            AssistChip(
                                onClick = {
                                    isDesktopMode = !isDesktopMode
                                    webViewInstance?.let { wv ->
                                        wv.settings.userAgentString = if (isDesktopMode) {
                                            com.example.ai.AiStudioAutomationHelper.DESKTOP_USER_AGENT
                                        } else {
                                            com.example.ai.AiStudioAutomationHelper.MOBILE_USER_AGENT
                                        }
                                        wv.settings.useWideViewPort = isDesktopMode
                                        wv.settings.loadWithOverviewMode = isDesktopMode
                                        wv.reload()
                                    }
                                    val modeMsg = if (isDesktopMode) "Desktop Mode On 🖥️ (Full Workspace)" else "Mobile Mode On 📱"
                                    Toast.makeText(context, modeMsg, Toast.LENGTH_SHORT).show()
                                    liveActionNotice = modeMsg
                                },
                                label = { Text(if (isDesktopMode) "🖥️ Desktop View (On)" else "📱 Mobile View", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = if (isDesktopMode) CyberTeal.copy(alpha = 0.25f) else DarkSurfaceVariant,
                                    labelColor = Color.White
                                ),
                                border = BorderStroke(1.dp, if (isDesktopMode) CyberTeal else DarkBorder)
                            )

                            AssistChip(
                                onClick = {
                                    val js = com.example.ai.AiStudioAutomationHelper.getNavigateToNewAppJs()
                                    runJs(js) {
                                        executeAiStudioPromptInjection(searchQuery)
                                    }
                                },
                                label = { Text("➕ New App Kholo", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = SunnyAmber.copy(alpha = 0.25f), labelColor = Color.White),
                                border = BorderStroke(1.dp, SunnyAmber.copy(alpha = 0.6f))
                            )

                            AssistChip(
                                onClick = { copyPromptToClipboard() },
                                label = { Text("📋 Copy Prompt", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = NeonPink.copy(alpha = 0.2f), labelColor = Color.White),
                                border = BorderStroke(1.dp, NeonPink.copy(alpha = 0.5f))
                            )

                            AssistChip(
                                onClick = { webViewInstance?.reload() },
                                label = { Text("🔄 Re-Run Build", fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = SunnyAmber.copy(alpha = 0.2f), labelColor = Color.White),
                                border = BorderStroke(1.dp, SunnyAmber.copy(alpha = 0.5f))
                            )

                            AssistChip(
                                onClick = { executeInPageAction("Scroll down") },
                                label = { Text("⬇️ Scroll Down", fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = DarkSurfaceVariant, labelColor = Color.LightGray),
                                border = BorderStroke(0.8.dp, DarkBorder)
                            )

                            AssistChip(
                                onClick = { executeInPageAction("Scroll up") },
                                label = { Text("⬆️ Scroll Up", fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = DarkSurfaceVariant, labelColor = Color.LightGray),
                                border = BorderStroke(0.8.dp, DarkBorder)
                            )
                        } else {
                            AssistChip(
                                onClick = { executeInPageAction("Add to cart") },
                                label = { Text("🛒 Add to Cart", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = NeonPink.copy(alpha = 0.2f), labelColor = Color.White),
                                border = BorderStroke(1.dp, NeonPink.copy(alpha = 0.5f))
                            )

                            AssistChip(
                                onClick = { executeInPageAction("Buy now") },
                                label = { Text("⚡ Buy Now / Order", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = CyberTeal.copy(alpha = 0.2f), labelColor = Color.White),
                                border = BorderStroke(1.dp, CyberTeal.copy(alpha = 0.5f))
                            )

                            AssistChip(
                                onClick = { executeInPageAction("Fill my address") },
                                label = { Text("📍 Fill My Address", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = SunnyAmber.copy(alpha = 0.2f), labelColor = Color.White),
                                border = BorderStroke(1.dp, SunnyAmber.copy(alpha = 0.5f))
                            )

                            AssistChip(
                                onClick = { executeInPageAction("Fill passenger info") },
                                label = { Text("🚆 Passenger Info", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = MagentaRose.copy(alpha = 0.2f), labelColor = Color.White),
                                border = BorderStroke(1.dp, MagentaRose.copy(alpha = 0.5f))
                            )

                            AssistChip(
                                onClick = { executeInPageAction("Scroll down") },
                                label = { Text("⬇️ Scroll Down", fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = DarkSurfaceVariant, labelColor = Color.LightGray),
                                border = BorderStroke(0.8.dp, DarkBorder)
                            )

                            AssistChip(
                                onClick = { executeInPageAction("Scroll up") },
                                label = { Text("⬆️ Scroll Up", fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = DarkSurfaceVariant, labelColor = Color.LightGray),
                                border = BorderStroke(0.8.dp, DarkBorder)
                            )

                            AssistChip(
                                onClick = { executeInPageAction("First item kholo") },
                                label = { Text("📦 Select Item", fontSize = 11.sp) },
                                colors = AssistChipDefaults.assistChipColors(containerColor = DarkSurfaceVariant, labelColor = Color.LightGray),
                                border = BorderStroke(0.8.dp, DarkBorder)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Text & Voice Input Command Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = typedCommand,
                            onValueChange = { typedCommand = it },
                            placeholder = {
                                Text(
                                    if (isAiStudioMode) "AI Studio command: 'Run karo', 'Build app', 'Scroll down'..." else "Website me jo karwana ho boliye ya likhiye...",
                                    fontSize = 12.sp,
                                    color = Color.Gray
                                )
                            },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(25.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberTeal,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedContainerColor = DarkSurfaceVariant,
                                unfocusedContainerColor = DarkSurfaceVariant
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        // Send button for typed command
                        if (typedCommand.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    val cmd = typedCommand.trim()
                                    typedCommand = ""
                                    executeInPageAction(cmd)
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(CyberTeal, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Send,
                                    contentDescription = "Send",
                                    tint = Color.Black,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                        }

                        // Voice Mic Button (Interactive with pulsing animation)
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(48.dp)
                                .scale(pulseScale)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        if (isListening) listOf(CyberTeal, DeepViolet)
                                        else listOf(NeonPink, MagentaRose)
                                    )
                                )
                                .clickable {
                                    if (isListening) {
                                        onStopListening()
                                    } else {
                                        if (isSpeaking) {
                                            onStopSpeaking()
                                        }
                                        onStartListening()
                                    }
                                }
                        ) {
                            Icon(
                                imageVector = if (isListening) Icons.Rounded.Mic else Icons.Rounded.MicOff,
                                contentDescription = "Voice Command",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Saved Profile & Delivery Details Dialog
    if (showProfileDialog) {
        SavedProfileManagerDialog(
            onDismiss = { showProfileDialog = false },
            onProfileSaved = { updatedProfile ->
                showProfileDialog = false
                val msg = "Aapka delivery address aur profile save ho gaya hai Boss! 🏠✅"
                liveActionNotice = msg
                onSpeakFeedback(msg)
            }
        )
    }
}
