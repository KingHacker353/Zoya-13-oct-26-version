package com.example.ai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

object GeminiVoiceService {

    private const val TAG = "GeminiVoiceService"
    private val TTS_MODELS = listOf("gemini-2.5-flash-preview-tts", "gemini-3.8-flash-tts", "gemini-3.1-flash-tts-preview")
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    @Volatile
    private var mediaPlayer: MediaPlayer? = null
    @Volatile
    private var currentAudioTrack: AudioTrack? = null
    @Volatile
    private var isVoicePlaying = false
    @Volatile
    private var isPlaybackCancelled = false

    data class SynthesizedChunk(
        val pcmBytes: ByteArray,
        val sampleRate: Int,
        val wavFile: File? = null
    )

    /**
     * Splits full text into natural, coherent speech chunks at sentence boundaries.
     * Prevents any text truncation while keeping chunk sizes optimal for Gemini TTS.
     */
    fun splitIntoSpeechChunks(text: String, maxChunkSize: Int = 680): List<String> {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return emptyList()
        if (trimmed.length <= maxChunkSize) return listOf(trimmed)

        val chunks = mutableListOf<String>()
        var remaining = trimmed

        while (remaining.isNotEmpty()) {
            if (remaining.length <= maxChunkSize) {
                chunks.add(remaining)
                break
            }

            val candidate = remaining.take(maxChunkSize)
            val delimiters = listOf("\n\n", "\n", "। ", ". ", "! ", "? ", ", ")
            var splitIndex = -1

            for (delim in delimiters) {
                val idx = candidate.lastIndexOf(delim)
                if (idx >= 200) {
                    splitIndex = idx + delim.length
                    break
                }
            }

            if (splitIndex == -1) {
                val spaceIdx = candidate.lastIndexOf(' ')
                splitIndex = if (spaceIdx >= 200) spaceIdx + 1 else maxChunkSize
            }

            val chunk = remaining.substring(0, splitIndex).trim()
            if (chunk.isNotEmpty()) {
                chunks.add(chunk)
            }
            remaining = remaining.substring(splitIndex).trim()
        }

        return chunks
    }

    /**
     * Synthesize a single chunk to raw PCM and optional WAV audio file.
     */
    private suspend fun synthesizeChunk(
        apiKey: String,
        chunkText: String,
        voiceName: String,
        cacheDir: File
    ): SynthesizedChunk? = withContext(Dispatchers.IO) {
        val requestJson = JSONObject().apply {
            val contentsArr = JSONArray().apply {
                val partObj = JSONObject().apply {
                    put("text", "Read the following text aloud without adding anything else: $chunkText")
                }
                val contentObj = JSONObject().apply {
                    put("parts", JSONArray().put(partObj))
                }
                put(contentObj)
            }
            put("contents", contentsArr)

            val generationConfig = JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                val voiceConfig = JSONObject().apply {
                    val prebuiltVoiceConfig = JSONObject().apply {
                        put("voiceName", voiceName)
                    }
                    put("prebuiltVoiceConfig", prebuiltVoiceConfig)
                }
                val speechConfig = JSONObject().apply {
                    put("voiceConfig", voiceConfig)
                }
                put("speechConfig", speechConfig)
            }
            put("generationConfig", generationConfig)
        }

        val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())

        for (model in TTS_MODELS) {
            if (isPlaybackCancelled) return@withContext null
            for (attempt in 1..2) {
                if (isPlaybackCancelled) return@withContext null
                try {
                    val url = "$BASE_URL/$model:generateContent?key=$apiKey"
                    val httpRequest = Request.Builder()
                        .url(url)
                        .post(requestBody)
                        .build()

                    val response = okHttpClient.newCall(httpRequest).execute()
                    val responseBody = response.body?.string() ?: ""

                    if (!response.isSuccessful) {
                        Log.w(TAG, "Gemini Voice model $model attempt $attempt error: ${response.code} $responseBody")
                        if (response.code == 404 || response.code == 400) break
                        delay(150)
                        continue
                    }

                val jsonRes = JSONObject(responseBody)
                val candidates = jsonRes.optJSONArray("candidates")
                val candidate = candidates?.optJSONObject(0)
                val content = candidate?.optJSONObject("content")
                val parts = content?.optJSONArray("parts")

                var audioBase64: String? = null
                var mimeType = "audio/wav"

                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val part = parts.optJSONObject(i)
                        val inlineData = part?.optJSONObject("inlineData")
                        if (inlineData != null) {
                            audioBase64 = inlineData.optString("data")
                            mimeType = inlineData.optString("mimeType", "audio/wav")
                            break
                        }
                    }
                }

                if (audioBase64.isNullOrEmpty()) {
                    delay(150)
                    continue
                }

                val rawBytes = Base64.decode(audioBase64, Base64.DEFAULT)
                val hasRiff = isWavFile(rawBytes)
                val rateMatch = Regex("""rate=(\d+)""").find(mimeType.lowercase())
                val sampleRate = rateMatch?.groupValues?.get(1)?.toIntOrNull() ?: 24000

                val pcmData = if (hasRiff && rawBytes.size > 44) {
                    rawBytes.copyOfRange(44, rawBytes.size)
                } else {
                    rawBytes
                }

                val tempFile = try {
                    val wavBytes = if (!hasRiff) {
                        pcmToWav(rawBytes, sampleRate = sampleRate, channels = 1, bitsPerSample = 16)
                    } else {
                        rawBytes
                    }
                    val f = File(cacheDir, "gemini_voice_${System.currentTimeMillis()}_${(100..999).random()}.wav")
                    FileOutputStream(f).use { it.write(wavBytes) }
                    f
                } catch (_: Exception) {
                    null
                }

                return@withContext SynthesizedChunk(
                    pcmBytes = pcmData,
                    sampleRate = sampleRate,
                    wavFile = tempFile
                )
            } catch (e: Exception) {
                Log.w(TAG, "Synthesis attempt $attempt failed", e)
                delay(150)
            }
        }
    }
    null
}

    /**
     * Unmute audio volume if device volume is set to 0.
     */
    private fun ensureVolumeNotMuted(context: Context) {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (audioManager != null) {
                val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                if (currentVol == 0 && maxVol > 0) {
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (maxVol * 0.75f).toInt(), 0)
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * Synthesize and speak text using Gemini AI Voice API.
     * Uses ultra-reliable AudioTrack for hardware PCM output and MediaPlayer as fallback.
     */
    suspend fun speakWithGemini(
        context: Context,
        text: String,
        voiceName: String = "Aoede",
        onStart: () -> Unit = {},
        onComplete: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) = withContext(Dispatchers.IO) {
        val savedKey = com.example.data.ZoyaPreferences.getGeminiApiKey(context).trim()
        val apiKey = if (savedKey.isNotEmpty() && savedKey != "MY_GEMINI_API_KEY") {
            savedKey
        } else {
            try { BuildConfig.GEMINI_API_KEY.trim() } catch (e: Exception) { "" }
        }
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            withContext(Dispatchers.Main) {
                onError("Gemini API Key missing. Please configure your key in Zoya Settings.")
            }
            return@withContext
        }

        try {
            stopPlayback()
            isPlaybackCancelled = false
            ensureVolumeNotMuted(context)

            val cleanText = text.replace(Regex("<action[^>]*/>"), "").trim()
            if (cleanText.isEmpty()) {
                withContext(Dispatchers.Main) { onComplete() }
                return@withContext
            }

            // Split into natural chunks so full detailed answers are spoken without truncation
            val chunks = splitIntoSpeechChunks(cleanText, 680)
            if (chunks.isEmpty()) {
                withContext(Dispatchers.Main) { onComplete() }
                return@withContext
            }

            // Synthesize the first chunk immediately for fast initial speech
            val firstChunk = synthesizeChunk(apiKey, chunks[0], voiceName, context.cacheDir)
            if (firstChunk == null) {
                if (!isPlaybackCancelled) {
                    withContext(Dispatchers.Main) {
                        onError("Gemini Voice synthesis failed.")
                    }
                }
                return@withContext
            }

            if (isPlaybackCancelled) {
                try { firstChunk.wavFile?.delete() } catch (_: Exception) {}
                return@withContext
            }

            withContext(Dispatchers.Main) {
                onStart()
            }

            var currentChunk: SynthesizedChunk? = firstChunk

            for (index in chunks.indices) {
                if (isPlaybackCancelled) break

                // While current chunk plays, asynchronously pre-fetch the next chunk
                val nextChunkDeferred: Deferred<SynthesizedChunk?>? = if (index + 1 < chunks.size) {
                    val nextChunkText = chunks[index + 1]
                    async(Dispatchers.IO) {
                        synthesizeChunk(apiKey, nextChunkText, voiceName, context.cacheDir)
                    }
                } else {
                    null
                }

                val chunkToPlay = currentChunk ?: break

                // Primary hardware playback: AudioTrack (low-latency PCM)
                // Secondary fallback: MediaPlayer with FileInputStream
                val playSuccess = playWithAudioTrack(chunkToPlay.pcmBytes, chunkToPlay.sampleRate) ||
                        (chunkToPlay.wavFile != null && playWithMediaPlayer(chunkToPlay.wavFile))

                try { chunkToPlay.wavFile?.delete() } catch (_: Exception) {}

                if (!playSuccess || isPlaybackCancelled) {
                    nextChunkDeferred?.cancel()
                    break
                }

                currentChunk = nextChunkDeferred?.await()
            }

            withContext(Dispatchers.Main) {
                isVoicePlaying = false
                if (!isPlaybackCancelled) {
                    onComplete()
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Exception during Gemini Voice synthesis", e)
            withContext(Dispatchers.Main) {
                isVoicePlaying = false
                if (!isPlaybackCancelled) {
                    onError(e.localizedMessage ?: "Unknown error")
                }
            }
        }
    }

    /**
     * Primary hardware PCM playback using AudioTrack.
     * Guaranteed compatibility across all Android versions without file permission or mediaserver issues.
     */
    private suspend fun playWithAudioTrack(
        pcmBytes: ByteArray,
        sampleRate: Int
    ): Boolean = withContext(Dispatchers.IO) {
        if (isPlaybackCancelled || pcmBytes.isEmpty()) return@withContext false

        var track: AudioTrack? = null
        try {
            val minBufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = maxOf(minBufferSize * 2, 8192)

            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            track = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            currentAudioTrack = track
            track.setVolume(1.0f)
            track.play()
            isVoicePlaying = true

            var offset = 0
            val total = pcmBytes.size
            val chunkSize = 4096

            while (offset < total && !isPlaybackCancelled) {
                val toWrite = minOf(chunkSize, total - offset)
                val written = track.write(pcmBytes, offset, toWrite)
                if (written <= 0) break
                offset += written
            }

            // Wait until the audio hardware finishes rendering remaining frames
            val totalFrames = total / 2 // 16-bit mono = 2 bytes per frame
            while (!isPlaybackCancelled) {
                val head = try { track.playbackHeadPosition } catch (_: Exception) { totalFrames }
                if (head >= totalFrames) break
                delay(30)
            }

            try {
                track.stop()
                track.release()
            } catch (_: Exception) {}
            currentAudioTrack = null

            return@withContext !isPlaybackCancelled
        } catch (e: Exception) {
            Log.e(TAG, "AudioTrack playback error, will attempt MediaPlayer fallback", e)
            try {
                track?.stop()
                track?.release()
            } catch (_: Exception) {}
            currentAudioTrack = null
            return@withContext false
        }
    }

    /**
     * Secondary fallback playback using MediaPlayer with direct FileDescriptor to avoid EACCES issues.
     */
    private suspend fun playWithMediaPlayer(file: File): Boolean = withContext(Dispatchers.Main) {
        if (isPlaybackCancelled || !file.exists()) return@withContext false

        suspendCancellableCoroutine { cont ->
            try {
                stopMediaPlayerOnly()

                val mp = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    // Use FileDescriptor to guarantee process-level file access
                    FileInputStream(file).use { fis ->
                        setDataSource(fis.fd)
                    }
                    setVolume(1.0f, 1.0f)

                    setOnPreparedListener { player ->
                        if (isPlaybackCancelled) {
                            try { player.stop() } catch (_: Exception) {}
                            try { player.release() } catch (_: Exception) {}
                            mediaPlayer = null
                            if (cont.isActive) cont.resume(false)
                            return@setOnPreparedListener
                        }
                        isVoicePlaying = true
                        player.start()
                    }
                    setOnCompletionListener { player ->
                        try { player.stop() } catch (_: Exception) {}
                        try { player.release() } catch (_: Exception) {}
                        mediaPlayer = null
                        if (cont.isActive) cont.resume(true)
                    }
                    setOnErrorListener { player, what, extra ->
                        Log.w(TAG, "MediaPlayer error: $what / $extra")
                        try { player.reset() } catch (_: Exception) {}
                        try { player.release() } catch (_: Exception) {}
                        mediaPlayer = null
                        if (cont.isActive) cont.resume(false)
                        true
                    }
                }

                mediaPlayer = mp
                mp.prepareAsync()

                cont.invokeOnCancellation {
                    try {
                        mp.stop()
                        mp.release()
                    } catch (_: Exception) {}
                    mediaPlayer = null
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start MediaPlayer for file", e)
                if (cont.isActive) cont.resume(false)
            }
        }
    }

    private fun stopMediaPlayerOnly() {
        try {
            mediaPlayer?.let { mp ->
                try {
                    if (mp.isPlaying) {
                        mp.stop()
                    }
                } catch (_: Exception) {}
                try { mp.reset() } catch (_: Exception) {}
                try { mp.release() } catch (_: Exception) {}
            }
            mediaPlayer = null
        } catch (_: Exception) {}
    }

    fun stopPlayback() {
        isPlaybackCancelled = true
        isVoicePlaying = false
        try {
            currentAudioTrack?.let { track ->
                try { track.pause() } catch (_: Exception) {}
                try { track.flush() } catch (_: Exception) {}
                try { track.stop() } catch (_: Exception) {}
                try { track.release() } catch (_: Exception) {}
            }
            currentAudioTrack = null
        } catch (_: Exception) {}
        stopMediaPlayerOnly()
    }

    fun isSpeaking(): Boolean = isVoicePlaying

    private fun isWavFile(bytes: ByteArray): Boolean {
        if (bytes.size < 4) return false
        return bytes[0] == 'R'.code.toByte() && bytes[1] == 'I'.code.toByte() &&
                bytes[2] == 'F'.code.toByte() && bytes[3] == 'F'.code.toByte()
    }

    /**
     * Converts raw 16-bit PCM bytes to standard 44-byte header WAV file.
     */
    private fun pcmToWav(pcmData: ByteArray, sampleRate: Int = 24000, channels: Int = 1, bitsPerSample: Int = 16): ByteArray {
        val totalAudioLen = pcmData.size
        val totalDataLen = totalAudioLen + 36
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val header = ByteArray(44)

        // RIFF header
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = ((totalDataLen shr 8) and 0xff).toByte()
        header[6] = ((totalDataLen shr 16) and 0xff).toByte()
        header[7] = ((totalDataLen shr 24) and 0xff).toByte()

        // WAVE
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()

        // fmt chunk
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte()
        header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = (channels * bitsPerSample / 8).toByte()
        header[33] = 0
        header[34] = bitsPerSample.toByte()
        header[35] = 0

        // data chunk
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalAudioLen and 0xff).toByte()
        header[41] = ((totalAudioLen shr 8) and 0xff).toByte()
        header[42] = ((totalAudioLen shr 16) and 0xff).toByte()
        header[43] = ((totalAudioLen shr 24) and 0xff).toByte()

        return header + pcmData
    }
}
