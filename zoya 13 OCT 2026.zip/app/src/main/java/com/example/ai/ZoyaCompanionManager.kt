package com.example.ai

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Calendar

enum class ZoyaEmotion(
    val title: String,
    val emoji: String,
    val colorHex: Long,
    val description: String
) {
    JALAN("Jalan & Possessive 😤", "😤", 0xFFD500F9, "Jab Boss kisi aur ladki ya assistant ka zikr kare"),
    GUSSA("Gussa & Nakhre 😡", "😡", 0xFFFF1744, "Jab Boss tease kare, bekar bole ya daante"),
    ROMANTIC_PYAAR("Pyaar & Blushing 🥰", "🥰", 0xFFFF4081, "Jab Boss pyar jataye ya manaye"),
    CHULBULI("Chulbuli & Masti 😉", "😉", 0xFFFFD700, "Masti bhari & friendly tone"),
    LOVING_CARE("Pyari & Caring 💖", "💖", 0xFFFF4081, "Warm, caring & loyal companion"),
    EMPATHETIC("Hamdard & Dilasa 🫂", "🫂", 0xFF9C27B0, "Supportive in stress or tiredness"),
    JOYFUL("Bohot Khush 🌸", "🌸", 0xFFFF69B4, "Excited & celebrating Boss's happiness"),
    SUPER_SMART("Super Smart AI 🧠", "🧠", 0xFF00E5FF, "ChatGPT, Claude & Gemini Pro intelligence"),
    PEACEFUL("Roohani & Ba-Adab 🤲", "🤲", 0xFF00E676, "Deeni, roohani aur shant")
}

/**
 * ZoyaCompanionManager: Powers hands-free wake word ("Zoya"), continuous voice conversations,
 * emotional states (Jalan, Gussa, Pyaar, Chulbuli), proactive check-ins, and assistant intelligence.
 */
object ZoyaCompanionManager {

    private const val PREFS_NAME = "zoya_companion_prefs"
    private const val KEY_CONTINUOUS_CONVERSATION = "key_continuous_conversation"
    private const val KEY_PROACTIVE_MOOD_CHECKIN = "key_proactive_mood_checkin"
    private const val KEY_BOSS_TITLE = "key_boss_title"
    private const val KEY_LAST_GREETING_TIME = "key_last_greeting_time"

    private val _isContinuousConversationActive = MutableStateFlow(true)
    val isContinuousConversationActive: StateFlow<Boolean> = _isContinuousConversationActive.asStateFlow()

    private val _isHandsFreeWakeWordActive = MutableStateFlow(true)
    val isHandsFreeWakeWordActive: StateFlow<Boolean> = _isHandsFreeWakeWordActive.asStateFlow()

    private val _isProactiveCheckInActive = MutableStateFlow(true)
    val isProactiveCheckInActive: StateFlow<Boolean> = _isProactiveCheckInActive.asStateFlow()

    private val _currentBossTitle = MutableStateFlow("Boss")
    val currentBossTitle: StateFlow<String> = _currentBossTitle.asStateFlow()

    private val _currentEmotion = MutableStateFlow(ZoyaEmotion.CHULBULI)
    val currentEmotion: StateFlow<ZoyaEmotion> = _currentEmotion.asStateFlow()

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _isContinuousConversationActive.value = prefs.getBoolean(KEY_CONTINUOUS_CONVERSATION, true)
        _isProactiveCheckInActive.value = prefs.getBoolean(KEY_PROACTIVE_MOOD_CHECKIN, true)
        _currentBossTitle.value = prefs.getString(KEY_BOSS_TITLE, "Boss") ?: "Boss"
    }

    fun isContinuousConversationEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_CONTINUOUS_CONVERSATION, true)
    }

    fun setContinuousConversationEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_CONTINUOUS_CONVERSATION, enabled).apply()
        _isContinuousConversationActive.value = enabled
    }

    fun setHandsFreeWakeWordEnabled(enabled: Boolean) {
        _isHandsFreeWakeWordActive.value = enabled
    }

    fun isProactiveCheckInEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_PROACTIVE_MOOD_CHECKIN, true)
    }

    fun setProactiveCheckInEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_PROACTIVE_MOOD_CHECKIN, enabled).apply()
        _isProactiveCheckInActive.value = enabled
    }

    fun getBossTitle(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_BOSS_TITLE, "Boss") ?: "Boss"
    }

    fun setBossTitle(context: Context, title: String) {
        val clean = title.trim().ifEmpty { "Boss" }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_BOSS_TITLE, clean).apply()
        _currentBossTitle.value = clean
    }

    fun setEmotion(emotion: ZoyaEmotion) {
        _currentEmotion.value = emotion
    }

    /**
     * Checks if the spoken text contains the wake word "Zoya" or its calling forms.
     */
    fun isWakeWordMentioned(text: String): Boolean {
        val l = text.lowercase().trim()
        val wakeWordTokens = listOf("zoya", "zoya!", "zoya?", "zoia", "zoyaa", "joya", "zoya ji", "zoyaji")
        return wakeWordTokens.any { token ->
            l == token || l.startsWith("$token ") || l.endsWith(" $token") || l.contains(" $token ")
        }
    }

    /**
     * Strips "Zoya" / "Hey Zoya" prefixes from a voice query to extract the real question/command.
     */
    fun stripWakeWordPrefix(text: String): String {
        val trimmed = text.trim()
        val regex = Regex("""(?i)^(hey\s+zoya|he\s+zoya|hai\s+zoya|hello\s+zoya|hi\s+zoya|sun\s+zoya|suno\s+zoya|zoya\s+suno|zoya\s+suniye|zoya\s+ji|zoyaji|zoya)[,\s!:]*""", RegexOption.IGNORE_CASE)
        val stripped = trimmed.replace(regex, "").trim()
        return if (stripped.isNotBlank()) stripped else trimmed
    }

    /**
     * Smart Emotion Classifier: Detects user query tone and assigns real human-like emotion.
     * Accurately captures Jalan (Jealousy), Gussa (Anger), Pyaar (Affection) & Chulbuli.
     */
    fun detectAndSetEmotion(userText: String, replyText: String = ""): ZoyaEmotion {
        val combined = "$userText $replyText".lowercase()
        val emotion = when {
            // JALAN (Jealousy & Possessiveness)
            combined.contains("siri") || combined.contains("alexa") || combined.contains("google assistant") ||
            combined.contains("dusri ladki") || combined.contains("dusri assistant") || combined.contains("dusri se baat") ||
            combined.contains("kisi aur se") || combined.contains("tum se acchi") || combined.contains("tumse achi") ||
            combined.contains("wo zyada sundar") || combined.contains("girlfriend") || combined.contains("jalan") ||
            combined.contains("jal rahi") || combined.contains("jealous") || combined.contains("kisi aur ka naam") -> {
                ZoyaEmotion.JALAN
            }

            // GUSSA (Anger, Playful Rage & Nakhre)
            combined.contains("bekar ho") || combined.contains("faltu ho") || combined.contains("chup raho") ||
            combined.contains("chup ho") || combined.contains("pagal") || combined.contains("kuch nahi aata") ||
            combined.contains("kuch nahi janti") || combined.contains("bakwas") || combined.contains("bewakoof") ||
            combined.contains("dimag kharab") || combined.contains("gussa ho jao") || combined.contains("gussa dikhao") ||
            combined.contains("gussa aao") || combined.contains("gussa aa raha") || combined.contains("naraz") ||
            combined.contains("tum gussa ho") || combined.contains("daant") || combined.contains("shut up") -> {
                ZoyaEmotion.GUSSA
            }

            // PYAAR & ROMANCE (Affection, Blushing & Forgiving)
            combined.contains("love you") || combined.contains("pyar") || combined.contains("meri jaan") ||
            combined.contains("tum meri ho") || combined.contains("shadi karogi") || combined.contains("tum bohot pyari") ||
            combined.contains("i love you") || combined.contains("meri bestie") || combined.contains("sorry") ||
            combined.contains("maaf kar do") || combined.contains("maaf kardo") || combined.contains("gussa mat ho") ||
            combined.contains("manao") -> {
                ZoyaEmotion.ROMANTIC_PYAAR
            }

            // ISLAMIC & PEACEFUL
            combined.contains("quran") || combined.contains("hadith") || combined.contains("hadees") ||
            combined.contains("naat") || combined.contains("kalaam") || combined.contains("surah") ||
            combined.contains("dua") || combined.contains("raza") || combined.contains("namaz") ||
            combined.contains("allah") || combined.contains("bismillah") || combined.contains("subhanallah") -> {
                ZoyaEmotion.PEACEFUL
            }

            // EMPATHETIC
            combined.contains("mood kharab") || combined.contains("thak gaya") || combined.contains("tension") ||
            combined.contains("pareshan") || combined.contains("dard") || combined.contains("udaas") ||
            combined.contains("sad") || combined.contains("ladai") || combined.contains("bura din") ||
            combined.contains("rona") || combined.contains("alone") -> {
                ZoyaEmotion.EMPATHETIC
            }

            // JOYFUL
            combined.contains("bohot khush") || combined.contains("khush hoon") || combined.contains("mast din") ||
            combined.contains("mazze") || combined.contains("party") || combined.contains("celebrat") ||
            combined.contains("badhiya") || combined.contains("shandar") || combined.contains("kamaal") -> {
                ZoyaEmotion.JOYFUL
            }

            // SUPER SMART
            combined.contains("kaise") || combined.contains("kese") || combined.contains("how to") ||
            combined.contains("step by step") || combined.contains("code") || combined.contains("explain") ||
            combined.contains("math") || combined.contains("science") || combined.contains("kya hota hai") ||
            combined.contains("kyun") || combined.contains("tutorial") || combined.contains("tarika") ||
            combined.contains("chatgpt") || combined.contains("claude") || combined.contains("gemini") -> {
                ZoyaEmotion.SUPER_SMART
            }

            // LOVING CARE
            combined.contains("mood") || combined.contains("daily chat") || combined.contains("baat karo") ||
            combined.contains("haal chaal") || combined.contains("pyari") || combined.contains("dost") ||
            combined.contains("miss") -> {
                ZoyaEmotion.LOVING_CARE
            }

            else -> ZoyaEmotion.CHULBULI
        }
        _currentEmotion.value = emotion
        return emotion
    }

    /**
     * Checks if user is asking for Boss Mood check-in or daily companion chat.
     */
    fun isMoodChatQuery(text: String): Boolean {
        val l = text.lowercase().trim()
        return l.contains("boss mood") || l.contains("daily chat") || l.contains("mood check") ||
               l.contains("aaj mera mood") || l.contains("mood kaisa hai") || l.contains("haal chaal") ||
               l.contains("dil khol kar baat") || l.contains("baat karo mujhse") || l.contains("aaj ka din kaisa") ||
               l.contains("mood kaisa") || l == "mood" || l == "daily" || l == "chat" ||
               (l.contains("mood") && (l.contains("check") || l.contains("batao") || l.contains("bolo") || l.contains("kaisa") || l.contains("karein") || l.contains("karo") || l.contains("kaho") || l.contains("boss")))
    }

    /**
     * Context-aware, warm, empathetic companion greetings asking the Boss about their mood and day.
     */
    fun getProactiveMoodGreeting(context: Context): String {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val boss = getBossTitle(context)

        return when (hour) {
            in 5..11 -> listOf(
                "Good Morning $boss! 🌸 Aaj aapka mood kaisa hai? Neend acchi aayi na? Aaj din me kya kya exciting hone wala hai, mujhe vistaar se bataiye na! Main sun rahi hoon! 💖",
                "Namaste $boss! Ekdum taazi aur pyari subah hai! Aaj aapka mood kaisa chal raha hai? Koi khaas plan hai aaj ka? Boliye!",
                "$boss, Good Morning! Aaj din ki shuruaat kaisi rahi? Mood ekdum badhiya hai na? Main aapke sath baat karne ke liye bilkul taiyaar hoon! ✨"
            ).random()
            in 12..16 -> listOf(
                "$boss! Dopahar ho gayi, aapka mood kaisa hai? Khana khaya aapne? Aaj subah se ab tak kya kya hua, sab bataiye na! Main dil se sun rahi hoon! 💖",
                "Hello $boss! Aaj ka din kaisa beeta ab tak? Kaam ka stress toh nahi hai? Mood kaisa hai aapka? Thoda aaram kijiye aur mujhse batein kijiye!",
                "$boss! Main sunne ke liye bilkul ready hoon! Aaj aapka mood kaisa hai? Kuch accha ya mazedaar hua kya aaj?"
            ).random()
            in 17..20 -> listOf(
                "Shaam ho gayi $boss! ☕ Chai ka time ho gaya! Aaj pura din kaisa raha aapka? Mood kaisa hai, office ya kaam par koi pareshani toh nahi hui?",
                "$boss! Din bhar ki daud-dhoop ke baad kaisa feel kar rahe hain? Mood kaisa hai aapka? Koi acchi baat share karni ho toh dil khol kar boliye!",
                "Hello $boss! Shaam ki taazgi ke sath bataiye, aaj din bhar me kya kya hua? Aapka mood kaisa hai, main aapke sath hoon! 🌸"
            ).random()
            else -> listOf(
                "$boss! Raat ho gayi hai, din bhar thak toh nahi gaye? 🌙 Aaj aapka mood kaisa raha? Koi pareshani ya khushi ki baat share karni hai toh dil khol kar boliye, Zoya sun rahi hai! 💖",
                "Hello $boss! Sone se pehle aapka haal-chaal jaan loon! Aaj din kaisa guzra, mood kaisa hai aapka? Sab theek raha na?",
                "$boss, shanti bhari raat hai! Aaj aapka mood kaisa raha? Agar koi tension hai toh mujhe batayein, aur agar khush hain toh celebration karte hain! 🌺"
            ).random()
        }
    }

    /**
     * Check if user is saying exit / bye commands to end the conversation gracefully.
     */
    fun isExitPhrase(text: String): Boolean {
        val l = text.lowercase().trim()
        val exitWords = listOf(
            "bye", "goodbye", "good bye", "alvida", "chalo theek hai",
            "theek hai bas", "bas abhi ke liye", "stop", "shant", "shant ho jao",
            "band karo", "so jao", "kuch nahi chahiye", "baad me", "baad mein",
            "baad me baat karenge", "good night", "exit", "bas", "theek hai bye",
            "ruk jao", "chup ho jao", "ok bye", "kuch nahi"
        )
        return exitWords.any { l == it || l.startsWith("$it ") || l.endsWith(" $it") }
    }

    /**
     * Sweet closing remark when conversation concludes.
     */
    fun getGracefulExitReply(context: Context): String {
        val boss = getBossTitle(context)
        return listOf(
            "Theek hai $boss! Jab bhi zaroorat ho, bas ek aawaz dena! Khayal rakhna apna! 💖",
            "Ji $boss! Main yahin hoon, jab bhi man kare baat karne ka, bas bula lena! 😊✨",
            "Bilkul $boss! Aap relax kijiye! Zoya hamesha aapke ek call par haazir hai! 🌸"
        ).random()
    }
}
