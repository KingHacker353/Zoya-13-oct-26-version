package com.example.ai

import android.net.Uri

object AiStudioAutomationHelper {

    const val AI_STUDIO_BUILD_URL = "https://aistudio.google.com/build"
    const val AI_STUDIO_NEW_APP_URL = "https://aistudio.google.com/build"
    const val AI_STUDIO_HOME_URL = "https://aistudio.google.com/"
    const val AI_STUDIO_NEW_CHAT_URL = "https://aistudio.google.com/build" // Redirect old chat references to Build mode!

    // Desktop mode User Agent: Ensures Google AI Studio renders full desktop IDE with file explorer and live build preview
    const val DESKTOP_USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    const val MOBILE_USER_AGENT = "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    /**
     * Checks if the user prompt is requesting to build/create a website, app, or software,
     * or specifically requesting Google AI Studio automation.
     */
    fun isAppOrWebsiteCreationQuery(text: String): Boolean {
        val lower = text.lowercase().trim()

        // Explicit AI Studio mentions
        if (lower.contains("ai studio") || lower.contains("google ai") || lower.contains("aistudio")) {
            return true
        }

        // Action keywords (create / build / make / develop)
        val hasBuildIntent = lower.contains("banao") || lower.contains("bana do") || lower.contains("bana de") ||
                lower.contains("bana k") || lower.contains("banaye") || lower.contains("banane") ||
                lower.contains("create") || lower.contains("build") || lower.contains("develop") ||
                lower.contains("design") || lower.contains("generate") || lower.contains("chahiye") ||
                lower.contains("tayyar karo") || lower.contains("ready karo")

        // Subject keywords (website, web app, android app, application)
        val hasAppOrWebsite = lower.contains("website") || lower.contains("web app") || lower.contains("webpage") ||
                lower.contains("app") || lower.contains("application") || lower.contains("software") ||
                lower.contains("apk") || lower.contains("project") || lower.contains("portal") ||
                lower.contains("system")

        if (hasBuildIntent && hasAppOrWebsite) {
            return true
        }

        // Specific app/website categories + build intent
        val specificCategories = listOf(
            "shopping", "ecommerce", "food delivery", "calculator", "portfolio",
            "chat", "todo", "weather", "music player", "social media", "blog",
            "hotel booking", "restaurant", "fitness", "quiz", "game"
        )
        if (hasBuildIntent && specificCategories.any { lower.contains(it) }) {
            return true
        }

        return false
    }

    /**
     * Extracts a clean project name and determines whether it's an App or a Website.
     */
    fun extractProjectNameAndType(query: String): Pair<String, String> {
        val lower = query.lowercase().trim()
        val isWebsite = lower.contains("website") || lower.contains("web page") || lower.contains("web app") || lower.contains("portal")
        val appType = if (isWebsite) "Website" else "Application"

        val clean = query.replace(Regex("""(?i)\b(zoya|google|ai|studio|open|karke|kholo|aur|se|me|ek|koi|bhi|mujhe|mera|meri|apna|banao|bana do|bana de|banaye|banane|create|build|develop|generate|app|application|website|web app|apk|chahiye|direct|khud|prompt|touch|click|automation)\b"""), " ")
            .trim()
            .replace(Regex("""\s+"""), " ")

        val projectName = when {
            clean.isNotBlank() && clean.length > 2 -> {
                clean.split(" ").joinToString(" ") { word ->
                    word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                }
            }
            lower.contains("shopping") || lower.contains("store") || lower.contains("ecommerce") -> "E-Commerce Shopping $appType"
            lower.contains("food") || lower.contains("restaurant") || lower.contains("biryani") || lower.contains("pizza") -> "Food Delivery $appType"
            lower.contains("calculator") || lower.contains("hisab") -> "Smart Modern Calculator $appType"
            lower.contains("portfolio") || lower.contains("resume") || lower.contains("cv") -> "Developer Portfolio $appType"
            lower.contains("chat") || lower.contains("messaging") -> "Real-time Messaging & Chat $appType"
            lower.contains("fitness") || lower.contains("workout") || lower.contains("gym") -> "Fitness & Workout Tracker $appType"
            lower.contains("todo") || lower.contains("task") || lower.contains("notes") -> "Task & Project Manager $appType"
            lower.contains("weather") || lower.contains("mausam") -> "Live Weather Forecast $appType"
            lower.contains("travel") || lower.contains("booking") || lower.contains("ticket") -> "Travel & Hotel Booking $appType"
            else -> "Super $appType"
        }

        return Pair(projectName, appType)
    }

    /**
     * Crafts a comprehensive, high-calibre developer prompt for Google AI Studio.
     * This instructs the AI to generate a complete, working, production-ready implementation.
     */
    fun generateAiStudioPrompt(query: String, projectName: String, projectType: String): String {
        val isWebsite = projectType.equals("Website", ignoreCase = true)
        val techStack = if (isWebsite) {
            "Next.js 14 / React with TypeScript, Tailwind CSS, Lucide Icons, and responsive design"
        } else {
            "Modern Android with Kotlin, Jetpack Compose, Material 3, ViewModel, and Coroutines"
        }

        return buildString {
            append("Act as a World-Class Principal Software Engineer. ")
            append("Build a complete, fully functional, production-ready $projectName ($projectType). ")
            append("\n\nUser Goal / Brief: $query ")
            append("\n\nPrimary Tech Stack: $techStack. ")
            append("\n\nArchitecture & Key Requirements:")
            append("\n1. Visual & UX Excellence: Modern Material 3 / Sleek Dark & Light design, generous spacing, smooth micro-animations, accessible contrast, and mobile-first responsiveness.")
            append("\n2. Core Features & CUJs: Implement all essential user flows, state management, search/filter, detail views, and interactive components.")
            append("\n3. Zero Placeholders: Provide complete, runnable code with zero comments like '// implement here' or '// todo'. Every button, form, and screen must work.")
            append("\n4. Clean Code Standards: Strict modular structure, clean architecture, typed models, and production-grade error handling.")
            append("\n\nPlease generate the full implementation now, ready to compile and run!")
        }.trim()
    }

    /**
     * Builds the JavaScript string executed inside WebView for Google AI Studio automation.
     * It ensures we are in 'New App' / Build Mode (NOT Playground chat), navigates to New App if needed,
     * locates the 'Describe the app you want to build' prompt field, injects the complete developer prompt,
     * triggers native React/Angular events, and clicks the Build / Create / Run button without requiring any touch or click!
     */
    fun getAiStudioAutomationJs(promptText: String): String {
        val escapedPrompt = promptText
            .replace("\\", "\\\\")
            .replace("`", "\\`")
            .replace("$", "\\$")
            .replace("'", "\\'")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "")

        return """
            (function() {
                console.log("[Zoya AI Studio Automation] Script started for New App Build...");
                const targetPrompt = "$escapedPrompt";
                let pollCount = 0;
                const maxPoll = 45; // up to 22.5 seconds maximum polling for async components

                // If currently trapped in Playground chat (/prompts), redirect straight to Build / New App!
                if (window.location.pathname.includes('/prompts') && !window.location.pathname.includes('/build')) {
                    console.log("[Zoya AI Studio] Currently in Playground chat! Redirecting to Build Mode (/build)...");
                    window.location.href = 'https://aistudio.google.com/build';
                    return 'REDIRECTED_FROM_PLAYGROUND_TO_BUILD';
                }

                function tryClickNewAppButton() {
                    const clickCandidates = Array.from(document.querySelectorAll('button, a, div[role="button"], mat-list-item, [role="tab"], .mat-mdc-button-base'));
                    for (const el of clickCandidates) {
                        if (el.offsetParent === null) continue;
                        const text = (el.innerText || el.textContent || el.getAttribute('aria-label') || '').toLowerCase().trim();
                        const href = (el.getAttribute('href') || '').toLowerCase();
                        if (text.includes('new app') || text.includes('create app') || text.includes('build an app') || text === '+ new app' || href.includes('/build') || href.includes('/apps/new')) {
                            console.log("[Zoya AI Studio] Found 'New App' button, clicking: ", el);
                            el.click();
                            return true;
                        }
                    }
                    return false;
                }

                function injectAndRun() {
                    pollCount++;

                    // Check if user is on Google Sign-In redirect
                    if (window.location.hostname.includes('accounts.google.com')) {
                        console.log("[Zoya AI Studio] On Google accounts login page");
                        return 'STATUS_LOGIN_REQUIRED';
                    }

                    // Candidate selectors for Google AI Studio Build Mode / New App prompt input:
                    // Specifically targeting 'Describe the app you want to build' and Build mode elements
                    const selectors = [
                        'textarea[placeholder*="describe" i]',
                        'textarea[placeholder*="app" i]',
                        'textarea[placeholder*="build" i]',
                        'textarea[placeholder*="want to build" i]',
                        'textarea[placeholder*="what do you want" i]',
                        'textarea[placeholder*="prompt" i]',
                        'textarea[aria-label*="describe" i]',
                        'textarea[aria-label*="app" i]',
                        'textarea[aria-label*="prompt" i]',
                        'textarea.build-prompt',
                        'textarea.chat-input',
                        'textarea',
                        'input[type="text"][placeholder*="describe" i]',
                        'input[type="text"][placeholder*="app" i]',
                        'input[type="text"][placeholder*="build" i]',
                        'div[contenteditable="true"]',
                        'div[role="textbox"]',
                        'ms-autosize-textarea textarea',
                        'ms-prompt-input textarea',
                        '.ql-editor'
                    ];

                    let inputEl = null;
                    for (const sel of selectors) {
                        const elements = Array.from(document.querySelectorAll(sel));
                        for (const el of elements) {
                            if (el.offsetParent !== null && !el.disabled) {
                                inputEl = el;
                                break;
                            }
                        }
                        if (inputEl) break;
                    }

                    // If input element not yet present, check if we need to click "+ New App" or "Build" first!
                    if (!inputEl) {
                        const clicked = tryClickNewAppButton();
                        if (clicked) {
                            console.log("[Zoya AI Studio] Clicked New App button, polling for builder prompt box...");
                        }
                    }

                    if (inputEl) {
                        console.log("[Zoya AI Studio] Build Prompt input found: ", inputEl);
                        inputEl.focus();

                        // Highlight the box with a high-visibility cyberpunk outline
                        try {
                            inputEl.style.outline = '3px solid #00f5d4';
                            inputEl.style.boxShadow = '0 0 20px rgba(0, 245, 212, 0.7)';
                        } catch(e) {}

                        if (inputEl.tagName.toLowerCase() === 'textarea' || inputEl.tagName.toLowerCase() === 'input') {
                            inputEl.value = targetPrompt;
                        } else if (inputEl.isContentEditable) {
                            inputEl.innerText = targetPrompt;
                        } else {
                            inputEl.textContent = targetPrompt;
                        }

                        // Fire native input, change, and key events
                        inputEl.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
                        inputEl.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));

                        // Try calling React/Angular internal prototype setters
                        try {
                            const proto = window.HTMLTextAreaElement ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
                            const nativeInputValueSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
                            if (nativeInputValueSetter) {
                                nativeInputValueSetter.call(inputEl, targetPrompt);
                                inputEl.dispatchEvent(new Event('input', { bubbles: true }));
                            }
                        } catch(e) {}

                        // After short delay, click the Build / Create / Generate / Run button
                        setTimeout(function() {
                            const btnSelectors = [
                                'button[aria-label*="Build" i]',
                                'button[aria-label*="Create" i]',
                                'button[aria-label*="Generate" i]',
                                'button[aria-label*="Run" i]',
                                'button[aria-label*="Submit" i]',
                                'button[aria-label*="Send" i]',
                                'button.build-button',
                                'button.create-button',
                                'button.run-button',
                                'button.send-button',
                                'button[type="submit"]',
                                'ms-run-button button',
                                'button.mat-primary',
                                'button'
                            ];

                            let runBtn = null;
                            for (const bSel of btnSelectors) {
                                const btns = Array.from(document.querySelectorAll(bSel));
                                for (const b of btns) {
                                    if (b.offsetParent === null || b.disabled) continue;
                                    const text = (b.innerText || b.textContent || b.getAttribute('aria-label') || '').toLowerCase();
                                    if (text.includes('build') || text.includes('create') || text.includes('generate') || text.includes('start') || text.includes('run') || text.includes('submit')) {
                                        runBtn = b;
                                        break;
                                    }
                                }
                                if (runBtn) break;
                            }

                            if (runBtn) {
                                console.log("[Zoya AI Studio] Clicking Build button: ", runBtn);
                                runBtn.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                runBtn.click();
                                window._zoya_build_started = true;
                            } else {
                                console.log("[Zoya AI Studio] Simulating Enter / Ctrl+Enter on prompt box...");
                                const enterEvent = new KeyboardEvent('keydown', {
                                    key: 'Enter',
                                    code: 'Enter',
                                    keyCode: 13,
                                    which: 13,
                                    ctrlKey: true,
                                    bubbles: true
                                });
                                inputEl.dispatchEvent(enterEvent);
                                const enterUpEvent = new KeyboardEvent('keyup', {
                                    key: 'Enter',
                                    code: 'Enter',
                                    keyCode: 13,
                                    which: 13,
                                    ctrlKey: true,
                                    bubbles: true
                                });
                                inputEl.dispatchEvent(enterUpEvent);
                                window._zoya_build_started = true;
                            }
                        }, 600);

                        return 'SUCCESS_PROMPT_INJECTED_AND_RUN';
                    }

                    if (pollCount < maxPoll) {
                        setTimeout(injectAndRun, 500);
                        return 'POLLING';
                    }

                    return 'INPUT_NOT_FOUND';
                }

                return injectAndRun();
            })();
        """.trimIndent()
    }

    /**
     * JavaScript to monitor live Google AI Studio app building state:
     * - Detects when build starts (files generating, progress spinner, thinking indicator)
     * - Detects any errors (quota, rate limits, failures, error alerts)
     * - Detects when the application is completed (preview iframe ready, build finished)
     */
    fun getAiStudioStatusCheckJs(): String {
        return """
            (function() {
                try {
                    if (!window.location.hostname.includes('aistudio.google.com')) {
                        return JSON.stringify({ status: 'NOT_AISTUDIO' });
                    }

                    // 1. Check for Login Required
                    if (window.location.hostname.includes('accounts.google.com')) {
                        return JSON.stringify({ status: 'LOGIN_REQUIRED' });
                    }

                    // 2. Check for Visible Errors
                    const errorSelectors = [
                        'div[role="alert"]',
                        'mat-snack-bar-container',
                        '.error-message',
                        '.toast-error',
                        '[class*="error-banner" i]',
                        '[class*="error-message" i]',
                        '[class*="snackbar" i]',
                        '.mat-mdc-snack-bar-container',
                        '[role="status"]'
                    ];
                    for (const sel of errorSelectors) {
                        const els = Array.from(document.querySelectorAll(sel));
                        for (const el of els) {
                            if (el.offsetParent === null) continue;
                            const text = (el.innerText || el.textContent || '').trim();
                            if (text.length > 5) {
                                const lower = text.toLowerCase();
                                if (lower.includes('quota') || lower.includes('rate limit') || lower.includes('failed') ||
                                    lower.includes('error') || lower.includes('unable') || lower.includes('something went wrong') ||
                                    lower.includes('resource exhausted') || lower.includes('cannot complete')) {
                                    return JSON.stringify({ status: 'ERROR', message: text.substring(0, 150) });
                                }
                            }
                        }
                    }

                    const bodyText = document.body ? document.body.innerText.toLowerCase() : '';
                    if (bodyText.includes('quota exceeded') || bodyText.includes('resource exhausted') || bodyText.includes('too many requests')) {
                        return JSON.stringify({ status: 'ERROR', message: 'Quota / Rate limit exceeded' });
                    }
                    if (bodyText.includes('failed to generate') || bodyText.includes('build failed') || bodyText.includes('error compiling')) {
                        return JSON.stringify({ status: 'ERROR', message: 'Application build me error aayi hai' });
                    }

                    // 3. Check for Active Building / Generating (START / IN PROGRESS)
                    const hasSpinner = !!document.querySelector('mat-progress-spinner, mat-progress-bar, [role="progressbar"], .building-indicator, .generating-spinner, [class*="spinner" i], svg.animate-spin');
                    const hasStopBtn = !!document.querySelector('button[aria-label*="Stop" i], button[aria-label*="Cancel" i]');
                    const hasGeneratingText = Array.from(document.querySelectorAll('button, span, div, p, mat-chip')).some(el => {
                        if (el.offsetParent === null) return false;
                        const t = (el.innerText || '').toLowerCase().trim();
                        return (t.includes('generating') || t.includes('building app') || t.includes('building...') ||
                                t.includes('writing code') || t.includes('analyzing') || t.includes('planning') ||
                                t.includes('compiling') || t.includes('installing') || t.includes('thinking')) && t.length < 60;
                    });

                    const isGenerating = hasSpinner || hasStopBtn || hasGeneratingText;

                    // 4. Check for Completion (BAN GAYI / PREVIEW READY)
                    const hasPreviewIframe = !!(
                        document.querySelector('iframe[src*="preview" i], iframe[title*="preview" i], .preview-container iframe, iframe[src*="run.app"], device-frame, .device-preview, .app-preview iframe') ||
                        (document.querySelectorAll('iframe').length > 0 && Array.from(document.querySelectorAll('iframe')).some(f => f.offsetWidth > 100 && f.offsetHeight > 100))
                    );

                    const hasCompletionText = Array.from(document.querySelectorAll('button, [role="tab"], div, span, h2, h3')).some(el => {
                        if (el.offsetParent === null) return false;
                        const t = (el.innerText || '').toLowerCase().trim();
                        return t === 'preview' || t.includes('live preview') || t === 'app ready' ||
                               t.includes('build succeeded') || t.includes('build complete') || t.includes('ready to view') ||
                               t.includes('app running');
                    });

                    const hasGeneratedFiles = !!(
                        document.querySelector('[class*="file-tree" i], [class*="file-list" i], [class*="workspace-files" i], [class*="file-explorer" i]') ||
                        Array.from(document.querySelectorAll('[class*="file" i], [role="treeitem"]')).some(el => {
                            const t = (el.innerText || '').toLowerCase();
                            return t.endsWith('.kt') || t.endsWith('.tsx') || t.endsWith('.jsx') || t.endsWith('.html') || t.endsWith('.json') || t.endsWith('.css');
                        })
                    );

                    if (isGenerating) {
                        window._zoya_build_started = true;
                        return JSON.stringify({ status: 'BUILDING', hasFiles: hasGeneratedFiles });
                    }

                    if ((hasPreviewIframe || hasCompletionText) && (window._zoya_build_started || hasGeneratedFiles)) {
                        return JSON.stringify({ status: 'COMPLETED', hasPreview: true, hasFiles: hasGeneratedFiles });
                    }

                    if (window._zoya_build_started && hasGeneratedFiles && !isGenerating) {
                        return JSON.stringify({ status: 'COMPLETED', hasPreview: hasPreviewIframe, hasFiles: true });
                    }

                    return JSON.stringify({
                        status: window._zoya_build_started ? 'BUILDING' : 'IDLE',
                        hasPreview: hasPreviewIframe,
                        hasFiles: hasGeneratedFiles,
                        buildStarted: !!window._zoya_build_started
                    });
                } catch(e) {
                    return JSON.stringify({ status: 'ERROR', message: e.message });
                }
            })();
        """.trimIndent()
    }

    /**
     * Injects a desktop viewport meta tag to force the page to render at desktop resolution (1280px)
     * so that the full Google AI Studio workspace (sidebar, code files, and preview screen) is visible.
     */
    fun getForceDesktopViewportJs(): String {
        return """
            (function() {
                try {
                    let meta = document.querySelector('meta[name="viewport"]');
                    if (!meta) {
                        meta = document.createElement('meta');
                        meta.name = 'viewport';
                        document.head.appendChild(meta);
                    }
                    meta.setAttribute('content', 'width=1280, initial-scale=0.6, maximum-scale=3.0, user-scalable=yes');
                    if (document.body) {
                        document.body.style.minWidth = '1280px';
                    }
                    if (document.documentElement) {
                        document.documentElement.style.minWidth = '1280px';
                    }
                    console.log("[Zoya AI Studio] Forced desktop viewport 1280px applied.");
                    return 'DESKTOP_VIEWPORT_APPLIED';
                } catch(e) {
                    return 'ERROR: ' + e.message;
                }
            })();
        """.trimIndent()
    }

    /**
     * Builds JavaScript to explicitly navigate or click 'New App' / Build mode in AI Studio.
     */
    fun getNavigateToNewAppJs(): String {
        return """
            (function() {
                const clickCandidates = Array.from(document.querySelectorAll('button, a, div[role="button"], mat-list-item, [role="tab"], .mat-mdc-button-base'));
                for (const el of clickCandidates) {
                    if (el.offsetParent === null) continue;
                    const text = (el.innerText || el.textContent || el.getAttribute('aria-label') || '').toLowerCase().trim();
                    const href = (el.getAttribute('href') || '').toLowerCase();
                    if (text.includes('new app') || text.includes('create app') || text.includes('build an app') || text === '+ new app' || href.includes('/build') || href.includes('/apps/new')) {
                        el.click();
                        return 'CLICKED_NEW_APP';
                    }
                }
                window.location.href = 'https://aistudio.google.com/build';
                return 'NAVIGATED_TO_BUILD';
            })();
        """.trimIndent()
    }
}
