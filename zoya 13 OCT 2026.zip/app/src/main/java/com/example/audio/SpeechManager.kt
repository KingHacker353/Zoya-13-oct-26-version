package com.example.audio

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.random.Random

data class FemaleVoiceProfile(
    val id: String,
    val name: String,
    val description: String,
    val avatarEmoji: String,
    val pitch: Float,
    val speed: Float,
    val sampleText: String,
    val systemVoiceName: String? = null,
    val isGeminiVoice: Boolean = false,
    val geminiVoiceName: String = "Aoede"
)

class SpeechManager(private val context: Context, private val coroutineScope: CoroutineScope) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _audioAmplitude = MutableStateFlow(0f)
    val audioAmplitude: StateFlow<Float> = _audioAmplitude.asStateFlow()

    private val _liveTranscript = MutableStateFlow("")
    val liveTranscript: StateFlow<String> = _liveTranscript.asStateFlow()

    // Preset Natural Human-Like Gemini AI Neural Voices (100% Gemini API Key Powered)
    val defaultFemaleVoices = listOf(
        FemaleVoiceProfile(
            id = "gemini_aoede",
            name = "Zoya Signature - Aoede ✨",
            description = "Gemini Ultra-Realistic Natural Voice (Breezy & Sweet)",
            avatarEmoji = "✨",
            pitch = 1.00f,
            speed = 1.00f,
            sampleText = "Haan ji Boss! Main Zoya hoon, Gemini AI voice se powered aapki personal voice assistant!",
            isGeminiVoice = true,
            geminiVoiceName = "Aoede"
        ),
        FemaleVoiceProfile(
            id = "gemini_kore",
            name = "Zoya Pyari Dost - Kore 💖",
            description = "Gemini Warm, Loving & Friendly Companion Voice",
            avatarEmoji = "💖",
            pitch = 1.00f,
            speed = 1.00f,
            sampleText = "Haan ji Boss! Aap jo bhi kahenge, main bade pyar se aur turant kar doongi!",
            isGeminiVoice = true,
            geminiVoiceName = "Kore"
        ),
        FemaleVoiceProfile(
            id = "gemini_leda",
            name = "Zoya Smart Pro - Leda 🌺",
            description = "Gemini Expressive, Crisp & Highly Articulate Voice",
            avatarEmoji = "🌺",
            pitch = 1.00f,
            speed = 1.00f,
            sampleText = "Namaste Boss! Phone ke saare accessibility controls aur smart features taiyaar hain.",
            isGeminiVoice = true,
            geminiVoiceName = "Leda"
        ),
        FemaleVoiceProfile(
            id = "gemini_zephyr",
            name = "Zoya Sweet Calm - Zephyr 🍃",
            description = "Gemini Soothing, Soft & Relaxed Natural Voice",
            avatarEmoji = "🍃",
            pitch = 1.00f,
            speed = 1.00f,
            sampleText = "Boss aap aaram se baat kijiye, main sab kuch acche se sambhal loongi.",
            isGeminiVoice = true,
            geminiVoiceName = "Zephyr"
        ),
        FemaleVoiceProfile(
            id = "gemini_puck",
            name = "Zoya Chulbuli - Puck ⚡",
            description = "Gemini Energetic, Playful & High-Spirited Voice",
            avatarEmoji = "⚡",
            pitch = 1.00f,
            speed = 1.00f,
            sampleText = "Hello Boss! Main aapke saare tasks bijli ki tezi se aur masti me poore kar doongi!",
            isGeminiVoice = true,
            geminiVoiceName = "Puck"
        ),
        FemaleVoiceProfile(
            id = "gemini_fenrir",
            name = "Zoya Dynamic - Fenrir 🌟",
            description = "Gemini Confident, Sharp & Distinct AI Voice",
            avatarEmoji = "🌟",
            pitch = 1.00f,
            speed = 1.00f,
            sampleText = "Haan ji Boss! Har sawal aur command ke liye main poore josh se taiyaar hoon!",
            isGeminiVoice = true,
            geminiVoiceName = "Fenrir"
        ),
        FemaleVoiceProfile(
            id = "gemini_charon",
            name = "Zoya Mentor - Charon 🎙️",
            description = "Gemini Deep, Informative & Clear AI Voice",
            avatarEmoji = "🎙️",
            pitch = 1.00f,
            speed = 1.00f,
            sampleText = "Namaste Boss! Step-by-step guidance aur detailed information ke liye haazir hoon.",
            isGeminiVoice = true,
            geminiVoiceName = "Charon"
        ),
        FemaleVoiceProfile(
            id = "gemini_orus",
            name = "Zoya Modern - Orus 💫",
            description = "Gemini Smooth, Balanced & Radiant AI Voice",
            avatarEmoji = "💫",
            pitch = 1.00f,
            speed = 1.00f,
            sampleText = "Hello Boss! Zoya ka modern AI assistant mode aapki service me active hai.",
            isGeminiVoice = true,
            geminiVoiceName = "Orus"
        )
    )

    private val _availableVoices = MutableStateFlow<List<FemaleVoiceProfile>>(defaultFemaleVoices)
    val availableVoices: StateFlow<List<FemaleVoiceProfile>> = _availableVoices.asStateFlow()

    private val _selectedVoice: MutableStateFlow<FemaleVoiceProfile>
    val selectedVoice: StateFlow<FemaleVoiceProfile>

    private var ttsAnimationJob: Job? = null

    var pitch: Float = 1.00f
    var speed: Float = 1.00f

    init {
        val savedVoiceId = com.example.data.ZoyaPreferences.getSelectedVoiceId(context)
        val initialVoice = defaultFemaleVoices.find { it.id == savedVoiceId && it.isGeminiVoice } ?: defaultFemaleVoices[0]
        _selectedVoice = MutableStateFlow(initialVoice)
        selectedVoice = _selectedVoice.asStateFlow()

        pitch = com.example.data.ZoyaPreferences.getVoicePitch(context)
        speed = com.example.data.ZoyaPreferences.getVoiceSpeed(context)

        initTts()
    }

    private var currentTtsOnComplete: (() -> Unit)? = null

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true

                val hindiLocale = Locale("hi", "IN")
                val englishIndiaLocale = Locale("en", "IN")

                val resHindi = textToSpeech?.setLanguage(hindiLocale)
                if (resHindi == TextToSpeech.LANG_MISSING_DATA || resHindi == TextToSpeech.LANG_NOT_SUPPORTED) {
                    val resEngIn = textToSpeech?.setLanguage(englishIndiaLocale)
                    if (resEngIn == TextToSpeech.LANG_MISSING_DATA || resEngIn == TextToSpeech.LANG_NOT_SUPPORTED) {
                        textToSpeech?.language = Locale.getDefault()
                    }
                }

                // Detect system voices and populate
                detectSystemVoices()
                applyVoiceProfile(_selectedVoice.value)

                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                        startTtsWaveAnimation()
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                        stopTtsWaveAnimation()
                        coroutineScope.launch(Dispatchers.Main) {
                            val cb = currentTtsOnComplete
                            currentTtsOnComplete = null
                            cb?.invoke()
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                        stopTtsWaveAnimation()
                        coroutineScope.launch(Dispatchers.Main) {
                            val cb = currentTtsOnComplete
                            currentTtsOnComplete = null
                            cb?.invoke()
                        }
                    }
                })
            }
        }
    }

    private fun detectSystemVoices() {
        // Keep strictly Gemini Neural Voices as requested by user
        _availableVoices.value = defaultFemaleVoices
    }

    fun selectVoice(profile: FemaleVoiceProfile) {
        _selectedVoice.value = profile
        pitch = profile.pitch
        speed = profile.speed
        com.example.data.ZoyaPreferences.setSelectedVoiceId(context, profile.id)
        com.example.data.ZoyaPreferences.setVoicePitch(context, profile.pitch)
        com.example.data.ZoyaPreferences.setVoiceSpeed(context, profile.speed)
        applyVoiceProfile(profile)
    }

    private fun applyVoiceProfile(profile: FemaleVoiceProfile) {
        if (!isTtsReady || textToSpeech == null) return

        if (profile.systemVoiceName != null) {
            val matchedVoice = textToSpeech?.voices?.find { it.name == profile.systemVoiceName }
            if (matchedVoice != null) {
                textToSpeech?.voice = matchedVoice
            }
        } else {
            // Find highest quality female matching language
            textToSpeech?.voices?.find { voice ->
                val name = voice.name.lowercase()
                (name.contains("female") || name.contains("woman") || name.contains("#female") || name.contains("hi-in") || name.contains("en-in")) &&
                        (voice.locale.language == "hi" || voice.locale.language == "en")
            }?.let { bestFemaleVoice ->
                textToSpeech?.voice = bestFemaleVoice
            }
        }

        textToSpeech?.setPitch(profile.pitch)
        textToSpeech?.setSpeechRate(profile.speed)
    }

    fun previewVoice(profile: FemaleVoiceProfile) {
        selectVoice(profile)
        speak(profile.sampleText)
    }

    /**
     * Cleans text thoroughly so that TTS articulates every word clearly
     * without mumbling symbols, markdown, hashtags, or emojis.
     */
    private var speakJob: Job? = null

    fun cleanTextForSpeech(rawText: String): String {
        return rawText
            // Remove XML tags like <action ... />
            .replace(Regex("""<[^>]*>"""), " ")
            // Remove markdown bold/italic asterisks & underscores (**text**, *text*, _text_)
            .replace(Regex("""[*_~#>`|]"""), " ")
            // Remove bullet numbers at start of lines like "1. ", "2. "
            .replace(Regex("""^\s*\d+[\.\)]\s*""", RegexOption.MULTILINE), "")
            // Remove URLs
            .replace(Regex("""https?://\S+"""), " link ")
            // Replace symbols with clear spoken words
            .replace("%", " percent ")
            .replace("&", " aur ")
            .replace("+", " plus ")
            .replace("@", " at ")
            .replace("WhatsApp", " WhatsApp ")
            .replace("YouTube", " YouTube ")
            .replace("SMS", " S M S ")
            // Strip emojis and weird non-alphanumeric unicode symbols while preserving Latin & Devanagari script and basic punctuation
            .replace(Regex("""[^\w\s.,!?'\u0900-\u097F-]"""), " ")
            // Normalize multiple spaces into single space
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    fun speak(text: String, onComplete: (() -> Unit)? = null) {
        stopListening()
        stopSpeaking()
        val finishedCallback = onComplete

        val cleaned = cleanTextForSpeech(text)
        if (cleaned.isBlank()) {
            finishedCallback?.invoke()
            return
        }

        val activeProfile = _selectedVoice.value
        val voiceName = if (activeProfile.isGeminiVoice) activeProfile.geminiVoiceName else "Aoede"

        // Primary Voice: Gemini AI Voice API (Powered by user's Gemini API Key)
        speakJob?.cancel()
        speakJob = coroutineScope.launch {
            var geminiSuccess = false
            try {
                com.example.ai.GeminiVoiceService.speakWithGemini(
                    context = context,
                    text = cleaned,
                    voiceName = voiceName,
                    onStart = {
                        _isSpeaking.value = true
                        startTtsWaveAnimation()
                    },
                    onComplete = {
                        geminiSuccess = true
                        _isSpeaking.value = false
                        stopTtsWaveAnimation()
                        coroutineScope.launch(Dispatchers.Main) {
                            finishedCallback?.invoke()
                        }
                    },
                    onError = { err ->
                        Log.w("SpeechManager", "Gemini Voice fallback to TTS: $err")
                    }
                )
            } catch (e: Exception) {
                Log.w("SpeechManager", "Gemini Voice exception: ${e.message}")
            }

            // Fallback to on-device TTS if Gemini Voice was unable to play (e.g. offline)
            if (!geminiSuccess && !_isSpeaking.value) {
                speakWithTts(cleaned) {
                    _isSpeaking.value = false
                    stopTtsWaveAnimation()
                    coroutineScope.launch(Dispatchers.Main) {
                        finishedCallback?.invoke()
                    }
                }
            }
        }
    }

    private fun speakWithTts(cleaned: String, onComplete: (() -> Unit)? = null) {
        if (!isTtsReady || textToSpeech == null) {
            onComplete?.invoke()
            return
        }
        _isSpeaking.value = true
        startTtsWaveAnimation()
        textToSpeech?.stop()
        textToSpeech?.setPitch(pitch)
        textToSpeech?.setSpeechRate(speed)
        currentTtsOnComplete = onComplete

        val params = Bundle()
        val utteranceId = "ZOYA_${System.currentTimeMillis()}"
        textToSpeech?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    fun stopSpeaking() {
        speakJob?.cancel()
        speakJob = null
        com.example.ai.GeminiVoiceService.stopPlayback()
        textToSpeech?.stop()
        _isSpeaking.value = false
        stopTtsWaveAnimation()
    }

    fun startListening(
        onResult: (String) -> Unit,
        onError: ((String) -> Unit)? = null,
        onFallbackToSystemDialog: (() -> Unit)? = null
    ) {
        mainHandler.post {
            stopSpeaking()

            // Check if SpeechRecognizer is available on this device
            val isAvailable = try {
                SpeechRecognizer.isRecognitionAvailable(context)
            } catch (e: Exception) {
                false
            }

            if (!isAvailable) {
                Log.w("SpeechManager", "SpeechRecognizer not available on this device, falling back to system dialog")
                _liveTranscript.value = "Voice Dialog khol rahe hain... 🎤"
                onFallbackToSystemDialog?.invoke()
                return@post
            }

            try {
                try {
                    speechRecognizer?.destroy()
                } catch (e: Exception) {
                    // ignore
                }
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            } catch (e: Exception) {
                Log.e("SpeechManager", "Failed to create SpeechRecognizer, falling back to system dialog", e)
                _liveTranscript.value = "Voice Dialog khol rahe hain... 🎤"
                onFallbackToSystemDialog?.invoke()
                return@post
            }

            val defaultLocale = Locale.getDefault()
            val primaryLang = if (defaultLocale.language.equals("hi", ignoreCase = true)) "hi-IN" else "hi-IN"

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, primaryLang)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, primaryLang)
                putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("hi-IN", "en-IN", "en-US", "ur-IN", "hi"))
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                // Generous silence threshold so user is not cut off while speaking
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 2000L)
            }

            var lastRecordedSpeech = ""

            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _isListening.value = true
                    _liveTranscript.value = "Sun rahi hoon... boliye! 🎤"
                    lastRecordedSpeech = ""
                }

                override fun onBeginningOfSpeech() {
                    _liveTranscript.value = "Sun rahi hoon... 🎙️"
                }

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.05f, 1f)
                    _audioAmplitude.value = normalized
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _isListening.value = false
                    _audioAmplitude.value = 0f
                }

                override fun onError(error: Int) {
                    _isListening.value = false
                    _audioAmplitude.value = 0f
                    Log.w("SpeechManager", "Speech recognition onError code: $error")

                    // If we captured partial speech before the timeout/error, process it!
                    if (lastRecordedSpeech.isNotBlank()) {
                        _liveTranscript.value = lastRecordedSpeech
                        onResult(lastRecordedSpeech)
                        return
                    }

                    // Reset recognizer if error is client or busy
                    if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                        try {
                            speechRecognizer?.destroy()
                        } catch (e: Exception) {
                            // ignore
                        }
                        speechRecognizer = null
                    }

                    val (errorMsg, shouldFallback) = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> Pair("Sun rahi hoon Boss... boliye na! 🎤", false)
                        SpeechRecognizer.ERROR_AUDIO -> Pair("Audio error, dobara try karein", false)
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> Pair("Mic permission allow karein", false)
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> Pair("Sun rahi hoon Boss... mic on hai, boliye! 🎙️", false)
                        SpeechRecognizer.ERROR_CLIENT -> Pair("Speech recognizer reset ho raha hai...", true)
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> Pair("Mic ready ho raha hai...", false)
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> Pair("Internet connection check karein", false)
                        else -> Pair("Sun rahi hoon... boliye na 😊", false)
                    }

                    _liveTranscript.value = errorMsg
                    onError?.invoke(errorMsg)
                }

                override fun onResults(results: Bundle?) {
                    _isListening.value = false
                    _audioAmplitude.value = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val recognizedText = matches?.firstOrNull()?.trim() ?: lastRecordedSpeech.trim()
                    if (recognizedText.isNotBlank()) {
                        _liveTranscript.value = recognizedText
                        lastRecordedSpeech = recognizedText
                        onResult(recognizedText)
                    } else {
                        _liveTranscript.value = "Sun rahi hoon Boss... boliye! 🎤"
                        onError?.invoke("Sun rahi hoon Boss... boliye! 🎤")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val partialText = matches?.firstOrNull()?.trim() ?: ""
                    if (partialText.isNotBlank()) {
                        lastRecordedSpeech = partialText
                        _liveTranscript.value = partialText
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            try {
                speechRecognizer?.startListening(intent)
                _isListening.value = true
            } catch (e: Exception) {
                Log.e("SpeechManager", "Error in startListening", e)
                _isListening.value = false
                onFallbackToSystemDialog?.invoke()
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            if (_isListening.value) {
                try {
                    speechRecognizer?.stopListening()
                } catch (e: Exception) {
                    // ignore
                }
                _isListening.value = false
                _audioAmplitude.value = 0f
            }
        }
    }

    private fun startTtsWaveAnimation() {
        ttsAnimationJob?.cancel()
        ttsAnimationJob = coroutineScope.launch(Dispatchers.Default) {
            while (_isSpeaking.value) {
                val randomAmp = Random.nextFloat() * 0.7f + 0.3f
                _audioAmplitude.value = randomAmp
                delay(80)
            }
            _audioAmplitude.value = 0f
        }
    }

    private fun stopTtsWaveAnimation() {
        ttsAnimationJob?.cancel()
        _audioAmplitude.value = 0f
    }

    fun destroy() {
        mainHandler.post {
            stopSpeaking()
            textToSpeech?.shutdown()
            try {
                speechRecognizer?.destroy()
            } catch (e: Exception) {
                // ignore
            }
            speechRecognizer = null
        }
    }
}
