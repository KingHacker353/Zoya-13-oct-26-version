package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ContactEntity
import com.example.data.model.ConversationEntity
import com.example.data.model.MemoryEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [ConversationEntity::class, MemoryEntity::class, ContactEntity::class],
    version = 2,
    exportSchema = false
)
abstract class ZoyaDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun memoryDao(): MemoryDao
    abstract fun contactDao(): ContactDao

    companion object {
        @Volatile
        private var INSTANCE: ZoyaDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): ZoyaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ZoyaDatabase::class.java,
                    "zoya_assistant_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.memoryDao(), database.conversationDao(), database.contactDao())
                    }
                }
            }

            suspend fun populateInitialData(
                memoryDao: MemoryDao,
                conversationDao: ConversationDao,
                contactDao: ContactDao
            ) {
                // Prepopulate essential creator & home location & fun facts memory
                memoryDao.insertMemory(
                    MemoryEntity(
                        key = "Creator",
                        value = "Muhammad Zubair Irshadi",
                        category = "people",
                        notes = "The brilliant creator of Zoya"
                    )
                )
                memoryDao.insertMemory(
                    MemoryEntity(
                        key = "Home Location",
                        value = "Mahudha",
                        category = "general",
                        notes = "Zoya's hometown & roots"
                    )
                )
                memoryDao.insertMemory(
                    MemoryEntity(
                        key = "Mummy's Birthday",
                        value = "15 March",
                        category = "dates",
                        notes = "Special birthday date to remember"
                    )
                )
                memoryDao.insertMemory(
                    MemoryEntity(
                        key = "Sarkar Contact",
                        value = "Best Friend / VIP",
                        category = "people",
                        notes = "Close buddy to message or call"
                    )
                )
                memoryDao.insertMemory(
                    MemoryEntity(
                        key = "Favourite Habit",
                        value = "Listening to music and multitasking",
                        category = "habits",
                        notes = "Always keep phone vibrant!"
                    )
                )

                // Prepopulate Default Contacts
                contactDao.insertContact(
                    ContactEntity(
                        name = "Sarkar",
                        phoneNumber = "+91 9876543210",
                        nickname = "Sarkar",
                        relationship = "VIP",
                        notes = "Best buddy - WhatsApp & Calls",
                        isFavorite = true
                    )
                )
                contactDao.insertContact(
                    ContactEntity(
                        name = "Muhammad Zubair Irshadi",
                        phoneNumber = "+91 9123456789",
                        nickname = "Creator",
                        relationship = "VIP",
                        notes = "Creator of Zoya from Mahudha",
                        isFavorite = true
                    )
                )
                contactDao.insertContact(
                    ContactEntity(
                        name = "Mummy",
                        phoneNumber = "+91 9898989898",
                        nickname = "Ammi",
                        relationship = "Family",
                        notes = "Birthday 15 March",
                        isFavorite = true
                    )
                )

                // Initial welcome message from Zoya
                conversationDao.insertConversation(
                    ConversationEntity(
                        role = "zoya",
                        content = "Heyy! Main Zoya hoon 🎉 Aapki masti bhari, super-smart aur chulbuli dost! Phone par koi bhi kaam ho — WhatsApp message, calling, apps open karna, alarm lagana ya koi bhi baat yaad rakhna — bas bolo! Ab batao, aaj kya dhamaka karna hai? 😉",
                        timestamp = System.currentTimeMillis(),
                        isVoice = true
                    )
                )
            }
        }
    }
}
