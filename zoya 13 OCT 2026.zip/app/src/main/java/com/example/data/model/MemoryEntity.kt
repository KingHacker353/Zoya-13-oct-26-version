package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val key: String, // e.g. "mummy_birthday", "favourite_song", "sarkar_contact", "home_location"
    val value: String, // e.g. "15 March", "Tum Hi Ho", "+919876543210", "Mahudha"
    val category: String = "general", // "dates", "preferences", "people", "habits", "general"
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
