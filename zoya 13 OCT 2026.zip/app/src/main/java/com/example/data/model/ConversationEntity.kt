package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val role: String, // "user" or "zoya"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val actionExecuted: String? = null, // e.g. "OPEN_APP: WhatsApp", "CALL_PHONE: Sarkar"
    val isVoice: Boolean = false
)
