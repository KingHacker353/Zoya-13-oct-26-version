package com.example.data.repository

import com.example.data.local.ContactDao
import com.example.data.local.ConversationDao
import com.example.data.local.MemoryDao
import com.example.data.model.ContactEntity
import com.example.data.model.ConversationEntity
import com.example.data.model.MemoryEntity
import kotlinx.coroutines.flow.Flow

class ZoyaRepository(
    private val conversationDao: ConversationDao,
    private val memoryDao: MemoryDao,
    private val contactDao: ContactDao
) {
    val allConversations: Flow<List<ConversationEntity>> = conversationDao.getAllConversations()
    val allMemories: Flow<List<MemoryEntity>> = memoryDao.getAllMemoriesFlow()
    val allContacts: Flow<List<ContactEntity>> = contactDao.getAllContactsFlow()

    suspend fun getRecentConversations(limit: Int = 8): List<ConversationEntity> {
        return conversationDao.getRecentConversations(limit)
    }

    suspend fun insertConversation(role: String, content: String, actionExecuted: String? = null, isVoice: Boolean = false): Long {
        return conversationDao.insertConversation(
            ConversationEntity(
                role = role,
                content = content,
                actionExecuted = actionExecuted,
                isVoice = isVoice
            )
        )
    }

    suspend fun clearHistory() {
        conversationDao.clearAllConversations()
    }

    suspend fun deleteConversation(id: Long) {
        conversationDao.deleteConversation(id)
    }

    suspend fun getAllMemoriesList(): List<MemoryEntity> {
        return memoryDao.getAllMemories()
    }

    suspend fun searchMemories(query: String): List<MemoryEntity> {
        return memoryDao.searchMemories(query)
    }

    suspend fun insertMemory(key: String, value: String, category: String = "general", notes: String = ""): Long {
        return memoryDao.insertMemory(
            MemoryEntity(
                key = key.trim(),
                value = value.trim(),
                category = category,
                notes = notes
            )
        )
    }

    suspend fun updateMemory(memory: MemoryEntity) {
        memoryDao.updateMemory(memory)
    }

    suspend fun deleteMemory(memory: MemoryEntity) {
        memoryDao.deleteMemory(memory)
    }

    suspend fun deleteMemoryById(id: Long) {
        memoryDao.deleteMemoryById(id)
    }

    suspend fun clearAllMemories() {
        memoryDao.clearAllMemories()
    }

    // Contacts
    suspend fun getAllContactsList(): List<ContactEntity> {
        return contactDao.getAllContacts()
    }

    suspend fun searchContacts(query: String): List<ContactEntity> {
        return contactDao.searchContacts(query)
    }

    suspend fun findContact(nameOrNickname: String): ContactEntity? {
        return contactDao.findContactByNameOrNickname(nameOrNickname)
    }

    suspend fun insertContact(contact: ContactEntity): Long {
        return contactDao.insertContact(contact)
    }

    suspend fun updateContact(contact: ContactEntity) {
        contactDao.updateContact(contact)
    }

    suspend fun deleteContact(contact: ContactEntity) {
        contactDao.deleteContact(contact)
    }

    suspend fun deleteContactById(id: Long) {
        contactDao.deleteContactById(id)
    }
}

