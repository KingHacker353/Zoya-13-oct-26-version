package com.example.data.islamic

data class SurahInfo(
    val number: Int,
    val nameArabic: String,
    val nameEnglish: String,
    val nameHindi: String,
    val meaningHindi: String,
    val totalAyats: Int,
    val revelationType: String, // "मक्की" or "मदनी"
    val virtues: String = ""
)

data class AyatDetail(
    val surahNumber: Int,
    val surahName: String,
    val ayatNumber: Int,
    val arabicText: String,
    val hindiTransliteration: String, // हिंदी में उच्चारण (तलफ़्फ़ुज़)
    val hindiTranslation: String,     // हिंदी तर्जुमा (अनुवाद)
    val virtues: String = ""
)

data class NaatItem(
    val id: String,
    val title: String,
    val titleUrdu: String,
    val poet: String,
    val category: String,
    val stanzas: List<String>, // छंद / शेर
    val hindiLyrics: String,
    val audioRecitationText: String
)

data class ShayariItem(
    val id: String,
    val title: String,
    val poet: String,
    val category: String, // "इश्क़-ए-रसूल ﷺ", "अल्लामा इक़बाल", "नमाज़ व इबादत", "सब्र व दुआ"
    val couplets: List<String>,
    val audioRecitationText: String
)

data class KalimaItem(
    val number: Int,
    val name: String,
    val arabicText: String,
    val hindiTransliteration: String,
    val hindiTranslation: String
)

data class DuaItem(
    val id: String,
    val title: String,
    val occasion: String,
    val arabicText: String,
    val hindiTransliteration: String,
    val hindiTranslation: String,
    val benefit: String = ""
)

data class HadithItem(
    val id: String,
    val title: String,
    val arabicText: String,
    val hindiTransliteration: String,
    val hindiTranslation: String,
    val rawi: String,
    val reference: String,
    val category: String,
    val lesson: String,
    val audioRecitationText: String
)

data class FatwaItem(
    val id: String,
    val title: String,
    val topic: String,
    val question: String,
    val fatwaAnswer: String,
    val reference: String,
    val audioRecitationText: String
)
