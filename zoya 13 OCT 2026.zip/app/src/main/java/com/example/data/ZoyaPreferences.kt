package com.example.data

import android.content.Context
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ZoyaPreferences {

    private const val PREFS_NAME = "zoya_user_preferences"
    private const val KEY_CUSTOM_GEMINI_API_KEY = "custom_gemini_api_key"
    private const val KEY_SELECTED_VOICE_ID = "selected_voice_id"
    private const val KEY_VOICE_PITCH = "voice_pitch"
    private const val KEY_VOICE_SPEED = "voice_speed"
    private const val KEY_PERSONALITY = "personality_level"

    fun getGeminiApiKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val customKey = prefs.getString(KEY_CUSTOM_GEMINI_API_KEY, "")?.trim()?.removeSurrounding("\"")?.removeSurrounding("'") ?: ""
        if (customKey.isNotBlank() && customKey != "MY_GEMINI_API_KEY") {
            return customKey
        }
        val buildKey = try {
            BuildConfig.GEMINI_API_KEY.trim().removeSurrounding("\"").removeSurrounding("'")
        } catch (e: Exception) {
            ""
        }
        return if (buildKey == "MY_GEMINI_API_KEY") "" else buildKey
    }

    fun setGeminiApiKey(context: Context, key: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_CUSTOM_GEMINI_API_KEY, key.trim()).apply()
    }

    fun getSelectedVoiceId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_SELECTED_VOICE_ID, "gemini_aoede") ?: "gemini_aoede"
        // Ensure only Gemini API voices are returned; migrate any legacy voice
        return if (saved.startsWith("gemini_")) saved else "gemini_aoede"
    }

    fun setSelectedVoiceId(context: Context, voiceId: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_SELECTED_VOICE_ID, voiceId.trim()).apply()
    }

    fun getVoicePitch(context: Context): Float {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getFloat(KEY_VOICE_PITCH, 1.0f)
    }

    fun setVoicePitch(context: Context, pitch: Float) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putFloat(KEY_VOICE_PITCH, pitch).apply()
    }

    fun getVoiceSpeed(context: Context): Float {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getFloat(KEY_VOICE_SPEED, 0.98f)
    }

    fun setVoiceSpeed(context: Context, speed: Float) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putFloat(KEY_VOICE_SPEED, speed).apply()
    }

    private const val KEY_MEMORY_STORAGE_PIN = "memory_storage_pin"

    fun getPersonality(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_PERSONALITY, "Max Chulbuli 💖") ?: "Max Chulbuli 💖"
    }

    fun setPersonality(context: Context, personality: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PERSONALITY, personality).apply()
    }

    /**
     * Memory Storage PIN / Password Protection
     * Default PIN is 1234. Only the user can access their private notes, memories and vault!
     */
    fun getMemoryStoragePin(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_MEMORY_STORAGE_PIN, "1234") ?: "1234"
    }

    fun setMemoryStoragePin(context: Context, pin: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_MEMORY_STORAGE_PIN, pin.trim()).apply()
    }

    fun verifyMemoryStoragePin(context: Context, enteredPin: String): Boolean {
        val currentPin = getMemoryStoragePin(context)
        return enteredPin.trim() == currentPin.trim()
    }

    /**
     * Test Gemini API key connection with a lightweight ping.
     */
    suspend fun testGeminiApiKey(key: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val cleanKey = key.trim()
        if (cleanKey.isEmpty() || cleanKey == "MY_GEMINI_API_KEY") {
            return@withContext Pair(false, "API Key khali hai! Kripya valid key darj karein.")
        }

        val client = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()

        val json = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Hello")))
            ))
        }

        val modelsToTest = listOf("gemini-3.6-flash", "gemini-3.5-flash", "gemini-flash-latest")
        var lastError = ""

        for (model in modelsToTest) {
            try {
                val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$cleanKey"
                val request = Request.Builder()
                    .url(url)
                    .post(json.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(request).execute()
                val body = response.body?.string() ?: ""

                if (response.isSuccessful) {
                    return@withContext Pair(true, "Gemini AI Connected Successfully ($model)! 🚀✨")
                } else {
                    lastError = "Error ${response.code}: ${body.take(120)}"
                }
            } catch (e: Exception) {
                lastError = e.localizedMessage ?: "Connection error"
            }
        }

        Pair(false, lastError)
    }

    // User Order & Delivery Profile for 1-Click Shopping & Train Ticket Automation
    data class UserOrderProfile(
        val fullName: String = "Shaikh Zuber (Muhammad Zubair Irshadi)",
        val phoneNumber: String = "9876543210",
        val email: String = "shaikhzuber018@gmail.com",
        val addressLine1: String = "Irshadi Manzil, Near Jama Masjid",
        val addressLine2: String = "Station Road, Main Bazaar",
        val landmark: String = "Near Bus Station",
        val city: String = "Mahudha",
        val district: String = "Kheda",
        val state: String = "Gujarat",
        val pincode: String = "387335",
        val irctcUsername: String = "shaikhzuber018",
        val passengerAge: String = "28",
        val passengerGender: String = "Male",
        val berthPreference: String = "Lower"
    )

    fun getUserOrderProfile(context: Context): UserOrderProfile {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return UserOrderProfile(
            fullName = prefs.getString("profile_full_name", "Shaikh Zuber (Muhammad Zubair Irshadi)") ?: "Shaikh Zuber (Muhammad Zubair Irshadi)",
            phoneNumber = prefs.getString("profile_phone", "9876543210") ?: "9876543210",
            email = prefs.getString("profile_email", "shaikhzuber018@gmail.com") ?: "shaikhzuber018@gmail.com",
            addressLine1 = prefs.getString("profile_address_line1", "Irshadi Manzil, Near Jama Masjid") ?: "Irshadi Manzil, Near Jama Masjid",
            addressLine2 = prefs.getString("profile_address_line2", "Station Road, Main Bazaar") ?: "Station Road, Main Bazaar",
            landmark = prefs.getString("profile_landmark", "Near Bus Station") ?: "Near Bus Station",
            city = prefs.getString("profile_city", "Mahudha") ?: "Mahudha",
            district = prefs.getString("profile_district", "Kheda") ?: "Kheda",
            state = prefs.getString("profile_state", "Gujarat") ?: "Gujarat",
            pincode = prefs.getString("profile_pincode", "387335") ?: "387335",
            irctcUsername = prefs.getString("profile_irctc_username", "shaikhzuber018") ?: "shaikhzuber018",
            passengerAge = prefs.getString("profile_passenger_age", "28") ?: "28",
            passengerGender = prefs.getString("profile_passenger_gender", "Male") ?: "Male",
            berthPreference = prefs.getString("profile_berth_pref", "Lower") ?: "Lower"
        )
    }

    fun saveUserOrderProfile(context: Context, profile: UserOrderProfile) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().apply {
            putString("profile_full_name", profile.fullName.trim())
            putString("profile_phone", profile.phoneNumber.trim())
            putString("profile_email", profile.email.trim())
            putString("profile_address_line1", profile.addressLine1.trim())
            putString("profile_address_line2", profile.addressLine2.trim())
            putString("profile_landmark", profile.landmark.trim())
            putString("profile_city", profile.city.trim())
            putString("profile_district", profile.district.trim())
            putString("profile_state", profile.state.trim())
            putString("profile_pincode", profile.pincode.trim())
            putString("profile_irctc_username", profile.irctcUsername.trim())
            putString("profile_passenger_age", profile.passengerAge.trim())
            putString("profile_passenger_gender", profile.passengerGender.trim())
            putString("profile_berth_pref", profile.berthPreference.trim())
            apply()
        }
    }
}
